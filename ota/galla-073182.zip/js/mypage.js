/* ═══ 이중 모드(MPA/SPA) ═══
   · MPA(mypage.html 단독 문서): 파일 하단에서 기존처럼 DOMContentLoaded 자동 초기화.
   · SPA(app.html, body[data-page="spa"]): 자동 초기화를 건너뛰고
     window.GALLA_PAGE_MYPAGE.mount(root, params)를 어댑터(js/spa/views/mypage.js)가 호출.
   로직은 동일 — 페이지 요소 조회만 root(D)로 스코프해 단일문서 내 충돌을 막는다. */
async function GALLA_mypageInit(root, spaParams) {
    // 조회 루트 — MPA면 document, SPA면 view-host(#app 추출분)
    const D = (root && root !== document && root.querySelector) ? root : document;
    const byId = (id) => (D === document) ? document.getElementById(id) : D.querySelector("#" + id);

    // ---------------------------
    // Supabase client 확보 (UMD bootstrap 대응)
    // ---------------------------
    const supabase = await waitForSupabaseClient();

    // ---------------------------
    // 현재 페이지 정보 (SPA에선 view-host의 data-page)
    // ---------------------------
    const currentPage = (D !== document && D.dataset && D.dataset.page) || document.body.dataset.page;

    // ---------------------------
    // 하단 네비 active 적용 (SPA엔 판 안에 네비가 없어 no-op — 셸 네비는 라우터가 칠한다)
    // ---------------------------
    D.querySelectorAll(".bottom-nav .nav-item").forEach(item => {
        item.classList.toggle("active", item.dataset.page === currentPage);
    });

    // ---------------------------
    // 상단 nav (필요한 경우만 적용)
    // ---------------------------
    D.querySelectorAll(".nav-item").forEach(item => {
        item.classList.toggle("active", item.dataset.page === currentPage);
    });

    // 🩹 자가치유 — CF/SW가 이 문서에만 옛 HTML(모아 탭 없는 버전)을 주는 경우가 있다.
    //   (내비게이션엔 옛 HTML, page fetch엔 최신 — 광장 ensurePlazaPanel과 동일 증상, 사장님 확정.)
    //   최신 HTML을 page fetch로 받아 탭바를 통째 교체하고 gallari.css를 보장한다. MPA에서만.
    if (D === document && !D.querySelector('.tabs .tab[data-tab="all"]')) {
        try {
            const html = await fetch(location.pathname + '?mh=' + Date.now(), { cache: 'reload' }).then(r => r.text());
            const fdoc = new DOMParser().parseFromString(html, 'text/html');
            const fresh = fdoc.querySelector('.tabs');
            const cur = D.querySelector('.tabs');
            if (fresh && cur && fresh.querySelector('.tab[data-tab="all"]')) {
                cur.innerHTML = fresh.innerHTML;
                if (!document.querySelector('link[href*="gallari.css"]')) {
                    const link = fdoc.querySelector('link[href*="gallari.css"]');
                    if (link) { const l = document.createElement("link"); l.rel = "stylesheet"; l.href = link.getAttribute("href"); document.head.appendChild(l); }
                }
                console.info("[mypage] 탭바 자가치유 완료(모아 탭 복원)");
            }
        } catch (e) { console.warn("[mypage] tab heal skip:", e); }
    }

    // ---------------------------
    // 탭 요소
    // ---------------------------
    const tabs = D.querySelectorAll(".tab");
    const tabContent = byId("tabContent");

    // ---------------------------
    // 로그인 세션 확보
    // ---------------------------
    const { data: sessionData } = await supabase.auth.getSession();
    const session = sessionData?.session;

    if (!session?.user) {
        // SPA(app.html): 문서 이탈 없이 로그인 뷰 push. MPA는 기존 그대로.
        if (document.body.dataset.page === "spa" && window.GALLA_gotoLogin) { window.GALLA_gotoLogin("mypage"); return; }
        if (!document.body.classList.contains("in-shell")) alert("로그인이 필요합니다."); // 셸 백그라운드 판에선 알럿이 셸 전체를 덮는다
        (window.GALLA_nav||function(u){location.href=u})("login.html");
        return;
    }

    const userId = session.user.id;

    // ============================
    // View User (self vs other)
    // ============================
    const params = new URLSearchParams(spaParams || location.search); // SPA는 라우터 params, MPA는 쿼리스트링
    const viewUserId = params.get("user") || userId;
    const isMyPage = viewUserId === userId;

    // ============================
    // 헤더 & 탭: 내 프로필 vs 방문자 뷰 분기
    // ============================
    // 남의 프로필도 '원래 마이페이지'와 같은 크롬으로 본다 — 커스텀 헤더 교체(뒤로/⋯공유)는
    // 앱 전체 문법과 어긋나 '이상한 페이지'처럼 보여서 폐기. 데이터 분기(비공개 숨김)만 유지.
    // SPA에선 내 탭(mp-self) 위에 남의 프로필 스택(mp-other)이 겹쳐 mount될 수 있어 갈아끼운다
    document.body.classList.remove("mp-self", "mp-other");
    document.body.classList.add(isMyPage ? "mp-self" : "mp-other");
    if (window.initNotifications) window.initNotifications();
    if (!isMyPage) {
        // 방문자에게 비공개 탭 숨김 (뉴스=저장한 뉴스는 본인만). 갈라/예측/광장은 공개 My만.
        ["news"].forEach(t => {
            D.querySelector(`.tab[data-tab="${t}"]`)?.setAttribute("hidden", "");
        });
    }

    // ============================
    // Profile Actions (Follow / Message) - Render dynamically
    // ============================
    const profileActions = byId("profileActions");
    profileActions.innerHTML = "";

    if (isMyPage) {
        const editBtn = document.createElement("button");
        editBtn.className = "action-btn primary";
        editBtn.textContent = "프로필 편집";
        editBtn.onclick = () => (window.GALLA_nav||function(u){location.href=u})("account-edit.html");

        const missionBtn = document.createElement("button");
        missionBtn.className = "action-btn secondary";
        missionBtn.textContent = "오늘의 미션";
        missionBtn.onclick = () => (window.GALLA_nav||function(u){location.href=u})("quest.html");

        /* 상점 직행 — 기존엔 설정 안까지 들어가야 했다(사장님 UX 지적) */
        const shopBtn = document.createElement("button");
        shopBtn.className = "action-btn secondary";
        shopBtn.textContent = "🛒 상점";
        shopBtn.onclick = () => window.openShop ? window.openShop() : ((window.GALLA_nav||function(u){location.href=u})("settings.html"));

        profileActions.appendChild(editBtn);
        profileActions.appendChild(missionBtn);
        profileActions.appendChild(shopBtn);
    } else {
        const followBtn = document.createElement("button");
        followBtn.className = "action-btn primary";

        const messageBtn = document.createElement("button");
        messageBtn.className = "action-btn secondary";
        messageBtn.textContent = "메시지 보내기";

        const { data: followRow } = await supabase
            .from("follows")
            .select("id")
            .eq("follower", userId)
            .eq("following", viewUserId)
            .maybeSingle();

        let isFollowing = !!followRow;
        followBtn.textContent = isFollowing ? "언팔로우" : "팔로우";

        followBtn.onclick = async () => {
            if (isFollowing) {
                await supabase.from("follows")
                    .delete()
                    .eq("follower", userId)
                    .eq("following", viewUserId);
            } else {
                await supabase.from("follows")
                    .insert({ follower: userId, following: viewUserId });
            }
            // SPA(app.html): location.reload()는 앱 전체를 재부팅하고 해시(#/mypage?user=)가
            // 탭으로 해석돼 '내 프로필'로 떨어진다 — 제자리 갱신. MPA는 기존 reload 유지.
            if (document.body.dataset.page === "spa") {
                isFollowing = !isFollowing;
                followBtn.textContent = isFollowing ? "언팔로우" : "팔로우";
            } else location.reload();
        };

        messageBtn.onclick = () => {
            const name = byId("profileName")?.textContent || "";
            if (window.startDM) window.startDM(viewUserId, name);
        };

        /* ⚔️ 일기토 신청 버튼 제거 — 일기토는 '논쟁 중인 댓글'에서만 신청한다.
           프로필에서 아무한테나 도전하는 구조가 아님(사장님 룰). 전적 열람은 별개. */
        profileActions.appendChild(followBtn);
        profileActions.appendChild(messageBtn);
    }

    // ============================
    // Load viewed user's profile data (nickname, bio, level, avatar_url)
    // ============================
    const { data: viewProfile, error: viewProfileError } = await supabase
        .from("users")
        .select("nickname, bio, level, avatar_url")
        .eq("id", viewUserId)
        .single();

    if (!viewProfileError && viewProfile) {
        const nameEl = byId("profileName");
        const descEl = byId("profileDesc");
        const levelEl = byId("levelText");
        const profileImg = byId("profileImg");

        if (nameEl) {
            nameEl.textContent = viewProfile.nickname || "익명의 사용자";
            nameEl.setAttribute("data-nick-uid", viewUserId);   // 꾸미기 도색 대상
        }
        const hdrTitle = byId("mpHdrTitle");
        if (hdrTitle) hdrTitle.textContent = viewProfile.nickname || "프로필";
        if (descEl) descEl.textContent = viewProfile.bio || "소개 문구가 없습니다.";
        // 레벨·등급 칩 — 죽은 users.level 대신 갈라리안 GI 등급으로 통일
        // (설정·grade 페이지와 동일: 예 "여론 논객 Lv.3")
        if (levelEl) levelEl.textContent = "…";
        const tierChip = byId("tierChip");
        if (tierChip) tierChip.textContent = "🌱";
        (async () => {
            try {
                // grade 페이지와 '완전히' 동일한 full 계산(merit·예측 포함)으로 통일
                const g = window.GALLA_gallianOf ? await window.GALLA_gallianOf(supabase, viewUserId) : null;
                const t = g?.tier || { name: "🌱 눈팅 뉴비" };
                const sl = g?.subLevel || 1;
                // ⚠️ 등급(TIERS)엔 icon 필드가 없다 — 이모지가 name 앞에 붙어있다("🎤 여론 논객").
                //    t.icon(undefined)을 칩에 넣어 '등급 아이콘이 안 뜨던' 버그. name에서 이모지를 뽑는다.
                const tierIcon = (t.name || "🌱").trim().split(/\s+/)[0];
                if (levelEl) levelEl.textContent = `${t.name} Lv.${sl}`;
                if (tierChip) { tierChip.textContent = tierIcon; tierChip.title = `${t.name} Lv.${sl}`; }
            } catch (_) { if (levelEl) levelEl.textContent = "눈팅 뉴비 Lv.1"; }
        })();
        // 전투력 = 이 유저가 벌인 전투 액션(공격/방어/지원) 총량
        (async () => {
            const powerEl = byId("powerText");
            if (!powerEl) return;
            const { count } = await supabase
                .from("comment_actions")
                .select("id", { count: "exact", head: true })
                .eq("user_id", viewUserId);
            powerEl.textContent = `⚡ 전투력 ${(count ?? 0).toLocaleString()}`;
        })();
        const badgeEl = byId("badgeText");
        if (badgeEl) {
            if (isMyPage) badgeEl.textContent = "🎯 오늘의 미션";
            else badgeEl.hidden = true; // 미션 배지는 본인 전용
        }

        if (profileImg) {
            window.GALLA_setAvatar(profileImg, viewProfile.avatar_url, 256, true);
            // 📷 카톡식 프로필 사진 전체보기 — 탭/꾹 누르면 흐린 배경 + 큰 사진 + 액션
            profileImg.style.cursor = "pointer";
            bindAvatarViewer(profileImg, viewProfile.avatar_url, viewProfile.nickname, viewUserId, isMyPage);
        }
    }

    // =====================================================
    // 📷 프로필 사진 전체보기(카톡식) — 흐린 배경, 큰 원형 사진, 공유/링크/편집
    // =====================================================
    function bindAvatarViewer(imgEl, avatarUrl, nick, uid, isSelf) {
        const escT = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
        const open = () => {
            const big = window.GALLA_avatarSrc(avatarUrl, 720);
            const profileUrl = location.origin + "/mypage.html?user=" + encodeURIComponent(uid);
            const ov = document.createElement("div");
            ov.className = "av-viewer";
            ov.innerHTML =
                '<div class="av-bg" style="background-image:url(\'' + big + '\')"></div>' +
                '<div class="av-scrim"></div>' +
                '<button class="av-x" aria-label="닫기"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button>' +
                '<div class="av-stage">' +
                  '<div class="av-photo-wrap">' +
                    '<img class="av-photo" src="' + big + '" alt="" draggable="false" oncontextmenu="return false" onerror="this.onerror=null;this.src=window.GALLA_DEFAULT_AVATAR">' +
                    (isSelf ? '<button class="av-pen" aria-label="사진 변경"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/></svg></button>' : '') +
                  '</div>' +
                  '<div class="av-name">' + escT(nick || "익명") + '</div>' +
                '</div>' +
                '<div class="av-actions">' +
                  '<button class="av-act" data-act="share"><span class="av-act-ic"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><path d="M8.6 13.5l6.8 4M15.4 6.5l-6.8 4"/></svg></span><b>공유하기</b></button>' +
                  '<button class="av-act" data-act="copy"><span class="av-act-ic"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1"/></svg></span><b>링크 복사</b></button>' +
                  (isSelf ? '<button class="av-act" data-act="edit"><span class="av-act-ic"><svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></svg></span><b>사진 변경</b></button>' : '') +
                '</div>';
            document.body.appendChild(ov);
            requestAnimationFrame(() => ov.classList.add("on"));
            // 셸(네이티브) 하단 nav를 숨긴다 — 뷰어 하단 액션이 nav와 겹치던 문제(사장님 제보)
            const navHide = (on) => { try { if (window.parent && window.parent !== window) window.parent.postMessage({ galla: "shell", t: "navhide", on }, location.origin); } catch (_) {} };
            navHide(true);
            const close = () => { navHide(false); ov.classList.remove("on"); setTimeout(() => ov.remove(), 240); };
            ov.querySelector(".av-x").onclick = close;
            ov.querySelector(".av-scrim").onclick = close;
            const penEl = ov.querySelector(".av-pen"); if (penEl) penEl.onclick = () => { (window.GALLA_nav||function(u){location.href=u})("account-edit.html"); };
            const copyLink = () => {
                try { navigator.clipboard.writeText(profileUrl); } catch (_) { }
                (window.GALLA_toast || alert)("🔗 프로필 링크 복사됨");
            };
            ov.querySelectorAll(".av-act").forEach(b => {
                b.onclick = () => {
                    const a = b.dataset.act;
                    if (a === "share") {
                        if (navigator.share) navigator.share({ title: nick || "GALLA", url: profileUrl }).catch(() => { });
                        else copyLink();
                    } else if (a === "copy") { copyLink(); }
                    else if (a === "edit") { (window.GALLA_nav||function(u){location.href=u})("account-edit.html"); }
                };
            });
            // 아래로 쓸어내리면 닫기
            let y0 = null;
            ov.addEventListener("touchstart", (e) => { y0 = e.touches[0].clientY; }, { passive: true });
            ov.addEventListener("touchend", (e) => { if (y0 != null && e.changedTouches[0].clientY - y0 > 80) close(); y0 = null; }, { passive: true });
        };
        // 탭 + 꾹 누르기(롱프레스) 모두 열기
        imgEl.addEventListener("click", (e) => { e.preventDefault(); open(); });
        let lpTimer = null;
        imgEl.addEventListener("touchstart", () => { lpTimer = setTimeout(open, 450); }, { passive: true });
        imgEl.addEventListener("touchend", () => { clearTimeout(lpTimer); }, { passive: true });
        imgEl.addEventListener("touchmove", () => { clearTimeout(lpTimer); }, { passive: true });
    }

    // =====================================================
    // Load My Stats
    // =====================================================
    async function loadMyStats() {
        // 1) My Drop: count of issues where user_id = viewUserId
        const { count: dropCount, error: dropError } = await supabase
            .from("issues")
            .select("id", { count: "exact", head: true })
            .eq("user_id", viewUserId);

        // 2) Followers: count of follows where following = viewUserId
        const { count: followerCount, error: followerError } = await supabase
            .from("follows")
            .select("id", { count: "exact", head: true })
            .eq("following", viewUserId);

        // 3) 내가 만든 이슈 id 목록
        const { data: myIssues, error: myIssuesError } = await supabase
            .from("issues")
            .select("id")
            .eq("user_id", viewUserId);

        const myIssueIds = (myIssues || []).map(i => i.id);

        // 4) Supports (찬성): votes.type = 'pro'
        let supportSum = 0;
        if (myIssueIds.length > 0) {
            const { count } = await supabase
                .from("votes")
                .select("id", { count: "exact", head: true })
                .in("issue_id", myIssueIds)
                .eq("type", "pro");
            supportSum = count || 0;
        }

        // 5) Opposes (반발): votes.type = 'con'
        let opposeSum = 0;
        if (myIssueIds.length > 0) {
            const { count } = await supabase
                .from("votes")
                .select("id", { count: "exact", head: true })
                .in("issue_id", myIssueIds)
                .eq("type", "con");
            opposeSum = count || 0;
        }

        // Update DOM elements (fallback to 0)
        const setStat = (selector, value) => {
            const el = D.querySelector(selector);
            if (el) el.textContent = value ?? 0;
        };
        setStat("#statDrop", dropCount ?? 0);
        setStat("#statFollowers", followerCount ?? 0);
        setStat("#statSupports", supportSum ?? 0);
        setStat("#statOppose", opposeSum ?? 0);
    }

    // Load stats before initial render
    loadMyStats();

    // 발의자 후원 수익 카드 (내 프로필 & 받은 후원이 있을 때만)
    if (isMyPage && window.GALLA_renderEarnings) window.GALLA_renderEarnings();

    // =====================================================
    // My 갈라 — 내가 만든 이슈
    // =====================================================
    /* 탭 그리드 로딩 스피너 — 회색 텍스트 대신 갈라 톤 스피너(로드 완료까지 유지) */
    const MP_SPINNER = `<div style="display:flex;align-items:center;justify-content:center;padding:64px 0">
      <i style="width:28px;height:28px;border-radius:50%;border:2.5px solid rgba(255,255,255,.14);border-top-color:#6f86ff;display:block;animation:mpspin .7s linear infinite"></i>
    </div><style>@keyframes mpspin{to{transform:rotate(360deg)}}</style>`;

    const renderMy = async () => {
        // 스냅샷 그리드가 떠 있는 동안 grid 클래스를 벗기면 첫 사진이 전체 폭으로 터진다(사장님 재현)
        if (!tabContent.firstElementChild) tabContent.className = "content-area";
        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        const { data: issues, error } = await supabase
            .from("issues")
            .select(`
                id,
                title,
                created_at,
                score,
                thumbnail_url,
                card_thumb_url,
                images,
                video_url
            `)
            .eq("user_id", viewUserId)
            .order("created_at", { ascending: false });

        if (error) {
            console.error("[My Galla] error", error);
            tabContent.innerHTML = `<div style="color:#777">불러오기 실패</div>`;
            return;
        }

        if (!issues || issues.length === 0) {
            tabContent.innerHTML = `
                <div style="color:#777;font-size:14px;padding:20px;">
                    아직 발의한 이슈가 없습니다.
                </div>
            `;
            return;
        }

        // 인스타식 3열 정사각 그리드(igCard) — 다른 탭과 통일
        tabContent.className = "content-area grid";
        tabContent.innerHTML = "";

        const qvItems = issues.map(i => ({ type: "issue", id: i.id }));
        issues.forEach((issue, myIdx) => {
            const firstImg = Array.isArray(issue.images) && issue.images.length ? issue.images[0] : null;
            tabContent.appendChild(igCard({
                // 갈라 브랜드 카드 썸네일 우선(사장님 지시 — 영상 원본 프레임은 톤 깨짐).
                // 이미지 변환이 켜진 지금은 igCard 쪽 GALLA_thumb가 480px로 줄여 받아 무겁지 않다.
                thumb: issue.card_thumb_url || issue.thumbnail_url || firstImg || null,
                title: issue.title,
                badge: issue.video_url ? "▶" : "",
                onClick: () => openQvList(qvItems, myIdx)   // 이탈 금지 — 마이페이지 내 퀵뷰로 소비
            }));
        });
    };

    // =====================================================
    // Battle / Save / Favorite (아직 더미 유지)
    // =====================================================
    const renderBattle = async () => {
        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        // 1) 내가 만든 원본 이슈 id 목록
        const { data: myIssues, error: myIssuesError } = await supabase
            .from("issues")
            .select("id, title, thumbnail_url")
            .eq("user_id", viewUserId);

        if (myIssuesError) {
            console.error("[Battle Galla] my issues error", myIssuesError);
            tabContent.innerHTML = `<div style="color:#777">불러오기 실패</div>`;
            return;
        }

        if (!myIssues || myIssues.length === 0) {
            tabContent.innerHTML = `
                <div style="color:#777;font-size:14px;padding:20px;">
                    아직 배틀이 발생한 이슈가 없습니다.
                </div>
            `;
            return;
        }

        const myIssueIds = myIssues.map(i => i.id);

        // 2) 내 이슈에 참전된 배틀 이슈 조회 (명시적 battle_type 기준)
        const { data: battleIssues, error: battleError } = await supabase
            .from("issues")
            .select(`
                id,
                title,
                thumbnail_url,
                origin_issue_id,
                battle_type,
                score
            `)
            // battle 판단 기준: origin_issue_id 존재 여부 (legacy 데이터 호환)
            .in("origin_issue_id", myIssueIds)
            .neq("user_id", userId);

        if (battleError) {
            console.error("[Battle Galla] battle issues error", battleError);
            tabContent.innerHTML = `<div style="color:#777">불러오기 실패</div>`;
            return;
        }

        if (!battleIssues || battleIssues.length === 0) {
            tabContent.innerHTML = `
                <div style="color:#777;font-size:14px;padding:20px;">
                    아직 배틀이 발생한 이슈가 없습니다.
                </div>
            `;
            return;
        }

        tabContent.innerHTML = "";

        battleIssues.forEach(battle => {
            const origin = myIssues.find(i => i.id === battle.origin_issue_id);

            const card = document.createElement("div");
            card.className = "thumb-card";

            card.innerHTML = `
                <img src="${origin?.thumbnail_url || "./assets/logo.png"}">
                <div class="thumb-title">${origin?.title || "Battle Issue"}</div>
                <div class="thumb-author">⚔️ 참전 발생</div>
                <div class="thumb-stats">
                    <span>🔥 ${battle.score ?? 0}</span>
                </div>
            `;

            card.onclick = () => openQvList([{ type: "issue", id: battle.origin_issue_id }], 0); // 이탈 금지 — 퀵뷰

            tabContent.appendChild(card);
        });
    };

    // =====================================================
    // 퀵뷰 모달 — 그리드 클릭 시 페이지 이탈 없이 미리보기
    // =====================================================
    // 퀵뷰 탐색 상태: 현재 탭의 아이템 목록 + 위치
    let QV_ITEMS = [];   // [{type:'issue'|'news'|'plaza', id}]
    let QV_INDEX = 0;
    let qvDirty = false; // 퀵뷰에서 저장 해제 등 변경 발생 → 닫을 때 탭 새로고침

    function closeQuickView() {
        const qv = document.getElementById("mpQuickView");
        if (!qv) return;
        qv.classList.remove("open");
        document.body.style.overflow = "";
        if (qvDirty) {
            qvDirty = false;
            D.querySelector(".tab.active")?.click(); // 현재 탭 재렌더
            loadTabCounts(); // 탭 카운트 갱신
        }
    }

    function qvStep(dir) {
        const next = QV_INDEX + dir;
        if (next < 0 || next >= QV_ITEMS.length) return;
        QV_INDEX = next;
        showQvCurrent();
    }

    function showQvCurrent() {
        const it = QV_ITEMS[QV_INDEX];
        if (!it) return;
        if (it.type === "issue") quickViewIssue(it.id);
        else if (it.type === "news") quickViewNews(it.id);
        else if (it.type === "plaza") quickViewPlaza(it.id);
        else if (it.type === "market") quickViewMarket(it.id);
    }

    function openQvList(items, index) {
        QV_ITEMS = items;
        QV_INDEX = index;
        showQvCurrent();
    }

    // 공용 아이콘 SVG — 전 페이지 통일
    const BM_ICON = '<svg class="ic-bookmark" viewBox="0 0 24 24"><path d="M18 21l-6-4.3L6 21V5.5A2.5 2.5 0 0 1 8.5 3h7A2.5 2.5 0 0 1 18 5.5V21z"/></svg>';
    const SHARE_ICON = '<svg class="ic-share" viewBox="0 0 24 24"><path d="M21.5 2.5L10.8 13.2"/><path d="M21.5 2.5l-6.8 19-3.9-8.3-8.3-3.9 19-6.8z"/></svg>';

    function ensureQuickView() {
        let qv = document.getElementById("mpQuickView");
        if (qv) return qv;
        qv = document.createElement("div");
        qv.id = "mpQuickView";
        qv.innerHTML = `
            <div class="qv-dim"></div>
            <div class="qv-card">
                <button class="qv-close" aria-label="닫기">✕</button>
                <button class="qv-nav qv-prev" aria-label="이전">‹</button>
                <button class="qv-nav qv-next" aria-label="다음">›</button>
                <div class="qv-media"></div>
                <div class="qv-body">
                    <div class="qv-cat"></div>
                    <div class="qv-title"></div>
                    <div class="qv-desc"></div>
                    <div class="qv-stats"></div>
                    <div class="qv-actions"></div>
                    <button class="qv-go"></button>
                </div>
            </div>`;
        document.body.appendChild(qv);
        qv.querySelector(".qv-dim").onclick = closeQuickView;
        qv.querySelector(".qv-close").onclick = closeQuickView;
        qv.querySelector(".qv-prev").onclick = () => qvStep(-1);
        qv.querySelector(".qv-next").onclick = () => qvStep(1);

        // 좌우 스와이프로 이전/다음 (세로 스크롤과 구분)
        const card = qv.querySelector(".qv-card");
        let tx = 0, ty = 0;
        card.addEventListener("touchstart", e => {
            tx = e.touches[0].clientX; ty = e.touches[0].clientY;
        }, { passive: true });
        card.addEventListener("touchend", e => {
            const dx = e.changedTouches[0].clientX - tx;
            const dy = e.changedTouches[0].clientY - ty;
            if (Math.abs(dx) > 60 && Math.abs(dx) > Math.abs(dy) * 1.5) {
                qvStep(dx < 0 ? 1 : -1);
            }
        }, { passive: true });

        // 키보드 ← → / ESC
        document.addEventListener("keydown", e => {
            if (!qv.classList.contains("open")) return;
            if (e.key === "ArrowLeft") qvStep(-1);
            if (e.key === "ArrowRight") qvStep(1);
            if (e.key === "Escape") closeQuickView();
        });
        return qv;
    }

    function openQuickView({ mediaHtml, cat, title, desc, stats, goLabel, goHref, actions }) {
        const qv = ensureQuickView();
        qv.querySelector(".qv-media").innerHTML = mediaHtml || "";
        qv.querySelector(".qv-cat").textContent = cat || "";
        qv.querySelector(".qv-title").textContent = title || "";
        qv.querySelector(".qv-desc").textContent = desc || "";
        qv.querySelector(".qv-stats").innerHTML = stats || "";

        // 액션 버튼 (좋아요/저장 등)
        const actWrap = qv.querySelector(".qv-actions");
        actWrap.innerHTML = "";
        (actions || []).forEach(a => {
            const b = document.createElement("button");
            b.className = "qv-act" + (a.active ? " on" : "");
            b.innerHTML = a.label;
            b.onclick = async () => {
                b.disabled = true;
                try { await a.onClick(b); } finally { b.disabled = false; }
            };
            actWrap.appendChild(b);
        });
        // 공유 버튼 (항상, 저장 옆)
        const shareBtn = document.createElement("button");
        shareBtn.className = "qv-act qv-share";
        shareBtn.innerHTML = SHARE_ICON + '<span class="qv-act-txt">공유</span>';
        shareBtn.onclick = async () => {
            const url = new URL(goHref, location.href).href;
            if (navigator.share) {
                try { await navigator.share({ title: title || "GALLA", url }); return; }
                catch (err) { if (err.name === "AbortError") return; }
            }
            try { await navigator.clipboard.writeText(url); alert("링크가 복사되었습니다."); }
            catch { alert("링크 복사에 실패했습니다."); }
        };
        actWrap.appendChild(shareBtn);

        const go = qv.querySelector(".qv-go");
        go.textContent = goLabel || "원본으로 이동";
        go.onclick = () => location.href = goHref;

        // 이전/다음 버튼 표시 여부
        qv.querySelector(".qv-prev").style.visibility = QV_INDEX > 0 ? "visible" : "hidden";
        qv.querySelector(".qv-next").style.visibility = QV_INDEX < QV_ITEMS.length - 1 ? "visible" : "hidden";

        qv.classList.add("open");
        document.body.style.overflow = "hidden";
    }

    const qvImg = (src) => src
        ? `<img src="${src}" onerror="this.src='./assets/logo.png'">`
        : `<img src="./assets/logo.png">`;

    // 타입별 퀵뷰 (필요 데이터 lazy 조회)
    async function quickViewIssue(issueId) {
        const [{ data: i }, { data: bm }] = await Promise.all([
            supabase.from("issues")
                .select("id,title,category,thumbnail_url,images,video_url,pro_count,con_count,faction_a,faction_b")
                .eq("id", issueId).maybeSingle(),
            supabase.from("bookmarks")
                .select("issue_id").eq("user_id", userId).eq("issue_id", issueId).maybeSingle()
        ]);
        if (!i) { location.href = `issue.html?id=${issueId}`; return; }
        const thumb = i.thumbnail_url || (Array.isArray(i.images) && i.images[0]) || null;
        const media = i.video_url
            ? `<video src="${i.video_url}" controls playsinline preload="metadata"></video>`
            : qvImg(thumb);

        let saved = !!bm;
        openQuickView({
            mediaHtml: media,
            cat: i.category || "",
            title: i.title,
            desc: "",
            stats: `<span>${i.faction_a || "찬성"} ${i.pro_count || 0}</span> · <span>${i.faction_b || "반대"} ${i.con_count || 0}</span>`,
            actions: [{
                label: BM_ICON + '<span class="qv-act-txt">' + (saved ? "저장됨" : "저장") + '</span>',
                active: saved,
                onClick: async (btn) => {
                    if (saved) {
                        await supabase.from("bookmarks").delete()
                            .eq("user_id", userId).eq("issue_id", issueId);
                    } else {
                        await supabase.from("bookmarks").insert({ user_id: userId, issue_id: issueId });
                    }
                    saved = !saved;
                    btn.querySelector(".qv-act-txt").textContent = saved ? "저장됨" : "저장";
                    btn.classList.toggle("on", saved);
                    qvDirty = true;
                }
            }],
            goLabel: "이슈에서 참전하기",
            goHref: `issue.html?id=${i.id}`
        });
    }

    async function quickViewNews(newsId) {
        const [{ data: n }, { data: bm }, { data: rx }] = await Promise.all([
            supabase.from("galla_news")
                .select("id,title,summary,category,hero_image,source_count")
                .eq("id", newsId).maybeSingle(),
            supabase.from("galla_news_bookmarks")
                .select("news_id").eq("user_id", userId).eq("news_id", newsId).maybeSingle(),
            supabase.from("galla_news_reactions")
                .select("value").eq("user_id", userId).eq("news_id", newsId).maybeSingle()
        ]);
        if (!n) { location.href = `search.html?gn=${newsId}`; return; }

        let liked = rx?.value === 1;
        let saved = !!bm;
        openQuickView({
            mediaHtml: qvImg(n.hero_image),
            cat: `${n.category || ""} · 갈라뉴스`,
            title: n.title,
            desc: n.summary || "",
            stats: n.source_count ? `<span>출처 ${n.source_count}곳 종합</span>` : "",
            actions: [
                {
                    label: liked ? "👍 좋아요 취소" : "👍 좋아요",
                    active: liked,
                    onClick: async (btn) => {
                        if (liked) {
                            await supabase.from("galla_news_reactions").delete()
                                .eq("user_id", userId).eq("news_id", newsId);
                        } else {
                            await supabase.from("galla_news_reactions")
                                .upsert({ news_id: newsId, user_id: userId, value: 1 }, { onConflict: "news_id,user_id" });
                        }
                        liked = !liked;
                        btn.textContent = liked ? "👍 좋아요 취소" : "👍 좋아요";
                        btn.classList.toggle("on", liked);
                    }
                },
                {
                    label: BM_ICON + '<span class="qv-act-txt">' + (saved ? "저장됨" : "저장") + '</span>',
                    active: saved,
                    onClick: async (btn) => {
                        if (saved) {
                            await supabase.from("galla_news_bookmarks").delete()
                                .eq("user_id", userId).eq("news_id", newsId);
                        } else {
                            await supabase.from("galla_news_bookmarks").insert({ news_id: newsId, user_id: userId });
                        }
                        saved = !saved;
                        btn.querySelector(".qv-act-txt").textContent = saved ? "저장됨" : "저장";
                        btn.classList.toggle("on", saved);
                        qvDirty = true;
                    }
                }
            ],
            goLabel: "기사 전체 읽기",
            goHref: `search.html?gn=${n.id}`
        });
    }

    async function quickViewPlaza(postId) {
        const [{ data: p }, { data: bm }] = await Promise.all([
            supabase.from("plaza_posts")
                .select("id,title,body,category,cover_image,thumbnail,up_count,down_count,view_count")
                .eq("id", postId).maybeSingle(),
            supabase.from("plaza_bookmarks")
                .select("post_id").eq("user_id", userId).eq("post_id", postId).maybeSingle()
        ]);
        if (!p) { location.href = `plaza_detail.html?id=${postId}`; return; }
        // 본문 미리보기: 마커 제거 후 앞 120자
        const plain = (p.body || "").replace(/\[(IMAGE|VIDEO|EMBED)\]\S+/g, "").replace(/\s+/g, " ").trim();

        let saved = !!bm;
        openQuickView({
            mediaHtml: qvImg(p.cover_image || p.thumbnail),
            cat: `${p.category || ""} · 갈라 광장`,
            title: p.title,
            desc: plain.slice(0, 120) + (plain.length > 120 ? "…" : ""),
            stats: `<span>추천 ${p.up_count || 0}</span> · <span>비추 ${p.down_count || 0}</span> · <span>조회 ${p.view_count || 0}</span>`,
            actions: [{
                label: BM_ICON + '<span class="qv-act-txt">' + (saved ? "저장됨" : "저장") + '</span>',
                active: saved,
                onClick: async (btn) => {
                    if (saved) {
                        await supabase.from("plaza_bookmarks").delete()
                            .eq("user_id", userId).eq("post_id", postId);
                    } else {
                        await supabase.from("plaza_bookmarks").insert({ post_id: postId, user_id: userId });
                    }
                    saved = !saved;
                    btn.querySelector(".qv-act-txt").textContent = saved ? "저장됨" : "저장";
                    btn.classList.toggle("on", saved);
                    qvDirty = true;
                }
            }],
            goLabel: "광장에서 보기",
            goHref: `plaza_detail.html?id=${p.id}`
        });
    }

    async function quickViewMarket(marketId) {
        const [{ data: m }, { data: bm }] = await Promise.all([
            supabase.from("markets")
                .select("id,question,category,image_url,volume,market_type,resolved,close_at")
                .eq("id", marketId).maybeSingle(),
            supabase.from("market_bookmarks")
                .select("market_id").eq("user_id", userId).eq("market_id", marketId).maybeSingle()
        ]);
        if (!m) { location.href = `predict-market.html?id=${marketId}`; return; }

        // 대표 선택지 확률
        let topLine = "";
        const { data: outs } = await supabase.from("market_outcomes")
            .select("label,pool_yes,pool_no,sort_order").eq("market_id", marketId);
        if (outs && outs.length) {
            const top = outs.map(o => ({
                label: o.label,
                p: Math.round(o.pool_no / (o.pool_yes + o.pool_no) * 100)
            })).sort((a, b) => b.p - a.p)[0];
            if (top) topLine = `<span><b>${top.p}%</b> ${top.label}</span> · `;
        }

        let saved = !!bm;
        openQuickView({
            mediaHtml: m.image_url ? qvImg(m.image_url) : "",
            cat: `${m.category || ""} · 갈라예측${m.market_type === "multi" ? " · 여러 선택지" : ""}`,
            title: m.question,
            desc: "",
            stats: `${topLine}<span>거래량 ${Math.round(m.volume || 0).toLocaleString("ko-KR")}P</span>${m.resolved ? " · <span>정산 완료</span>" : ""}`,
            actions: [{
                label: BM_ICON + '<span class="qv-act-txt">' + (saved ? "저장됨" : "저장") + '</span>',
                active: saved,
                onClick: async (btn) => {
                    if (saved) {
                        await supabase.from("market_bookmarks").delete()
                            .eq("user_id", userId).eq("market_id", marketId);
                    } else {
                        await supabase.from("market_bookmarks").insert({ market_id: marketId, user_id: userId });
                    }
                    saved = !saved;
                    btn.querySelector(".qv-act-txt").textContent = saved ? "저장됨" : "저장";
                    btn.classList.toggle("on", saved);
                    qvDirty = true;
                }
            }],
            goLabel: "예측하러 가기",
            goHref: `predict-market.html?id=${m.id}`
        });
    }

    // =====================================================
    // 인스타 그리드 카드 (정사각 썸네일 + 하단 타이틀 오버레이)
    // =====================================================
    const igCard = ({ thumb, title, badge, onClick }) => {
        const card = document.createElement("div");
        card.className = "ig-card";
        card.innerHTML = `
            <img src="${(window.GALLA_thumb ? window.GALLA_thumb(thumb, 480) : thumb) || "./assets/logo.png"}" loading="lazy"
                 onerror="this.src='./assets/logo.png'">
            ${badge ? `<span class="ig-badge">${badge}</span>` : ""}
            <div class="ig-title">${title || ""}</div>
        `;
        card.onclick = onClick;
        return card;
    };

    // 텍스트 중심 콘텐츠(예측·뉴스·광장)용 리스트 로우 — 썸네일 좌측 + 제목·메타 우측(가독성↑)
    const mpEsc = (s) => String(s ?? "").replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
    const mpRow = ({ thumb, kind, title, meta, onClick }) => {
        const row = document.createElement("div");
        row.className = "mp-row";
        const th = thumb
            ? `<img src="${mpEsc(window.GALLA_thumb ? window.GALLA_thumb(thumb, 240) : thumb)}" loading="lazy" referrerpolicy="no-referrer" onerror="this.closest('.mp-row-th').classList.add('noimg')">`
            : "";
        row.innerHTML = `
            <span class="mp-row-th${thumb ? "" : " noimg"}" data-kind="${mpEsc(kind || "")}">${th}</span>
            <span class="mp-row-main">
                <span class="mp-row-title">${mpEsc(title || "(제목 없음)")}</span>
                ${meta ? `<span class="mp-row-meta">${meta}</span>` : ""}
            </span>
            <span class="mp-row-go">›</span>`;
        row.onclick = onClick;
        return row;
    };
    const mpAgo = (iso) => {
        if (!iso) return "";
        const s = (Date.now() - new Date(iso).getTime()) / 1000;
        if (s < 3600) return Math.max(1, Math.floor(s / 60)) + "분 전";
        if (s < 86400) return Math.floor(s / 3600) + "시간 전";
        if (s < 2592000) return Math.floor(s / 86400) + "일 전";
        return new Date(iso).toLocaleDateString("ko-KR", { year: "2-digit", month: "2-digit", day: "2-digit" });
    };

    const emptyMsg = (msg) => `
        <div class="tab-empty" style="color:#777;font-size:14px;padding:24px 16px;">${msg}</div>`;

    // =====================================================
    // Save 갈라 — 내가 북마크한 이슈 (인스타 그리드)
    // =====================================================
    const renderSave = async () => {
        if (!tabContent.firstElementChild) tabContent.className = "content-area"; // 스냅샷 유지 중 grid 박탈 금지
        if (!isMyPage) {
            tabContent.innerHTML = emptyMsg("저장한 갈라는 본인만 볼 수 있습니다.");
            return;
        }

        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        // Save 갈라 = 저장한 이슈 (예측은 My 예측, 광장은 My 광장에서)
        const { data: ibm } = await supabase
            .from("bookmarks")
            .select("issue_id, created_at")
            .eq("user_id", userId)
            .order("created_at", { ascending: false });

        if (!ibm || !ibm.length) {
            tabContent.innerHTML = emptyMsg("저장한 갈라가 없습니다.<br>피드에서 북마크를 눌러 저장해보세요.");
            return;
        }

        const issueIds = ibm.map(b => b.issue_id);
        const { data: issues } = await supabase
            .from("issues")
            .select("id, title, thumbnail_url, video_url, images")
            .in("id", issueIds);

        const iMap = {};
        (issues || []).forEach(i => iMap[i.id] = i);

        tabContent.className = "content-area grid";
        tabContent.innerHTML = "";

        const liveIds = issueIds.filter(id => iMap[id]);
        const qvItems = liveIds.map(id => ({ type: "issue", id }));

        liveIds.forEach((id, myIdx) => {
            const i = iMap[id];
            tabContent.appendChild(igCard({
                thumb: i.thumbnail_url || (Array.isArray(i.images) && i.images[0]) || null,
                title: i.title,
                badge: i.video_url ? "▶" : "",
                onClick: () => openQvList(qvItems, myIdx)
            }));
        });
    };

    // =====================================================
    // 갈라 탭 — My 갈라 / Saved 갈라 서브탭 (mpSubBar 사용)
    // =====================================================
    let gallaSubTab = "mine"; // mine | saved
    const clearSubBar = () => { const s = byId("mpSubBar"); if (s) s.innerHTML = ""; };
    /* 서브탭을 갈라 탭과 '같은 위치'(#mpSubBar)에 그린다 — 예측·광장이
       tabContent 안에 그려 위치가 어긋나던 문제(사장님). onSwitch로 재렌더 */
    const paintSubBar = (active, tabs, onSwitch) => {
        const subBar = byId("mpSubBar");
        if (!subBar) return;
        if (!isMyPage) { subBar.innerHTML = ""; return; }
        subBar.innerHTML = `<div class="mp-subtabs">${tabs.map(t =>
            `<button class="mp-subtab ${active === t.k ? "active" : ""}" data-sub="${t.k}">${t.label}</button>`).join("")}</div>`;
        subBar.querySelector(".mp-subtabs").onclick = e => {
            const b = e.target.closest(".mp-subtab");
            if (!b || b.dataset.sub === active) return;
            onSwitch(b.dataset.sub);
        };
    };
    const renderGalla = () => {
        // 저장(Saved)은 설정 › 보관으로 이동 — 마이페이지는 '내가 만든 것'만
        clearSubBar();
        renderMy();
    };

    // =====================================================
    // My 예측 — 내가 만든 예측 / 저장한 예측 (서브탭 + 그리드)
    // =====================================================
    let predictSubTab = "mine"; // mine | saved

    const renderPredict = async () => {
        // 스냅샷 그리드가 떠 있는 동안 grid 클래스를 벗기면 첫 사진이 전체 폭으로 터진다(사장님 재현)
        if (!tabContent.firstElementChild) tabContent.className = "content-area";
        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        // 저장은 설정 › 보관으로 — 내가 만든 예측만
        clearSubBar();
        predictSubTab = "mine";

        let markets = [];
        if (predictSubTab === "mine") {
            const { data, error } = await supabase
                .from("markets")
                .select("id, question, image_url, created_at")
                .eq("created_by", viewUserId)
                .order("created_at", { ascending: false });
            if (error) {
                console.error("[My Predict] error", error);
                tabContent.innerHTML = emptyMsg("불러오기 실패");
                return;
            }
            markets = data || [];
        } else {
            const { data: bms, error } = await supabase
                .from("market_bookmarks")
                .select("market_id, created_at")
                .eq("user_id", userId)
                .order("created_at", { ascending: false });
            if (error) {
                console.error("[Saved Predict] error", error);
                tabContent.innerHTML = emptyMsg("불러오기 실패");
                return;
            }
            const ids = (bms || []).map(b => b.market_id);
            if (ids.length) {
                const { data: rows } = await supabase
                    .from("markets")
                    .select("id, question, image_url, created_at")
                    .in("id", ids);
                const map = {};
                (rows || []).forEach(m => map[m.id] = m);
                markets = ids.map(id => map[id]).filter(Boolean); // 저장순 유지
            }
        }

        tabContent.className = "content-area";
        tabContent.innerHTML = "";

        if (!markets.length) {
            const empty = document.createElement("div");
            empty.innerHTML = emptyMsg(predictSubTab === "mine"
                ? "아직 만든 예측이 없습니다."
                : "저장한 예측이 없습니다.<br>예측 상세에서 저장을 눌러보세요.");
            tabContent.appendChild(empty);
            return;
        }

        const list = document.createElement("div");
        list.className = "mp-list";
        tabContent.appendChild(list);

        const qvItems = markets.map(m => ({ type: "market", id: m.id }));
        markets.forEach((m, myIdx) => {
            list.appendChild(mpRow({
                thumb: m.image_url,
                kind: "🔮",
                title: m.question,
                meta: `<span class="mp-row-tag predict">🔮 갈라예측</span> ${mpAgo(m.created_at)}`,
                onClick: () => openQvList(qvItems, myIdx)
            }));
        });
    };

    // =====================================================
    // 저장한 뉴스 — 갈라뉴스 북마크 (인스타 그리드)
    // =====================================================
    const renderNews = async () => {
        if (!tabContent.firstElementChild) tabContent.className = "content-area"; // 스냅샷 유지 중 grid 박탈 금지
        if (!isMyPage) {
            tabContent.innerHTML = emptyMsg("저장한 뉴스는 본인만 볼 수 있습니다.");
            return;
        }

        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        const { data: bms, error: bmErr } = await supabase
            .from("galla_news_bookmarks")
            .select("news_id, created_at")
            .eq("user_id", userId)
            .order("created_at", { ascending: false });

        if (bmErr) {
            console.error("[Saved News] error", bmErr);
            tabContent.innerHTML = emptyMsg("불러오기 실패");
            return;
        }

        if (!bms || bms.length === 0) {
            tabContent.innerHTML = emptyMsg("저장한 뉴스가 없습니다.<br>갈라뉴스에서 저장을 눌러보세요.");
            return;
        }

        const newsIds = bms.map(b => b.news_id);
        const { data: newsRows } = await supabase
            .from("galla_news")
            .select("id, title, hero_image, category, published_at")
            .in("id", newsIds);

        const newsMap = {};
        (newsRows || []).forEach(n => newsMap[n.id] = n);

        tabContent.className = "content-area";
        tabContent.innerHTML = "";
        const list = document.createElement("div");
        list.className = "mp-list";
        tabContent.appendChild(list);

        const qvItems = newsIds.filter(id => newsMap[id]).map(id => ({ type: "news", id }));
        let idx = 0;
        newsIds.forEach(id => {
            const n = newsMap[id];
            if (!n) return;
            const myIdx = idx++;
            list.appendChild(mpRow({
                thumb: n.hero_image,
                kind: "📰",
                title: n.title,
                meta: `<span class="mp-row-tag news">📰 갈라뉴스</span> ${n.category ? mpEsc(n.category) + " · " : ""}${mpAgo(n.published_at)}`,
                onClick: () => openQvList(qvItems, myIdx)
            }));
        });
    };

    // =====================================================
    // My 광장 — 내가 쓴 글 / 저장한 글 (서브탭 + 인스타 그리드)
    // =====================================================
    let plazaSubTab = "mine"; // mine | saved

    const renderPlaza = async () => {
        // 스냅샷 그리드가 떠 있는 동안 grid 클래스를 벗기면 첫 사진이 전체 폭으로 터진다(사장님 재현)
        if (!tabContent.firstElementChild) tabContent.className = "content-area";
        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        // 저장은 설정 › 보관으로 — 내가 쓴 글만
        clearSubBar();
        plazaSubTab = "mine";

        let posts = [];
        if (plazaSubTab === "mine") {
            const { data, error } = await supabase
                .from("plaza_posts")
                .select("id, title, thumbnail, cover_image, created_at")
                .eq("user_id", viewUserId)
                .order("created_at", { ascending: false });
            if (error) {
                console.error("[My Plaza] error", error);
                tabContent.innerHTML = emptyMsg("불러오기 실패");
                return;
            }
            posts = data || [];
        } else {
            const { data: bms, error } = await supabase
                .from("plaza_bookmarks")
                .select("post_id, created_at")
                .eq("user_id", userId)
                .order("created_at", { ascending: false });
            if (error) {
                console.error("[Saved Plaza] error", error);
                tabContent.innerHTML = emptyMsg("불러오기 실패");
                return;
            }
            const ids = (bms || []).map(b => b.post_id);
            if (ids.length) {
                const { data: rows } = await supabase
                    .from("plaza_posts")
                    .select("id, title, thumbnail, cover_image, created_at")
                    .in("id", ids);
                const map = {};
                (rows || []).forEach(p => map[p.id] = p);
                posts = ids.map(id => map[id]).filter(Boolean); // 저장순 유지
            }
        }

        // 서브탭 바 + 그리드 컨테이너
        tabContent.className = "content-area";
        tabContent.innerHTML = "";

        if (!posts.length) {
            const empty = document.createElement("div");
            empty.innerHTML = emptyMsg(plazaSubTab === "mine"
                ? "아직 갈라 광장에 쓴 글이 없습니다."
                : "저장한 광장 글이 없습니다.<br>광장에서 북마크를 눌러 저장해보세요.");
            tabContent.appendChild(empty);
            return;
        }

        const list = document.createElement("div");
        list.className = "mp-list";
        tabContent.appendChild(list);

        const qvItems = posts.map(p => ({ type: "plaza", id: p.id }));
        posts.forEach((p, myIdx) => {
            list.appendChild(mpRow({
                thumb: p.cover_image || p.thumbnail,
                kind: "🏛",
                title: p.title,
                meta: `<span class="mp-row-tag plaza">🏛 광장</span> ${mpAgo(p.created_at)}`,
                onClick: () => openQvList(qvItems, myIdx)
            }));
        });
    };

    // =====================================================
    // 즐겨찾기 — 나를 팔로우하는 사용자
    // =====================================================
    const renderFollower = async () => {
        // 스냅샷 그리드가 떠 있는 동안 grid 클래스를 벗기면 첫 사진이 전체 폭으로 터진다(사장님 재현)
        if (!tabContent.firstElementChild) tabContent.className = "content-area";
        if (!tabContent.firstElementChild) tabContent.innerHTML = MP_SPINNER; // 스냅샷 표시 중엔 덮지 않음, 빈 영역은 스피너(사장님 지시)

        const { data: follows, error: followError } = await supabase
            .from("follows")
            .select("follower")
            .eq("following", viewUserId)
            .order("created_at", { ascending: false });

        if (followError) {
            console.error("[Follower] follows error", followError);
            tabContent.innerHTML = emptyMsg("불러오기 실패");
            return;
        }

        if (!follows || follows.length === 0) {
            tabContent.innerHTML = emptyMsg("아직 팔로워가 없습니다.");
            return;
        }

        const followerIds = follows.map(f => f.follower);
        const { data: followUsers, error: usersError } = await supabase
            .from("users")
            .select("id, nickname, level, avatar_url")
            .in("id", followerIds);

        if (usersError) {
            console.error("[Follower] users error", usersError);
            tabContent.innerHTML = emptyMsg("불러오기 실패");
            return;
        }

        const userMap = {};
        (followUsers || []).forEach(u => userMap[u.id] = u);

        tabContent.innerHTML = "";

        followerIds.forEach(fid => {
            const u = userMap[fid];
            if (!u) return;

            const avatarSrc = window.GALLA_avatarSrc(u.avatar_url, 96);

            const row = document.createElement("div");
            row.className = "user-row";
            row.innerHTML = `
                <img class="user-row-avatar" src="${avatarSrc}" onerror="this.onerror=null;this.src=window.GALLA_DEFAULT_AVATAR">
                <div class="user-row-info">
                    <div class="user-row-name" data-nick-uid="${u.id}">${u.nickname || "익명의 사용자"}</div>
                    <div class="user-row-level">Lv. ${u.level || 1}</div>
                </div>
            `;
            row.onclick = () => {
                // SPA: 문서 이탈 없이 스택 push(이탈 시 nav.js 셸 복귀가 ?user를 버림). MPA 기존 유지.
                if (document.body.dataset.page === "spa" && window.GALLA_gotoProfile) { window.GALLA_gotoProfile(u.id); return; }
                location.href = `mypage.html?user=${u.id}`;
            };
            tabContent.appendChild(row);
        });
    };

    // =====================================================
    // 탭 카운트 뱃지 (Save/뉴스/팔로워)
    // =====================================================
    async function loadTabCounts() {
        const setCount = (tabName, n) => {
            const el = D.querySelector(`.tab[data-tab=""]`);
            if (el && typeof n === "number") {
                el.innerHTML = el.innerHTML.replace(/ <span class="tab-count">.*<\/span>/, "")
                    + ` <span class="tab-count">${n}</span>`;
            }
        };
        let savedPlaza = 0, savedMarkets = 0;
        if (isMyPage) {
            const [{ count: bm }, { count: nbm }, { count: mbm }, { count: pbm }] = await Promise.all([
                supabase.from("bookmarks").select("issue_id", { count: "exact", head: true }).eq("user_id", userId),
                supabase.from("galla_news_bookmarks").select("news_id", { count: "exact", head: true }).eq("user_id", userId),
                supabase.from("market_bookmarks").select("market_id", { count: "exact", head: true }).eq("user_id", userId),
                supabase.from("plaza_bookmarks").select("post_id", { count: "exact", head: true }).eq("user_id", userId)
            ]);
            setCount("save", bm ?? 0); // 이슈만 (예측/광장은 각자 탭)
            setCount("news", nbm ?? 0);
            savedMarkets = mbm ?? 0;
            savedPlaza = pbm ?? 0;
        }
        const [{ count: pz }, { count: mk }] = await Promise.all([
            supabase.from("plaza_posts").select("id", { count: "exact", head: true }).eq("user_id", viewUserId),
            supabase.from("markets").select("id", { count: "exact", head: true }).eq("created_by", viewUserId)
        ]);
        setCount("plaza", (pz ?? 0) + savedPlaza);
        setCount("predict", (mk ?? 0) + savedMarkets);
        const { count: fl } = await supabase
            .from("follows").select("id", { count: "exact", head: true }).eq("following", viewUserId);
        setCount("follower", fl ?? 0);
    }
    loadTabCounts();

    // 👥 팔로워 실시간 — 누가 나를 팔로우/언팔하면 카운트(⚡전적·탭 뱃지)·목록을 즉시 반영.
    //    내 마이페이지 한정(keep-alive 단일 인스턴스 → 채널 누수 없음). follows publication 공유.
    (function attachFollowerRealtime() {
        if (!isMyPage || !supabase || !supabase.channel || !viewUserId) return;
        window.__mpFollowerRT = window.__mpFollowerRT || {};
        if (window.__mpFollowerRT[viewUserId]) return;
        window.__mpFollowerRT[viewUserId] = true;
        supabase.channel("mp-followers-" + viewUserId)
            .on("postgres_changes",
                { event: "*", schema: "public", table: "follows", filter: "following=eq." + viewUserId },
                async () => {
                    const { count } = await supabase.from("follows")
                        .select("id", { count: "exact", head: true }).eq("following", viewUserId);
                    const n = count ?? 0;
                    const stat = D.querySelector("#statFollowers");
                    if (stat) stat.textContent = n;
                    const ftab = D.querySelector('.tab[data-tab="follower"]');
                    if (ftab) ftab.innerHTML = ftab.innerHTML.replace(/ <span class="tab-count">.*<\/span>/, "") + ` <span class="tab-count">${n}</span>`;
                    if (ftab && ftab.classList.contains("active") && typeof renderFollower === "function") renderFollower();
                })
            .subscribe();
    })();

    // ---------------------------
    // 갈라리(콘텐츠) 탭 — 세로 3열 그리드 / 가로 유튜브 리스트 분배
    // ---------------------------
    // 숏판/롱판 = 각각 독립 탭. 저장 서브탭 없이 '내가 올린 것'만, 단일 kind 렌더.
    const renderContent = async (kind) => {
        kind = kind === "horizontal" ? "horizontal" : "vertical";
        clearSubBar();
        tabContent.className = "content-area";
        tabContent.innerHTML = MP_SPINNER;
        const { data: posts } = await supabase.from("posts")
            .select("id,kind,title,caption,images,video_url,thumbnail_url,like_count,comment_count")
            .eq("user_id", viewUserId).eq("kind", kind).eq("is_published", true)
            .order("created_at", { ascending: false }).limit(60);
        const items = posts || [];
        const esc = s => (s == null ? "" : String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])));
        const thumb = p => p.thumbnail_url || (Array.isArray(p.images) && p.images[0]) || "";
        let inner;
        if (!items.length) inner = `<div class="glf-empty">아직 ${kind === "vertical" ? "⚡ 숏판" : "🎬 롱판"} 콘텐츠가 없어요.</div>`;
        else if (kind === "vertical") inner = '<div class="glf-grid">' + items.map(p =>
            `<div class="glf-tile" data-id="${p.id}">${thumb(p) ? `<img src="${esc(thumb(p))}" loading="lazy">` : '<div style="width:100%;height:100%;background:#141420"></div>'}
             ${p.video_url ? '<span class="glf-play">▶</span>' : ''}<div class="glf-meta"><span>♥ ${p.like_count || 0}</span></div></div>`).join("") + "</div>";
        else inner = '<div class="glf-list">' + items.map(p =>
            `<div class="glf-card" data-id="${p.id}"><div class="glf-thumb">${thumb(p) ? `<img src="${esc(thumb(p))}" loading="lazy">` : '<div style="width:100%;height:100%;background:#141420"></div>'}</div>
             <div class="glf-cbody"><div class="glf-cinfo"><div class="glf-ctitle">${esc(p.title || p.caption || "(제목 없음)")}</div><div class="glf-cmeta">♥ ${p.like_count || 0} · 💬 ${p.comment_count || 0}</div></div></div></div>`).join("") + "</div>";
        tabContent.innerHTML = inner;
        tabContent.querySelectorAll("[data-id]").forEach(el => el.addEventListener("click", () =>
            // 숏판 = 릴스로(이 사람 숏판만 순차), 롱판 = 유튜브식 상세로
            (window.GALLA_nav || function (u) { location.href = u; })(
                kind === "vertical" ? "gallari-reels.html?start=" + el.dataset.id + "&t=post&user=" + viewUserId : "gallari-post.html?id=" + el.dataset.id)));
    };

    // ---------------------------
    // 모아 — 내 모든 콘텐츠 통합 그리드(갈라·숏판·롱판·예측·광장). 이모지 아이콘 없이 텍스트 라벨.
    // ---------------------------
    const ALL_TYPES = {
        issue:   { label: "갈라", dest: id => "issue.html?id=" + id },
        short:   { label: "숏판", dest: id => "gallari-reels.html?user=" + viewUserId + "&start=" + id + "&t=post" },
        long:    { label: "롱판", dest: id => "gallari-post.html?id=" + id },
        predict: { label: "예측", dest: id => "predict-market.html?id=" + id },
        plaza:   { label: "광장", dest: id => "plaza_detail.html?id=" + id },
    };
    const PLAY_SVG = '<svg viewBox="0 0 24 24" fill="#fff"><path d="M8 5v14l11-7z"/></svg>';

    // ── 모아 = 유튜브 채널 페이지식 섹션 레이아웃 ──
    // 숏판=Shorts 그리드(세로 썸네일), 롱판=동영상 리스트(16:9), 갈라·예측·광장=리스트 행.
    const renderAll = async () => {
        clearSubBar();
        tabContent.className = "content-area";
        tabContent.innerHTML = MP_SPINNER;
        const esc = s => (s == null ? "" : String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])));
        const views = n => { n = +n || 0; if (n >= 10000) return "조회수 " + (n / 10000).toFixed(n >= 100000 ? 0 : 1).replace(/\.0$/, "") + "만회"; if (n >= 1000) return "조회수 " + (n / 1000).toFixed(1).replace(/\.0$/, "") + "천회"; return "조회수 " + n + "회"; };
        const ago = ts => {
            const d = Math.floor((Date.now() - new Date(ts)) / 1000);
            if (d < 60) return "방금"; if (d < 3600) return Math.floor(d / 60) + "분 전";
            if (d < 86400) return Math.floor(d / 3600) + "시간 전"; if (d < 2592000) return Math.floor(d / 86400) + "일 전";
            if (d < 31536000) return Math.floor(d / 2592000) + "개월 전"; return Math.floor(d / 31536000) + "년 전";
        };
        const [iss, pst, mkt, plz] = await Promise.all([
            supabase.from("issues").select("id,title,thumbnail_url,card_thumb_url,images,created_at").eq("user_id", viewUserId).order("created_at", { ascending: false }).limit(6),
            supabase.from("posts").select("id,kind,title,caption,thumbnail_url,images,video_url,view_count,created_at").eq("user_id", viewUserId).eq("is_published", true).order("created_at", { ascending: false }).limit(40),
            supabase.from("markets").select("id,question,image_url,created_at").eq("created_by", viewUserId).order("created_at", { ascending: false }).limit(6),
            supabase.from("plaza_posts").select("id,title,thumbnail,cover_image,view_count,created_at").eq("user_id", viewUserId).order("created_at", { ascending: false }).limit(6),
        ]);
        const pdata = pst.data || [];
        const shorts = pdata.filter(r => r.kind !== "horizontal").slice(0, 6);
        const longs = pdata.filter(r => r.kind === "horizontal").slice(0, 6);
        const issues = iss.data || [], markets = mkt.data || [], plazas = plz.data || [];
        if (!(issues.length + pdata.length + markets.length + plazas.length)) {
            tabContent.innerHTML = emptyMsg("아직 올린 콘텐츠가 없어요."); return;
        }

        const firstImg = v => Array.isArray(v) ? (typeof v[0] === "string" ? v[0] : (v[0] && (v[0].url || v[0].src))) : "";
        // ⚠️ card_thumb_url(작성 때 고른 '대표 썸네일 3:4 — 마이페이지 카드에 노출') 최우선.
        //    thumbnail_url은 영상 자동프레임이라 대표썸네일이 있으면 그게 아니라 대표썸네일을 써야 한다.
        const thumbOf = r => r.card_thumb_url || r.thumbnail_url || r.image_url || r.thumbnail || r.cover_image || firstImg(r.images) || "";
        // 썸네일 <img> — CDN 리사이즈(GALLA_thumb) + 로드 실패 시 자동 제거(placeholder 배경 노출)
        const art = (url, w) => `<img src="${esc(window.GALLA_thumb ? window.GALLA_thumb(url, w || 640) : url)}" loading="lazy" onerror="this.remove()">`;
        // 섹션 헤더 — 누르면 해당 탭으로 이동(› 표시). tab = .tab[data-tab] 키
        const head = (label, tab) => `<h3 class="mp-yt-h" data-gototab="${tab}">${label}<span class="mp-yt-more">›</span></h3>`;
        // 세로폼 그리드(9:16) — 갈라·숏판 공용. sub는 선택(조회수 등)
        const vGrid = (label, tab, t, rows, capOf, subOf) => {
            const cells = rows.map(r => {
                const th = thumbOf(r);
                return `<div class="mp-sh-cell" data-t="${t}" data-id="${r.id}">
                    ${th ? art(th) : `<div class="mp-yt-ph"></div>`}
                    <span class="mp-sh-cap">${esc(capOf(r) || "")}</span>
                    ${subOf ? `<span class="mp-sh-v">${esc(subOf(r))}</span>` : ""}
                </div>`;
            }).join("");
            return `<section class="mp-yt-sec">${head(label, tab)}<div class="mp-sh-grid">${cells}</div></section>`;
        };
        // 애플 뮤직식 리스트 — 예측·광장 공용(작은 아트워크 + 제목 + 서브). 썸네일 없으면 유형 글리프.
        const GLYPH = {
            predict: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3 17l6-6 4 4 7-7"/><path d="M17 7h4v4"/></svg>',
            plaza: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/></svg>',
        };
        const listRows = (label, tab, t, rows, titleOf, metaOf) => {
            const html = rows.map(r => {
                const th = thumbOf(r);
                const artHtml = th ? art(th, 160) : `<div class="mp-am-ph">${GLYPH[t] || ""}</div>`;
                return `<div class="mp-am-row" data-t="${t}" data-id="${r.id}">
                    <div class="mp-am-art">${artHtml}</div>
                    <div class="mp-am-info"><div class="mp-am-tt">${esc(titleOf(r) || "제목 없음")}</div><div class="mp-am-sub">${esc(metaOf(r))}</div></div>
                </div>`;
            }).join("");
            return `<section class="mp-yt-sec">${head(label, tab)}<div class="mp-am-list">${html}</div></section>`;
        };

        const sections = [];
        // 순서: 갈라 → 숏판 → 롱판 → 예측 → 광장 (각 최신 6개)
        if (issues.length) sections.push(vGrid("갈라", "galla", "issue", issues, r => r.title));
        if (shorts.length) sections.push(vGrid("숏판", "short", "short", shorts, r => r.title || r.caption, r => views(r.view_count)));
        if (longs.length) {
            const rows = longs.map(r =>
                `<div class="mp-lv" data-t="long" data-id="${r.id}">
                    <div class="mp-lv-th">${thumbOf(r) ? art(thumbOf(r), 720) : `<div class="mp-yt-ph"></div>`}<span class="mp-lv-play">${PLAY_SVG}</span></div>
                    <div class="mp-lv-tt">${esc(r.title || r.caption || "제목 없음")}</div>
                    <div class="mp-lv-meta">${views(r.view_count)} · ${ago(r.created_at)}</div>
                </div>`).join("");
            sections.push(`<section class="mp-yt-sec">${head("롱판", "long")}<div class="mp-lv-list">${rows}</div></section>`);
        }
        if (markets.length) sections.push(listRows("예측", "predict", "predict", markets, r => r.question, r => ago(r.created_at)));
        if (plazas.length) sections.push(listRows("광장", "plaza", "plaza", plazas, r => r.title, r => views(r.view_count) + " · " + ago(r.created_at)));

        tabContent.innerHTML = `<div class="mp-yt">${sections.join("")}</div>`;
        // 섹션 헤더 탭 → 해당 탭으로 전환
        tabContent.querySelectorAll("[data-gototab]").forEach(el => el.addEventListener("click", () => {
            const tb = D.querySelector('.tab[data-tab="' + el.dataset.gototab + '"]');
            if (tb) tb.click();
        }));
        tabContent.querySelectorAll(".mp-sh-cell[data-id], .mp-lv[data-id], .mp-am-row[data-id]").forEach(el => el.addEventListener("click", () =>
            (window.GALLA_nav || function (u) { location.href = u; })(ALL_TYPES[el.dataset.t].dest(el.dataset.id))));
    };

    // 숏판·롱판 탭은 비공개 — gallari_enabled 켜졌거나 운영진일 때만 노출
    (async function revealContentTab() {
        const ctabs = D.querySelectorAll('.tab[data-tab="short"], .tab[data-tab="long"]');
        if (!ctabs.length) return;
        let on = false;
        try {
            const [{ data: fl }, { data: prof }] = await Promise.all([
                supabase.from("app_settings").select("v").eq("k", "gallari_enabled").maybeSingle(),
                supabase.from("user_profiles").select("admin_flag").eq("user_id", userId).maybeSingle(),
            ]);
            on = (fl && (fl.v === true || fl.v === "true")) || !!(prof && prof.admin_flag);
        } catch (_) {}
        if (on) ctabs.forEach(t => t.hidden = false);
    })();

    // ---------------------------
    // 탭 클릭 이벤트
    // ---------------------------
    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            tab.classList.add("active");

            const menu = tab.dataset.tab;

            switch (menu) {
                case "all": renderAll(); break;                              // 모아 — 전체 통합 그리드
                case "galla": renderGalla(); break;                          // 내가 만든 이슈
                case "short": renderContent("vertical"); break;              // 숏판
                case "long":  renderContent("horizontal"); break;            // 롱판
                case "predict": renderPredict(); break;                      // 내가 만든 예측
                case "plaza": renderPlaza(); break;                          // 내가 쓴 광장
            }
        });
    });

    // 조그/외부에서 탭 전환 — 해당 .tab을 눌러 재사용
    window.GALLA_mypageSetTab = (tab) => {
        const el = D.querySelector('.tabs .tab[data-tab="' + tab + '"]');
        if (el && !el.hidden) { el.click(); return true; }
        return false;
    };

    // ---------------------------
    // 기본 탭: 모아 (전체 통합 그리드) — 단, 조그로 넘어온 대기 탭이 있으면 그 탭
    // ---------------------------
    let pending = null;
    try { pending = sessionStorage.getItem("galla_mypage_tab"); if (pending) sessionStorage.removeItem("galla_mypage_tab"); } catch (_) {}
    const pendEl = pending && pending !== "all" ? D.querySelector('.tabs .tab[data-tab="' + pending + '"]') : null;
    if (pendEl && !pendEl.hidden) pendEl.click();
    else renderAll();
}

/* ═══ 모드 부트스트랩 ═══
   SPA 셸(app.html)이면 자동 초기화 금지 — 어댑터가 mount()로 부른다.
   MPA(단독 문서)면 기존과 동일하게 DOMContentLoaded에서 자동 초기화. */
(function () {
    const page = {
        _root: null,
        _roots: [],   // SPA 중첩(내 탭 위에 남의 프로필 스택) — 위 판 unmount 시 아래 판 root 복원
        mount(root, params) {
            if (page._root) page._roots.push(page._root);
            page._root = root || document;
            return GALLA_mypageInit(page._root, params);
        },
        unmount() { page._root = page._roots.pop() || page._root; },
        activate() {},
        deactivate() {},
        scrolltop() {
            const sc = (page._root && page._root !== document) ? page._root : (document.scrollingElement || document.documentElement);
            try { sc.scrollTo({ top: 0, behavior: "smooth" }); } catch (_) { sc.scrollTop = 0; }
        },
    };
    window.GALLA_PAGE_MYPAGE = page;

    if (document.body && document.body.dataset.page === "spa") return;   // SPA — mount 대기
    if (document.readyState === "loading")
        document.addEventListener("DOMContentLoaded", () => { GALLA_mypageInit(document); });
    else GALLA_mypageInit(document);   // (안전망 — 원래 스크립트는 body 끝 동기 로드라 위 분기만 탄다)
})();