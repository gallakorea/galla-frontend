/* =========================================================
   ⚔️ 일기토 — 실시간 채팅 대결(온라인 옥타곤)
   - 로비 / 신청 / 아레나(파이터 링 + 관중석 + 기세 게이지 + 실시간)
   - 댓글배틀 귀속: ?challenge=uid&issue=ID , 관전: ?id=N
   ========================================================= */
(function () {
  const $ = (s, r) => (r || document).querySelector(s);
  const root = () => document.getElementById("duel-root");
  const esc = (s) => (s == null ? "" : String(s).replace(/[&<>"]/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])));
  const P = new URLSearchParams(location.search);
  let sb, ME = null, nickCache = {};
  let chans = [], timers = [], D = null;

  function avatar(url) { return window.GALLA_avatarImg ? window.GALLA_avatarImg(url, "d-av") : ""; }
  const nk = (uid) => nickCache[uid]?.nick || "익명";
  const av = (uid) => nickCache[uid]?.avatar || null;
  function nameTag(uid) { return `<span class="user-name" data-user-id="${uid}" data-profile-uid="${uid}">${esc(nk(uid))}</span>`; }

  function mmss(ms) {
    if (ms < 0) ms = 0;
    const s = Math.floor(ms / 1000), m = Math.floor(s / 60);
    return `${m}:${String(s % 60).padStart(2, "0")}`;
  }
  function relTime(ts) {
    const s = (Date.now() - new Date(ts).getTime()) / 1000;
    if (s < 60) return "방금"; if (s < 3600) return Math.floor(s / 60) + "분 전";
    if (s < 86400) return Math.floor(s / 3600) + "시간 전"; return Math.floor(s / 86400) + "일 전";
  }

  async function loadNicks(uids) {
    const need = [...new Set(uids)].filter(u => u && !(u in nickCache));
    if (!need.length) return;
    const { data } = await sb.from("users").select("id,nickname,avatar_url").in("id", need);
    (data || []).forEach(u => { nickCache[u.id] = { nick: u.nickname || "익명", avatar: u.avatar_url }; });
    need.forEach(u => { if (!nickCache[u]) nickCache[u] = { nick: "익명", avatar: null }; });
  }

  function teardown() {
    chans.forEach(c => { try { sb.removeChannel(c); } catch (e) {} });
    timers.forEach(t => clearInterval(t));
    chans = []; timers = [];
    lockExit(false);   // ★대결이 끝나거나 화면이 바뀌면 반드시 잠금 해제(안 풀면 앱에 갇힌다)
  }

  const REASON = {
    no_ticket: "일기토 신청서가 없어요. 상점에서 구매하세요.",
    already: "이 상대와 진행 중인 일기토가 이미 있어요.",
    insufficient: "대결에 필요한 GP가 부족해요.",
    bad_opponent: "잘못된 상대예요.", no_topic: "주제를 입력하세요.",
    not_fighter: "파이터만 발언할 수 있어요.", is_party: "당사자는 참여할 수 없어요.",
    time_over: "시간이 종료됐어요.", not_live: "지금은 대결 중이 아니에요.",
    unauthorized: "로그인이 필요합니다.",
    // ↓ 누락돼 있어서 그냥 "실패"로만 뜨던 사유들 (특히 not_pending: 이미 끝난 결투에 수락)
    not_pending: "이미 종료되었거나 상대가 취소한 일기토예요.",
    not_found: "없는 일기토예요. 이미 삭제됐을 수 있어요.",
    not_opponent: "이 일기토의 상대가 아니에요.",
    not_scheduled: "예약 상태가 아니에요.", too_early: "아직 입장 시간이 아니에요.",
    already_voted: "이미 투표했어요.",
    // ⚔️ 고도화 아이템 사유
    already_extended: "이 판에서 이미 시간을 연장했어요. (1회)",
    finisher_used: "이 판에서 결정타를 이미 썼어요. (1회)",
    no_item: "시간 연장권이 없어요. 상점에서 구매하세요.",
    no_finisher: "결정타가 없어요. 상점에서 구매하세요.",
    no_rematch: "설욕전권이 없어요. 상점에서 구매하세요.",
    not_over: "아직 끝나지 않은 대결이에요.", not_party: "이 대결의 당사자가 아니에요.",
  };
  // 서버 상태와 화면이 어긋난 경우 — 알림만 띄우고 멈추면 사용자가 갇힌다. 최신 상태로 다시 그린다.
  const STALE = new Set(["not_pending", "not_found", "not_scheduled", "not_live", "time_over"]);
  const reason = (r) => REASON[r];

  /* ═══════════ ✦ DFX — 옥타곤 SVG 연출 엔진 ═══════════
     이모지 없이 전부 인라인 SVG. 톤은 theme.css: 인디고 액센트 + 진영색(pro/con).
     빛줄기 파티클·확산 링·글로우 플래시·흔들림·컨페티·아이콘 배너. reduced-motion 스킵. */
  const DFX = (() => {
    const reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;
    const NS = "http://www.w3.org/2000/svg";
    let layer;
    const L = () => { if (!layer || !layer.isConnected) { layer = document.createElement("div"); layer.className = "dfx-layer"; document.body.appendChild(layer); } return layer; };
    const rnd = (a, b) => a + Math.random() * (b - a);
    const PAL = {
      accent: ["#6a7bff", "#4361ff", "#8b9bff", "#aab6ff"],
      pro:    ["#4d8dff", "#6fa4ff", "#9bc0ff", "#c3d8ff"],
      con:    ["#ff5a6e", "#ff8a9c", "#ffb3bf", "#ffd4db"],
    };
    const center = () => { const o = document.querySelector(".octa") || document.body; const r = o.getBoundingClientRect(); return [r.left + r.width / 2, Math.max(150, r.top + Math.min(r.height, innerHeight) * 0.34)]; };
    // 파티클 = SVG 빛줄기(rect) 또는 4각 스파클(path)
    function particle(color, spark) {
      const s = document.createElementNS(NS, "svg"); s.setAttribute("class", "dfx-p");
      if (spark) {
        s.setAttribute("viewBox", "0 0 24 24");
        const p = document.createElementNS(NS, "path");
        p.setAttribute("d", "M12 0 L14.4 9.6 L24 12 L14.4 14.4 L12 24 L9.6 14.4 L0 12 L9.6 9.6 Z");
        p.setAttribute("fill", color); s.appendChild(p);
      } else {
        s.setAttribute("viewBox", "0 0 6 24");
        const r = document.createElementNS(NS, "rect");
        r.setAttribute("x", "1.5"); r.setAttribute("width", "3"); r.setAttribute("height", "24"); r.setAttribute("rx", "1.5");
        r.setAttribute("fill", color); s.appendChild(r);
      }
      return s;
    }
    function burst(x, y, pal, count = 22, spread = 150) {
      if (reduce) return; const l = L(); const cols = PAL[pal] || PAL.accent;
      for (let i = 0; i < count; i++) {
        const spark = i % 4 === 0;
        const el = particle(cols[i % cols.length], spark);
        const sz = spark ? rnd(10, 17) : rnd(4, 7);
        el.style.width = sz + "px"; el.style.height = (spark ? sz : sz * 3.4) + "px";
        el.style.left = x + "px"; el.style.top = y + "px";
        const ang = (Math.PI * 2 * i) / count + rnd(-0.28, 0.28), dist = spread + rnd(0, spread);
        const base = ang * 180 / Math.PI + 90;
        el.style.transform = `translate(-50%,-50%) rotate(${base}deg)`;
        l.appendChild(el);
        const dx = Math.cos(ang) * dist, dy = Math.sin(ang) * dist - 42;
        requestAnimationFrame(() => { el.style.transform = `translate(-50%,-50%) translate(${dx}px,${dy}px) rotate(${base + rnd(-40, 40)}deg) scale(${spark ? rnd(.5, 1.1) : rnd(.3, .8)})`; el.style.opacity = "0"; });
        setTimeout(() => el.remove(), 1000);
      }
    }
    function ring(x, y, color) {
      if (reduce) return;
      const s = document.createElementNS(NS, "svg"); s.setAttribute("class", "dfx-ring"); s.setAttribute("viewBox", "0 0 100 100");
      const c = document.createElementNS(NS, "circle"); c.setAttribute("cx", "50"); c.setAttribute("cy", "50"); c.setAttribute("r", "46");
      c.setAttribute("fill", "none"); c.setAttribute("stroke", color || "#4361ff"); c.setAttribute("stroke-width", "2.5");
      s.appendChild(c); s.style.left = x + "px"; s.style.top = y + "px"; L().appendChild(s);
      requestAnimationFrame(() => { s.style.transform = "translate(-50%,-50%) scale(3)"; s.style.opacity = "0"; });
      setTimeout(() => s.remove(), 720);
    }
    function flash(color) {
      if (reduce) return; const f = document.createElement("div"); f.className = "dfx-flash";
      f.style.background = `radial-gradient(circle at 50% 36%, ${color}, transparent 66%)`; L().appendChild(f);
      requestAnimationFrame(() => f.classList.add("on"));
      setTimeout(() => { f.classList.remove("on"); setTimeout(() => f.remove(), 340); }, 140);
    }
    function shake(hard) { if (reduce) return; document.body.classList.add(hard ? "dfx-shake-hard" : "dfx-shake"); setTimeout(() => document.body.classList.remove("dfx-shake", "dfx-shake-hard"), hard ? 620 : 460); }
    function confetti(pal, n = 56) {
      if (reduce) return; const l = L(); const cols = PAL[pal] || PAL.accent;
      for (let i = 0; i < n; i++) {
        const el = particle(cols[i % cols.length], i % 5 === 0);
        const w = rnd(4, 8); el.style.width = w + "px"; el.style.height = w * rnd(1.6, 3) + "px";
        el.style.left = rnd(0, innerWidth) + "px"; el.style.top = rnd(-40, -8) + "px";
        el.style.transition = `transform ${rnd(1.5, 2.6)}s cubic-bezier(.2,.6,.4,1), opacity .5s ease ${rnd(1, 1.9)}s`;
        l.appendChild(el);
        requestAnimationFrame(() => { el.style.transform = `translate(${rnd(-70, 70)}px, ${innerHeight + 90}px) rotate(${rnd(180, 960)}deg)`; el.style.opacity = "0"; });
        setTimeout(() => el.remove(), 2700);
      }
    }
    const ICON = {
      clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7.2v5l3.2 2"/>',
      mic:   '<rect x="9" y="2.5" width="6" height="11" rx="3"/><path d="M5.5 11a6.5 6.5 0 0 0 13 0"/><path d="M12 17.5V21"/>',
      rematch: '<path d="M3.5 9a8.5 8.5 0 0 1 14-3l1.7 1.6"/><path d="M19.2 3v4.6h-4.6"/><path d="M20.5 15a8.5 8.5 0 0 1-14 3L4.8 16.4"/><path d="M4.8 21v-4.6h4.6"/>',
      horn:  '<path d="M3 10v4a1 1 0 0 0 1 1h2l6 4V5L6 9H4a1 1 0 0 0-1 1Z"/><path d="M16 8.5a5 5 0 0 1 0 7"/>',
      roar:  '<circle cx="4.5" cy="12" r="2"/><path d="M8.5 8.5a5 5 0 0 1 0 7"/><path d="M11.5 5.5a9 9 0 0 1 0 13"/><path d="M14.5 3a12.5 12.5 0 0 1 0 18"/>',
      play:  '<path d="M7 4.5v15l12-7.5z"/>',
    };
    function bigText(icon, text, sub, tone) {
      const b = document.createElement("div"); b.className = "dfx-big tone-" + (tone || "accent");
      b.innerHTML = `<span class="dfx-ic"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICON[icon] || ""}</svg></span>`
        + `<span class="dfx-tx">${text}${sub ? `<em>${sub}</em>` : ""}</span>`;
      L().appendChild(b);
      requestAnimationFrame(() => b.classList.add("show"));
      setTimeout(() => { b.classList.add("out"); setTimeout(() => b.remove(), 440); }, 1500);
      return b;
    }
    function haptic(k) { try { window.BattleFX?.haptic?.(k); } catch (e) {} }
    return { burst, ring, flash, shake, confetti, bigText, center, haptic, reduce, ICON };
  })();

  /* 아이템별 연출 — 사용 즉시 호출(전부 SVG·톤 준수) */
  function fxExtend() {
    const [cx, cy] = DFX.center();
    DFX.ring(cx, cy, "#6a7bff"); DFX.ring(cx, cy, "#4361ff");
    DFX.burst(cx, cy, "accent", 24, 150);
    DFX.bigText("clock", "시간 연장", "+60초", "accent");
    DFX.haptic("hit");
  }
  function fxBoost(team, box) {
    const r = (box || document.querySelector(".octa") || document.body).getBoundingClientRect();
    const x = r.left + r.width / 2, y = r.top + Math.min(r.height, innerHeight) * 0.66;
    const pal = team === "challenger" ? "pro" : "con";
    DFX.burst(x, y, pal, 20, 130); DFX.confetti(pal, 54);
    DFX.bigText("horn", "응원 부스트", "×1.7", pal);
    DFX.haptic("hit");
  }
  function fxRematch() {
    const [cx, cy] = DFX.center();
    DFX.flash("rgba(255,90,110,.42)"); DFX.shake();
    DFX.burst(cx, cy, "con", 26, 160); DFX.confetti("con", 62);
    DFX.bigText("rematch", "설욕전", "REMATCH", "con");
    DFX.haptic("hit");
  }
  /* 🦁 사자후 — 최강 연출: 화면 강타 + 3중 음파링 + 대량 파티클 + 배너 */
  function fxRoar(side) {
    const tone = side === "opponent" ? "con" : side === "challenger" ? "pro" : "con";
    const [cx, cy] = DFX.center();
    DFX.flash(tone === "con" ? "rgba(255,90,110,.5)" : "rgba(77,141,255,.5)");
    DFX.shake(true);
    setTimeout(() => DFX.shake(true), 260);              // 두 번 강타
    DFX.ring(cx, cy, "#ff5a6e");
    setTimeout(() => DFX.ring(cx, cy, "#ff8a9c"), 120);
    setTimeout(() => DFX.ring(cx, cy, "#ffd4db"), 240);  // 퍼지는 음파 3중
    DFX.burst(cx, cy, tone, 36, 210);
    DFX.confetti(tone, 80);
    DFX.bigText("roar", "사자후", "獅子吼", tone);
    DFX.haptic("hit");
    setTimeout(() => DFX.haptic("hit"), 200);
  }

  // ─────────── 라우팅 ───────────
  async function boot() {
    sb = await waitForSupabaseClient();
    const { data: s } = await sb.auth.getSession();
    ME = s?.session?.user?.id || null;
    if (P.get("challenge")) return renderChallenge(P.get("challenge"), P.get("issue"));
    if (P.get("id")) return renderArena(P.get("id"));
    return renderLobby();
  }

  // ═══════════ 신청 ═══════════
  async function renderChallenge(oppId, issueId) {
    teardown();
    if (!ME) { alert("로그인이 필요합니다."); (window.GALLA_nav||function(u){location.href=u})("login.html"); return; }
    if (oppId === ME) { alert("자기 자신에게는 신청할 수 없어요."); (window.GALLA_nav||function(u){location.href=u})("duel.html"); return; }
    /* 주제는 사용자가 짓는 게 아니라 '논쟁하던 그 이슈'에서 온다(사장님 룰).
       이슈 맥락 없이 들어온 신청(직접 URL 등)은 받지 않는다. */
    if (!issueId) { alert("일기토는 논쟁 중인 이슈 댓글에서만 신청할 수 있어요."); (window.GALLA_nav||function(u){location.href=u})("duel.html"); return; }
    const { data: issueRow } = await sb.from("issues").select("title").eq("id", +issueId).maybeSingle();
    const fixedTopic = (issueRow?.title || "").trim();
    if (!fixedTopic) { alert("이슈를 찾을 수 없어요. 댓글에서 다시 신청해 주세요."); (window.GALLA_nav||function(u){location.href=u})("duel.html"); return; }
    await loadNicks([oppId]);
    root().innerHTML = `
      <div class="duel-card challenge-card">
        <div class="ch-title">⚔️ 일기토 신청</div>
        <div class="ch-opp">${avatar(av(oppId))}<div><div class="ch-oppname">${nameTag(oppId)}</div><div class="ch-sub">에게 1:1 실시간 설전을 신청</div></div></div>

        <label class="ch-label">논쟁 주제 <span class="ch-hint">논쟁 중인 이슈에서 자동으로 가져와요</span></label>
        <div class="ch-topic-fixed">“${esc(fixedTopic)}”</div>

        <label class="ch-label">대결 GP (승자 독식)</label>
        <div class="seg" id="seg-stake">
          <button data-v="300">300</button><button data-v="500" class="on">500</button><button data-v="1000">1000 GP</button>
        </div>

        <label class="ch-label">제한 시간 <span class="ch-hint">짧고 굵게 — 최대 90초</span></label>
        <div class="seg" id="seg-limit">
          <button data-v="60">⚡ 60초</button><button data-v="90" class="on">🔥 90초</button>
        </div>

        <label class="ch-label">시작 방식</label>
        <div class="seg" id="seg-when">
          <button data-v="instant" class="on">⚡ 지금 바로</button><button data-v="scheduled">⏰ 시간 예약</button>
        </div>
        <input id="ch-time" type="datetime-local" style="display:none" />

        <div class="ch-cost">신청서 1장 + 대결 GP가 잠깁니다 · 상대가 도망가면 위약금 획득</div>
        <button id="ch-send" class="duel-btn primary">⚔️ 결투 신청</button>
        <button id="ch-cancel" class="duel-btn ghost">취소</button>
      </div>`;

    const seg = (id, cb) => root().querySelectorAll(`#${id} button`).forEach(b => b.onclick = () => {
      root().querySelectorAll(`#${id} button`).forEach(x => x.classList.remove("on")); b.classList.add("on"); cb && cb(b.dataset.v);
    });
    let stake = 500, limit = 90, when = "instant";   // ⚔️ 기본 90초(서버 허용값 60/90)
    seg("seg-stake", v => stake = +v); seg("seg-limit", v => limit = +v);
    seg("seg-when", v => { when = v; $("#ch-time").style.display = v === "scheduled" ? "" : "none"; });

    $("#ch-cancel").onclick = () => history.length > 1 ? history.back() : ((window.GALLA_nav||function(u){location.href=u})("duel.html"));
    $("#ch-send").onclick = async () => {
      const topic = fixedTopic.slice(0, 140);   // 임의 작성 불가 — 이슈 제목 고정
      let sched = null;
      if (when === "scheduled") {
        const t = $("#ch-time").value; if (!t) { $("#ch-time").focus(); return; }
        sched = new Date(t).toISOString();
      }
      const btn = $("#ch-send"); btn.disabled = true; btn.textContent = "신청 중…";
      const { data, error } = await sb.rpc("duel_challenge", {
        p_opponent: oppId, p_topic: topic, p_issue_id: issueId ? +issueId : null,
        p_stake: stake, p_limit: limit, p_scheduled_at: sched,
      });
      if (error || !data?.ok) {
        btn.disabled = false; btn.textContent = "⚔️ 결투 신청";
        if (data?.reason === "no_ticket" && window.openShop) {
          alert(reason("no_ticket"));
          window.openShop(); // '상점에서 구매하세요'라고 말만 하지 말고 바로 연다
        } else {
          alert(reason(data?.reason) || "신청 실패");
        }
        return;
      }
      location.href = "duel.html?id=" + data.id;
    };
  }

  // ═══════════ 로비 ═══════════
  async function renderLobby() {
    teardown();
    root().innerHTML = `<div class="duel-loading">불러오는 중…</div>`;
    let mine = [], live = [], voting = [];
    if (ME) {
      const { data } = await sb.from("duels").select("*").or(`challenger.eq.${ME},opponent.eq.${ME}`)
        .order("created_at", { ascending: false }).limit(40);
      mine = data || [];
    }
    const { data: ld } = await sb.from("duels").select("*").in("status", ["live", "voting"])
      .order("live_started_at", { ascending: false }).limit(30);
    (ld || []).forEach(d => { (d.status === "live" ? live : voting).push(d); });
    live = live.filter(d => d.challenger !== ME && d.opponent !== ME);
    voting = voting.filter(d => d.challenger !== ME && d.opponent !== ME);

    const uids = []; mine.concat(live, voting).forEach(d => uids.push(d.challenger, d.opponent));
    await loadNicks(uids);

    let rec = { wins: 0, losses: 0, draws: 0, flees: 0 };
    if (ME) { const { data } = await sb.rpc("duel_record", { p_user: ME }); rec = data || rec; }

    const need = mine.filter(needsMe), others = mine.filter(d => !needsMe(d));
    root().innerHTML = `
      ${ME ? `<div class="duel-card rec-card"><div class="rec-title">🏟️ 내 전적</div>
        <div class="rec-row"><span class="rec-w">${rec.wins}승</span><span class="rec-l">${rec.losses}패</span><span class="rec-d">${rec.draws}무</span>${rec.flees ? `<span class="rec-f">🏳️${rec.flees}</span>` : ""}</div></div>` : ""}
      ${live.length ? `<div class="duel-sec-title">🔴 LIVE 생중계 <span class="sec-cnt live">${live.length}</span></div>${live.map(lobbyRow).join("")}` : ""}
      ${need.length ? `<div class="duel-sec-title">🔔 내 차례</div>${need.map(lobbyRow).join("")}` : ""}
      <div class="duel-sec-title">🗳️ 투표 중 ${voting.length ? `<span class="sec-cnt">${voting.length}</span>` : ""}</div>
      ${voting.length ? voting.map(lobbyRow).join("") : `<div class="duel-empty">지금 투표 중인 일기토가 없어요.</div>`}
      ${others.length ? `<div class="duel-sec-title">내 일기토</div>${others.map(lobbyRow).join("")}` : ""}
      ${!ME ? `<div class="duel-empty">로그인하면 일기토에 참전할 수 있어요.</div>` : ""}
      <div class="duel-hint">💡 일기토는 <b>논쟁 중인 이슈 댓글</b>에서만 신청할 수 있어요(⚔️ 격론 버튼). 신청서는 🛒 상점에서.</div>`;
    root().querySelectorAll("[data-goto]").forEach(el => el.onclick = () => location.href = "duel.html?id=" + el.dataset.goto);
  }
  function needsMe(d) {
    if (!ME) return false;
    if (d.status === "pending" && d.opponent === ME) return true;
    if (d.status === "scheduled" && (d.challenger === ME || d.opponent === ME)) return true;
    if (d.status === "live" && (d.challenger === ME || d.opponent === ME)) return true;
    return false;
  }
  function pill(d) {
    const m = {
      pending: ["수락 대기", "wait"], scheduled: ["예약됨", "wait"], live: ["🔴 LIVE", "live"],
      voting: ["🗳️ 투표", "vote"], declined: ["도망", "dead"], expired: ["무효", "dead"], noshow: ["몰수", "dead"],
    };
    if (d.status === "finished") {
      if (d.result === "draw") return `<span class="d-pill draw">무승부</span>`;
      const party = ME && (d.challenger === ME || d.opponent === ME);
      return `<span class="d-pill ${d.winner === ME ? "win" : "lose"}">${party ? (d.winner === ME ? "승리 🏆" : "패배") : "종료"}</span>`;
    }
    const x = m[d.status] || ["", ""]; return `<span class="d-pill ${x[1]}">${x[0]}</span>`;
  }
  function lobbyRow(d) {
    return `<div class="duel-card lobby-row${d.status === "live" ? " is-live" : ""}" data-goto="${d.id}">
      ${needsMe(d) ? `<span class="row-flag">●</span>` : ""}
      <div class="lr-main"><div class="lr-topic">${esc(d.topic)}</div>
        <div class="lr-vs">${esc(nk(d.challenger))} <span class="vs">vs</span> ${esc(nk(d.opponent))} · 💰${d.stake}</div></div>
      <div class="lr-right">${pill(d)}</div></div>`;
  }

  // ═══════════ 아레나(옥타곤) ═══════════
  async function loadDuel(id) {
    const { data } = await sb.from("duels").select("*").eq("id", id).maybeSingle();
    return data;
  }
  async function renderArena(id) {
    teardown();
    root().innerHTML = `<div class="duel-loading">링 준비 중…</div>`;
    D = await loadDuel(id);
    if (!D) { root().innerHTML = `<div class="duel-empty">일기토를 찾을 수 없어요.</div>`; return; }

    // 자동 상태 전이(멱등): 시간 경과분 정리
    if (D.status === "live" && D.live_ends_at && Date.now() >= new Date(D.live_ends_at).getTime()) {
      await sb.rpc("duel_resolve", { p_duel: id }); D = await loadDuel(id);
    } else if (D.status === "voting" && D.voting_ends_at && Date.now() >= new Date(D.voting_ends_at).getTime()) {
      await sb.rpc("duel_resolve", { p_duel: id }); D = await loadDuel(id);
    } else if (D.status === "scheduled" && D.grace_until && Date.now() >= new Date(D.grace_until).getTime()) {
      await sb.rpc("duel_noshow_check", { p_duel: id }); D = await loadDuel(id);
    }

    await loadNicks([D.challenger, D.opponent]);
    const isChal = ME === D.challenger, isOpp = ME === D.opponent, isParty = isChal || isOpp;
    D._isChal = isChal; D._isOpp = isOpp; D._isParty = isParty;

    // 비-라이브 상태들은 단순 카드, live/voting은 옥타곤
    if (D.status === "pending") return renderPending();
    if (D.status === "scheduled") return renderScheduled();
    if (D.status === "judging") return renderJudging();
    if (D.status === "declined" || D.status === "expired" || D.status === "noshow" || D.status === "finished")
      return renderClosed();
    return renderOctagon(); // live | voting
  }

  function ringHeader() {
    const chalWin = D.result === "challenger", oppWin = D.result === "opponent";
    return `
      <div class="ring-head">
        <div class="ring-fighters">
          <div class="rf chal ${chalWin ? "won" : ""}">
            <div class="rf-av" data-profile-uid="${D.challenger}"><span class="rf-dot" id="dot-chal"></span>${avatar(av(D.challenger))}${chalWin ? '<span class="rf-crown">👑</span>' : ""}</div>
            <div class="rf-name">${nameTag(D.challenger)}</div>
          </div>
          <div class="rf-vs"><div id="ring-timer" class="ring-timer">${D.status === "live" ? "" : "VS"}</div></div>
          <div class="rf opp ${oppWin ? "won" : ""}">
            <div class="rf-av" data-profile-uid="${D.opponent}"><span class="rf-dot" id="dot-opp"></span>${avatar(av(D.opponent))}${oppWin ? '<span class="rf-crown">👑</span>' : ""}</div>
            <div class="rf-name">${nameTag(D.opponent)}</div>
          </div>
        </div>
        <div class="ring-topic">“${esc(D.topic)}” · 💰${D.stake} GP</div>
      </div>`;
  }

  async function renderOctagon() {
    const isParty = D._isParty;
    root().innerHTML = `
      ${ringHeader()}
      <div class="octa">
        <!-- 🔥 응원 GP — 게이지와 투척 버튼을 한 덩어리로, 링 바로 아래.
             예전엔 관중석 스트림 밑(페이지 최하단)에 있어서 스크롤 안 하면 존재 자체를 몰랐다. -->
        <div class="cgz" id="cgz">
          <div class="cgz-head">🔥 응원 GP <b id="cgz-tot">0</b> 걸림 — 이긴 편 응원자가 진 편 GP를 나눠 갖습니다</div>
          <div class="cgz-bar" id="cgz-bar">
            <div class="cgz-fill chal" id="cgz-chal"><span id="cgz-cn">0</span></div>
            <div class="cgz-fill opp" id="cgz-opp"><span id="cgz-on">0</span></div>
          </div>
          <div class="cgz-names">
            <span class="cgz-nm chal">🔵 ${esc(nk(D.challenger))}</span>
            <span class="cgz-nm opp">${esc(nk(D.opponent))} 🔴</span>
          </div>
          <div id="cheer-gp"></div>
        </div>
        <div class="ring-label">⚔️ 파이터 링</div>
        <div class="ring-stream" id="ring-stream"></div>
        <div id="fighter-input"></div>
        ${isParty ? `<div class="forfeit-row"><button class="duel-btn danger" id="ff">🏳️ 포기하고 나가기</button></div>` : ""}
        <div class="stands-label">👥 관중석 <span id="cheer-cnt"></span></div>
        <div class="stands-stream" id="stands-stream"></div>
        <div id="stand-tools"></div>
      </div>`;

    // 초기 메시지/응원 로드
    const [{ data: msgs }, { data: cheers }, myVoteRow] = await Promise.all([
      sb.from("duel_messages").select("*").eq("duel_id", D.id).order("created_at").limit(200),
      sb.from("duel_cheers").select("*").eq("duel_id", D.id).order("created_at").limit(100),
      ME && !isParty ? sb.from("duel_votes").select("choice").eq("duel_id", D.id).eq("voter", ME).maybeSingle() : Promise.resolve({ data: null }),
    ]);
    await loadNicks((cheers || []).map(c => c.user_id));
    (msgs || []).forEach(appendMsg);
    (cheers || []).forEach(appendCheer);
    D._myVote = myVoteRow?.data?.choice || null;

    mountFighterInput();
    mountStandTools();
    mountCheerGp();
    paintCheerGauge();
    subscribeArena();
    startTimers();
    if (isParty && D.status === "live") lockExit(true);   // 🔒 대결 중 이탈 방지
    bindForfeit();
  }

  /* 🔥 응원 GP 게이지.
     ⚠️ 예전엔 이 게이지도 class="momentum"/.mo-fill을 썼는데, 구 투표 게이지가 같은 이름으로
     .momentum{height:12px;overflow:hidden} + .mo-fill{position:absolute}를 이미 잡아놔서
     26px 막대가 12px로 눌려 잘리고 두 칸이 겹쳤다("게이지가 안 움직인다"의 정체).
     구 투표 게이지는 제거했고, 이 게이지는 겹치지 않는 .cgz-* 이름을 쓴다. */
  function paintCheerGauge() {
    const c = D.cheer_chal || 0, o = D.cheer_opp || 0, t = c + o;
    const f1 = $("#cgz-chal"), f2 = $("#cgz-opp");
    if (!f1 || !f2) return;
    const cp = t ? Math.round((c / t) * 100) : 50;
    f1.style.width = cp + "%"; f2.style.width = (100 - cp) + "%";
    $("#cgz-cn").textContent = c.toLocaleString();
    $("#cgz-on").textContent = o.toLocaleString();
    $("#cgz-tot").textContent = t.toLocaleString();
    // 0이면 50:50이라 '고장난 것처럼' 보인다 → 빈 상태를 명시
    $("#cgz-bar")?.classList.toggle("empty", t === 0);
  }

  /* 🔒 대결 중 이탈 방지 — GP가 걸린 실시간 대결이라 실수로 나가면 상대가 피해를 본다.
     완전 차단은 불가(브라우저 정책)이므로 ①새로고침/닫기 경고 ②앱 내 이동 차단 ③뒤로가기 되돌림. */
  let EXIT_LOCKED = false;
  function beforeUnload(e) { e.preventDefault(); e.returnValue = ""; return ""; }
  function lockExit(on) {
    if (on === EXIT_LOCKED) return;
    EXIT_LOCKED = on;
    if (on) {
      window.addEventListener("beforeunload", beforeUnload);
      history.pushState({ duelLock: 1 }, "");           // 뒤로가기 1회 흡수
      window.addEventListener("popstate", onPop);
      document.addEventListener("click", blockNav, true);
      document.body.classList.add("duel-locked");
    } else {
      window.removeEventListener("beforeunload", beforeUnload);
      window.removeEventListener("popstate", onPop);
      document.removeEventListener("click", blockNav, true);
      document.body.classList.remove("duel-locked");
    }
  }
  function onPop() {
    if (!EXIT_LOCKED) return;
    history.pushState({ duelLock: 1 }, "");
    toastLock();
  }
  /* ⚠️ 예전엔 "나가는 요소"를 열거해서 막았다(a[href], .nav-item, [data-target]).
     그런데 duel.html의 뒤로가기는 <button class="st-back" data-back="index.html">이라
     셋 중 무엇에도 안 걸려서 그냥 나가졌다. 열거는 언제든 새 경로가 생기면 또 뚫린다.
     → 뒤집는다: 링(#duel-root) 안의 클릭만 통과시키고 나머지는 전부 막는다(화이트리스트). */
  function blockNav(e) {
    if (!EXIT_LOCKED) return;
    const t = e.target;
    if (t.closest("#duel-root") && !t.closest("[data-back], .nav-item, a[href]")) return;
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    toastLock();
  }
  let TOASTING = false;
  function toastLock() {
    if (TOASTING) return;   // 클릭 한 번에 alert이 여러 번 뜨지 않게
    TOASTING = true;
    alert("⚔️ 대결 중에는 나갈 수 없어요.\n포기하려면 '🏳️ 포기하고 나가기'를 누르세요 (걸어둔 GP를 잃습니다).");
    TOASTING = false;
  }

  /* 🏳️ 포기하기 */
  function bindForfeit() {
    const b = $("#ff"); if (!b) return;
    b.onclick = async () => {
      if (!confirm(`🏳️ 정말 포기할까요?\n걸어둔 ${D.stake} GP를 잃고 상대가 부전승으로 이깁니다.`)) return;
      b.disabled = true; b.textContent = "처리 중…";
      const { data, error } = await sb.rpc("duel_forfeit", { p_duel: D.id });
      if (error || !data?.ok) {
        alert(reason(data?.reason) || `포기 처리에 실패했어요.\n(${error?.message || "알 수 없는 오류"})`);
        b.disabled = false; b.textContent = "🏳️ 포기하고 나가기";
        if (!data?.reason || STALE.has(data?.reason)) { lockExit(false); renderArena(D.id); }
        return;
      }
      lockExit(false);
      renderArena(D.id);
    };
  }

  /* 🔥 응원 GP — 관중만. 파리뮤추얼(이긴 편이 진 편 풀 분배)이라 '던질 이유'가 있다. */
  function mountCheerGp() {
    const box = $("#cheer-gp"); if (!box) return;
    // 왜 못 거는지 침묵하지 않는다 — 버튼이 그냥 없으면 고장으로 보인다
    if (D._isParty) { box.innerHTML = `<div class="cg-note">당사자는 자기 대결에 응원 GP를 걸 수 없어요</div>`; return; }
    if (D.status !== "live") { box.innerHTML = `<div class="cg-note">대결 중일 때만 응원 GP를 걸 수 있어요</div>`; return; }
    if (!ME) { box.innerHTML = `<div class="cg-note">로그인하면 응원 GP를 걸 수 있어요</div>`; return; }
    box.innerHTML = `
      <div class="cheer-gp">
        <div class="cg-label">내 편에 걸기 — ① 편 선택 → ② 금액 탭</div>
        <div class="cg-teams">
          <button class="cg-team chal" data-team="challenger">🔵 ${esc(nk(D.challenger))}</button>
          <button class="cg-team opp"  data-team="opponent">🔴 ${esc(nk(D.opponent))}</button>
        </div>
        <div class="cg-amts">${[10, 50, 100, 500].map(a => `<button class="cg-amt" data-amt="${a}">${a}</button>`).join("")}</div>
        <button class="cg-boost" id="cg-boost" title="응원 부스트"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${DFX.ICON.horn}</svg> 부스트 <span class="cg-boost-x">1.7×</span></button>
      </div>`;
    let team = null, amt = 50, boost = false;
    box.querySelectorAll(".cg-team").forEach(b => b.onclick = () => {
      team = b.dataset.team;
      box.querySelectorAll(".cg-team").forEach(x => x.classList.toggle("on", x === b));
    });
    const boostBtn = $("#cg-boost");
    if (boostBtn) boostBtn.onclick = () => { boost = !boost; boostBtn.classList.toggle("on", boost); };
    box.querySelectorAll(".cg-amt").forEach(b => b.onclick = async () => {
      if (!ME) return alert("로그인이 필요해요.");
      if (!team) return alert("먼저 응원할 편을 고르세요.");
      amt = +b.dataset.amt;
      b.disabled = true;
      const { data, error } = await sb.rpc("duel_cheer_gp", { p_duel: D.id, p_team: team, p_amount: amt, p_boost: boost });
      b.disabled = false;
      if (error || !data?.ok) {
        const M = { insufficient: "GP가 부족해요.", is_party: "당사자는 응원할 수 없어요.",
                    not_live: "대결 중일 때만 응원할 수 있어요.", bad_amount: "잘못된 금액이에요." };
        return alert(M[data?.reason] || "응원에 실패했어요.");
      }
      D.cheer_chal = data.chal; D.cheer_opp = data.opp;
      paintCheerGauge();
      cheerFx(team, amt);
      if (boost && data.boosted) { fxBoost(team, box); finisherToast("부스트 적용! 응원 몫 1.7배"); boost = false; if (boostBtn) boostBtn.classList.remove("on"); }
      else if (boost && !data.boosted) { alert("부스트권이 없어 일반 응원으로 걸렸어요. 상점에서 부스트권을 구매하세요."); boost = false; if (boostBtn) boostBtn.classList.remove("on"); askBuy("duel_cheer_boost"); }
    });
  }
  /* 응원 투척 연출 — 숫자가 링으로 날아가 꽂힌다 */
  function cheerFx(team, amt) {
    const host = $("#cgz"); if (!host) return;
    const el = document.createElement("div");
    el.className = `cg-fly ${team === "challenger" ? "chal" : "opp"}`;
    el.textContent = `+${amt}`;
    host.appendChild(el);
    setTimeout(() => el.remove(), 900);
    try { window.BattleFX?.haptic?.("tap"); } catch (e) {}
  }

  function appendMsg(m) {
    const box = document.getElementById("ring-stream"); if (!box) return;
    const mine = m.user_id === ME;
    const el = document.createElement("div");
    const svg = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
    if (m.is_roar && m.roar_url) {
      // 🦁 사자후 — 재생 가능한 음성 버블
      el.className = `rmsg ${m.side}${mine ? " mine" : ""} roar pop`;
      el.innerHTML = `<span class="rmsg-roar">${svg(DFX.ICON.roar)}사자후</span>`
        + `<button class="roar-play" aria-label="재생">${svg(DFX.ICON.play)}<span class="roar-wave"><i></i><i></i><i></i><i></i><i></i></span><em>3초</em></button>`;
      const audio = new Audio(m.roar_url);
      const btn = el.querySelector(".roar-play");
      btn.onclick = () => { try { audio.currentTime = 0; audio.play(); btn.classList.add("playing"); } catch (e) {} };
      audio.onended = () => btn.classList.remove("playing");
      box.appendChild(el);
      box.scrollTop = box.scrollHeight;
      fxRoar(m.side);
      // 새로 도착한 사자후는 자동 재생(관전 몰입)
      if (!mine) { try { audio.play(); btn.classList.add("playing"); } catch (e) {} }
      return;
    }
    el.className = `rmsg ${m.side}${mine ? " mine" : ""}${m.is_finisher ? " finisher" : ""} pop`;
    el.innerHTML = `${m.is_finisher ? `<span class="rmsg-fin">${svg(DFX.ICON.mic)}결정타</span>` : ""}<span class="rmsg-body">${esc(m.body)}</span>`;
    box.appendChild(el);
    box.scrollTop = box.scrollHeight;
    window.BattleFX?.haptic?.(m.is_finisher ? "hit" : "tap");
    if (m.is_finisher) finisherBanner(m.side);   // 관중석에 '결정타!' 배너
  }
  /* 결정타 — 화면 전체가 번쩍이고 흔들리는 KO급 연출(SVG·진영색). 모두가 회심의 한 방을 목격 */
  function finisherBanner(side) {
    const nk_ = side === "challenger" ? nk(D.challenger) : nk(D.opponent);
    const tone = side === "challenger" ? "pro" : "con";
    DFX.flash(side === "challenger" ? "rgba(77,141,255,.45)" : "rgba(255,90,110,.45)");
    DFX.shake(true);
    const [cx, cy] = DFX.center();
    DFX.burst(cx, cy, tone, 30, 190);
    DFX.confetti(tone, 58);
    DFX.bigText("mic", "결정타", esc(nk_), tone);
    DFX.haptic("hit");
  }
  function appendCheer(c) {
    const box = document.getElementById("stands-stream"); if (!box) return;
    const el = document.createElement("div");
    el.className = `cheer t-${c.team} pop`;
    el.innerHTML = `<b class="cheer-nick" data-user-id="${c.user_id}" data-profile-uid="${c.user_id}">${esc(nk(c.user_id))}</b> ${esc(c.body)}`;
    box.appendChild(el);
    while (box.children.length > 60) box.removeChild(box.firstChild);
    box.scrollTop = box.scrollHeight;
  }

  function mountFighterInput() {
    const box = document.getElementById("fighter-input"); if (!box) return;
    if (D.status !== "live") { box.innerHTML = ""; return; }
    if (!D._isParty) {
      box.innerHTML = `<div class="watch-note">👀 관전 중 — 아래 관중석에서 응원·투표하세요</div>`;
      return;
    }
    const iAmChal = ME === D.challenger;
    const extended = iAmChal ? D.chal_extended : D.opp_extended;
    const finished = iAmChal ? D.chal_finisher : D.opp_finisher;
    const roared = iAmChal ? D.chal_roar : D.opp_roar;
    const svg = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
    const IC = DFX.ICON;
    const IC_ITEM = svg('<path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z"/>');   // 아이템(파워)
    const IC_SEND = svg('<path d="M22 2 11 13"/><path d="M22 2 15 22l-4-9-9-4 20-7Z"/>');
    // 아이템 진입로 = 채팅 입력창 "옆" 아이콘(기존 컴포저 UX와 통일). 탭 → 팝오버
    box.innerHTML = `<div class="fi-wrap">
      <div class="fi-pop" id="fi-pop" hidden>
        <button class="fip-item" id="fi-ext" ${extended ? "disabled" : ""}>
          <span class="fip-ic">${svg(IC.clock)}</span>
          <span class="fip-txt"><b>시간 연장</b><em>${extended ? "이미 사용함" : "제한시간 +60초 · 판당 1회"}</em></span>
          <span class="fip-state">${extended ? "완료" : "+60s"}</span></button>
        <button class="fip-item fin" id="fi-fin" ${finished ? "disabled" : ""}>
          <span class="fip-ic">${svg(IC.mic)}</span>
          <span class="fip-txt"><b>결정타</b><em>${finished ? "이미 사용함" : "다음 발화를 강조 · 판당 1회"}</em></span>
          <span class="fip-state">${finished ? "완료" : "1회"}</span></button>
        <button class="fip-item roar" id="fi-roar" ${roared ? "disabled" : ""}>
          <span class="fip-ic">${svg(IC.roar)}</span>
          <span class="fip-txt"><b>🦁 사자후</b><em>${roared ? "이미 사용함" : "3초 음성으로 압도 · 판당 1회"}</em></span>
          <span class="fip-state">${roared ? "완료" : "3초"}</span></button>
      </div>
      <div class="fi-row">
        <button id="fi-items" class="fi-items" aria-label="아이템">${IC_ITEM}</button>
        <input id="fi-input" maxlength="500" placeholder="상대에게 한 방 날리기…" autocomplete="off">
        <button id="fi-send" class="fi-send" aria-label="전송"><span class="fi-fin-badge" hidden>${svg(IC.mic)}</span>${IC_SEND}</button>
      </div></div>`;
    let armFin = false, popOpen = false;
    const pop = $("#fi-pop"), itemsBtn = $("#fi-items"), sendBadge = box.querySelector(".fi-fin-badge");
    const closePop = () => { popOpen = false; pop.hidden = true; itemsBtn.classList.remove("on"); };
    const togglePop = () => { popOpen = !popOpen; pop.hidden = !popOpen; itemsBtn.classList.toggle("on", popOpen); };
    itemsBtn.onclick = (e) => { e.stopPropagation(); togglePop(); };
    document.addEventListener("click", (e) => { if (popOpen && !box.contains(e.target)) closePop(); });
    const send = async () => {
      const inp = $("#fi-input"); const t = inp.value.trim(); if (!t) return;
      const useFin = armFin;
      inp.value = "";
      const { data } = await sb.rpc("duel_say", { p_duel: D.id, p_body: t, p_finisher: useFin });
      if (!data?.ok) {
        if (data?.reason === "time_over") return renderArena(D.id);
        if (data?.reason === "no_finisher") { alert("결정타가 없어요. 상점에서 구매하세요."); askBuy("duel_finisher_pass"); }
        else alert(reason(data?.reason) || "전송 실패");
        inp.value = t; return;
      }
      if (useFin) { armFin = false; sendBadge.hidden = true; $("#fi-send").classList.remove("armed"); inp.placeholder = "상대에게 한 방 날리기…";
        const fb = $("#fi-fin"); if (fb) { fb.disabled = true; fb.classList.remove("armed"); fb.querySelector(".fip-state").textContent = "완료"; } }
    };
    $("#fi-send").onclick = send;
    $("#fi-input").addEventListener("keydown", e => { if (e.key === "Enter") send(); });
    $("#fi-input").addEventListener("input", () => trackTyping());
    // ⏱️ 시간 연장권 — 판당 1회 +60초
    const extBtn = $("#fi-ext");
    if (extBtn && !extended) extBtn.onclick = async () => {
      extBtn.disabled = true; closePop();
      const { data } = await sb.rpc("duel_extend_time", { p_duel: D.id });
      if (!data?.ok) {
        extBtn.disabled = false;
        if (data?.reason === "no_item") { alert("시간 연장권이 없어요. 상점에서 구매하세요."); askBuy("duel_extend_pass"); }
        else alert(reason(data?.reason) || "연장 실패");
        return;
      }
      D.live_ends_at = data.live_ends_at;
      extBtn.classList.add("used"); extBtn.querySelector(".fip-state").textContent = "완료";
      fxExtend();
      finisherToast("60초 연장됐어요!");
      const t = document.getElementById("ring-timer"); if (t) { t.classList.remove("dfx-timer-pop"); void t.offsetWidth; t.classList.add("dfx-timer-pop"); }
    };
    // 결정타 — 다음 발화 1회를 하이라이트로 (토글)
    const finBtn = $("#fi-fin");
    if (finBtn && !finished) finBtn.onclick = () => {
      armFin = !armFin;
      finBtn.classList.toggle("armed", armFin);
      finBtn.querySelector(".fip-state").textContent = armFin ? "장전됨" : "1회";
      sendBadge.hidden = !armFin; $("#fi-send").classList.toggle("armed", armFin);
      const inp = $("#fi-input"); if (inp) inp.placeholder = armFin ? "회심의 한 방을 결정타로!" : "상대에게 한 방 날리기…";
      closePop();
    };
    // 🦁 사자후 — 3초 음성 녹음 → 발사
    const roarBtn = $("#fi-roar");
    if (roarBtn && !roared) roarBtn.onclick = () => { closePop(); openRoarRecorder(); };
  }
  /* 옥타곤 상단 짧은 토스트(연장/안내) — 배너보다 가벼운 알림 */
  function finisherToast(msg) {
    const t = document.createElement("div"); t.className = "duel-toast"; t.textContent = msg;
    document.body.appendChild(t); requestAnimationFrame(() => t.classList.add("show"));
    setTimeout(() => { t.classList.remove("show"); setTimeout(() => t.remove(), 300); }, 1800);
  }
  /* 아이템이 없을 때 상점으로 유도 — askShop 패턴(문구 금지·즉시 열기) */
  function askBuy(key) { try { window.openShop?.(key); } catch (e) {} }

  /* 🦁 사자후 — 3초 음성 녹음(채팅방 음성과 동일: MediaRecorder→R2). 녹음→들어보기→발사 */
  function openRoarRecorder() {
    const ROAR_MAX = 3;   // 초
    let rec = null, chunks = [], blob = null, url = null, stream = null, timer = null, mime = "";
    const svg = (p) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${p}</svg>`;
    const IC = DFX.ICON;
    const ov = document.createElement("div");
    ov.className = "roar-ov";
    ov.innerHTML = `<div class="roar-sheet">
        <div class="roar-head"><span class="roar-ic">${svg(IC.roar)}</span><b>사자후</b><span class="roar-sub">3초 음성으로 상대를 압도</span></div>
        <div class="roar-stage" id="roar-stage">
          <div class="roar-ring" id="roar-ring"><span id="roar-count">3</span></div>
          <div class="roar-hint" id="roar-hint">버튼을 누르면 3초간 녹음돼요</div>
        </div>
        <div class="roar-acts" id="roar-acts">
          <button class="roar-btn rec" id="roar-rec">${svg(IC.roar)} 녹음</button>
        </div>
        <button class="roar-x" id="roar-x">닫기</button>
      </div>`;
    document.body.appendChild(ov);
    requestAnimationFrame(() => ov.classList.add("on"));
    const $$ = (s) => ov.querySelector(s);
    const close = () => { try { rec && rec.state !== "inactive" && rec.stop(); } catch (e) {} stopStream(); ov.classList.remove("on"); setTimeout(() => ov.remove(), 220); };
    const stopStream = () => { try { stream?.getTracks().forEach(t => t.stop()); } catch (e) {} stream = null; };
    $$("#roar-x").onclick = close;
    ov.addEventListener("click", (e) => { if (e.target === ov) close(); });

    function pickMime() {
      if (typeof MediaRecorder === "undefined") return null;
      const c = ["audio/mp4", "audio/mp4;codecs=mp4a.40.2", "audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/aac"];
      for (const m of c) { try { if (MediaRecorder.isTypeSupported(m)) return m; } catch (_) {} }
      return "";
    }
    async function startRec() {
      try {
        if (typeof MediaRecorder === "undefined") { alert("이 브라우저에선 녹음이 막혀 있어요. 크롬으로 열어주세요."); return; }
        stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true } });
        mime = pickMime(); chunks = []; blob = null; url = null;
        rec = new MediaRecorder(stream, Object.assign(mime ? { mimeType: mime } : {}, { audioBitsPerSecond: 128000 }));
        rec.ondataavailable = e => { if (e.data?.size) chunks.push(e.data); };
        rec.onstop = () => {
          stopStream(); clearInterval(timer);
          blob = new Blob(chunks, { type: mime || "audio/webm" });
          if (!blob.size) { blob = null; $$("#roar-hint").textContent = "소리가 담기지 않았어요. 다시 시도해주세요."; resetRec(); return; }
          url = URL.createObjectURL(blob);
          $$("#roar-ring").classList.remove("recording");
          $$("#roar-hint").textContent = "들어보고 발사하세요";
          $$("#roar-count").textContent = "🦁";
          $$("#roar-acts").innerHTML = `
            <button class="roar-btn ghost" id="roar-play">${svg(IC.play)} 들어보기</button>
            <button class="roar-btn ghost" id="roar-again">다시</button>
            <button class="roar-btn go" id="roar-fire">발사 🦁</button>`;
          $$("#roar-play").onclick = () => { try { new Audio(url).play(); } catch (e) {} };
          $$("#roar-again").onclick = resetRec;
          $$("#roar-fire").onclick = fire;
        };
        // 3초 카운트다운 자동 종료
        $$("#roar-ring").classList.add("recording");
        $$("#roar-hint").textContent = "녹음 중… 크게 외쳐요!";
        let left = ROAR_MAX; $$("#roar-count").textContent = left;
        $$("#roar-acts").innerHTML = `<button class="roar-btn rec on" disabled>● 녹음 중…</button>`;
        rec.start();
        timer = setInterval(() => { left -= 1; $$("#roar-count").textContent = Math.max(0, left); if (left <= 0) { clearInterval(timer); try { rec.state !== "inactive" && rec.stop(); } catch (e) {} } }, 1000);
      } catch (e) {
        stopStream();
        const n = e?.name || "";
        if (n === "NotAllowedError" || n === "SecurityError") { try { window.GALLA_micHelp?.({ reason: "" }); } catch (_) {} alert("마이크 권한이 필요해요."); }
        else alert("녹음을 시작하지 못했어요 (" + (n || "오류") + ")");
        resetRec();
      }
    }
    function resetRec() {
      blob = null; url = null; clearInterval(timer);
      $$("#roar-ring").classList.remove("recording");
      $$("#roar-count").textContent = "3"; $$("#roar-hint").textContent = "버튼을 누르면 3초간 녹음돼요";
      $$("#roar-acts").innerHTML = `<button class="roar-btn rec" id="roar-rec">${svg(IC.roar)} 녹음</button>`;
      $$("#roar-rec").onclick = startRec;
    }
    async function fire() {
      if (!blob) return;
      const fb = $$("#roar-fire"); if (fb) { fb.disabled = true; fb.textContent = "발사 중…"; }
      try {
        if (!window.GALLA_UPLOAD_MEDIA) {
          await new Promise((res, rej) => {
            const vm = ([...document.scripts].map(s => s.src).find(u => /[?&]v=/.test(u)) || "").match(/[?&]v=(\d+)/);
            const s = document.createElement("script"); s.src = "/js/media-upload.js" + (vm ? "?v=" + vm[1] : "");
            s.onload = res; s.onerror = rej; document.head.appendChild(s);
          });
        }
        const type = blob.type || "audio/webm";
        const ext = /mp4|m4a/.test(type) ? "m4a" : /ogg/.test(type) ? "ogg" : /aac/.test(type) ? "aac" : "webm";
        const file = new File([blob], "roar." + ext, { type });
        const upUrl = await window.GALLA_UPLOAD_MEDIA(file, "audio");
        const { data } = await sb.rpc("duel_roar", { p_duel: D.id, p_url: upUrl, p_dur: 3 });
        if (!data?.ok) {
          if (fb) { fb.disabled = false; fb.textContent = "발사 🦁"; }
          if (data?.reason === "no_roar") { alert("사자후가 없어요. 상점에서 구매하세요."); close(); return askBuy("duel_roar_pass"); }
          if (data?.reason === "roar_used") { alert("이 판에서 사자후를 이미 썼어요."); return close(); }
          if (data?.reason === "time_over") { close(); return renderArena(D.id); }
          return alert(reason(data?.reason) || "발사 실패");
        }
        close();
      } catch (e) {
        if (fb) { fb.disabled = false; fb.textContent = "발사 🦁"; }
        alert("발사에 실패했어요. 다시 시도해주세요.");
      }
    }
    $$("#roar-rec").onclick = startRec;
  }

  function mountStandTools() {
    const box = document.getElementById("stand-tools"); if (!box) return;
    if (D._isParty) { box.innerHTML = ""; return; }
    if (!ME) { box.innerHTML = `<div class="watch-note">로그인하면 응원·투표할 수 있어요</div>`; return; }
    const voteRow = (D.status === "live" || D.status === "voting")
      ? `<div class="vote-row"><span class="vr-label">🗳️ 승자 예측</span>
           <button class="vpick chal${D._myVote === "challenger" ? " on" : ""}" data-c="challenger">${esc(nk(D.challenger))} <b id="vc-chal">${D.vote_challenger || 0}</b></button>
           <button class="vpick opp${D._myVote === "opponent" ? " on" : ""}" data-c="opponent">${esc(nk(D.opponent))} <b id="vc-opp">${D.vote_opponent || 0}</b></button></div>` : "";
    box.innerHTML = `${voteRow}
      <div class="cheer-row">
        <input id="cheer-input" maxlength="200" placeholder="응원·야유 남기기…" autocomplete="off">
        <button id="cheer-send" class="cheer-send">📣</button>
      </div>`;
    box.querySelectorAll(".vpick").forEach(b => b.onclick = () => castVote(b.dataset.c));
    const cheer = async () => {
      const inp = $("#cheer-input"); const t = inp.value.trim(); if (!t) return; inp.value = "";
      const team = D._myVote || "neutral";
      const { data } = await sb.rpc("duel_cheer", { p_duel: D.id, p_team: team, p_body: t });
      if (!data?.ok) { alert(reason(data?.reason) || "전송 실패"); inp.value = t; }
    };
    $("#cheer-send").onclick = cheer;
    $("#cheer-input").addEventListener("keydown", e => { if (e.key === "Enter") cheer(); });
  }

  /* 승자 예측 표수 — 게이지 대신 버튼 위 숫자로. 두 개의 막대가 각각 뭘 뜻하는지
     구분이 안 된다는 지적이 있어, 막대는 '응원 GP' 하나만 남기고 표수는 숫자로 뺐다. */
  function paintVoteCounts() {
    const a = $("#vc-chal"), b = $("#vc-opp");
    if (a) a.textContent = D.vote_challenger || 0;
    if (b) b.textContent = D.vote_opponent || 0;
  }

  async function castVote(choice) {
    const { data } = await sb.rpc("duel_vote", { p_duel: D.id, p_choice: choice });
    if (!data?.ok) { alert(reason(data?.reason) || "투표 실패"); return; }
    D._myVote = choice;
    document.querySelectorAll(".vpick").forEach(b => b.classList.toggle("on", b.dataset.c === choice));
    window.BattleFX?.haptic?.("tap");
  }

  // ─── 실시간 구독 ───
  function subscribeArena() {
    const ch = sb.channel("duel-live-" + D.id)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "duel_messages", filter: "duel_id=eq." + D.id },
        p => appendMsg(p.new))
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "duel_cheers", filter: "duel_id=eq." + D.id },
        async p => { await loadNicks([p.new.user_id]); appendCheer(p.new); })
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "duels", filter: "id=eq." + D.id },
        p => onDuelUpdate(p.new));
    ch.subscribe(); chans.push(ch);

    // 프레즌스(파이터 온라인/타이핑)
    const pc = sb.channel("duel-presence-" + D.id, { config: { presence: { key: ME || "anon-" + Math.random() } } });
    pc.on("presence", { event: "sync" }, () => renderPresence(pc.presenceState()));
    pc.subscribe(async (st) => { if (st === "SUBSCRIBED" && ME) await pc.track({ uid: ME, typing: false }); });
    chans.push(pc); D._pc = pc;
  }
  let typingT = null;
  function trackTyping() {
    if (!D._pc || !ME) return;
    D._pc.track({ uid: ME, typing: true });
    clearTimeout(typingT);
    typingT = setTimeout(() => D._pc.track({ uid: ME, typing: false }), 1500);
  }
  function renderPresence(state) {
    const online = new Set(); const typing = new Set();
    Object.values(state || {}).forEach(arr => arr.forEach(p => { if (p.uid) { online.add(p.uid); if (p.typing) typing.add(p.uid); } }));
    const setDot = (id, uid) => {
      const el = document.getElementById(id); if (!el) return;
      el.classList.toggle("on", online.has(uid));
      el.classList.toggle("typing", typing.has(uid));
    };
    setDot("dot-chal", D.challenger); setDot("dot-opp", D.opponent);
  }

  function onDuelUpdate(nd) {
    const prevStatus = D.status;
    Object.assign(D, nd);
    paintCheerGauge();     // 응원 GP 게이지 — 남이 던진 응원도 내 화면에 실시간 반영
    paintVoteCounts();     // 승자 예측 표수
    if (nd.status !== prevStatus) { renderArena(D.id); return; } // 상태 전환 → 재구성
  }

  // ─── 타이머(카운트다운 + 자동 판정) ───
  function startTimers() {
    const tick = () => {
      const t = document.getElementById("ring-timer");
      if (D.status === "live" && D.live_ends_at) {
        const left = new Date(D.live_ends_at).getTime() - Date.now();
        if (t) { t.textContent = mmss(left); t.classList.toggle("urgent", left < 30000); }
        if (left <= 0) resolveTick();
      } else if (D.status === "voting" && D.voting_ends_at) {
        const left = new Date(D.voting_ends_at).getTime() - Date.now();
        if (t) { t.textContent = "🗳️ " + mmss(left); }
        if (left <= 0) resolveTick();
      }
    };
    tick();
    timers.push(setInterval(tick, 1000));
  }
  let resolving = false;
  async function resolveTick() {
    if (resolving) return; resolving = true;
    await sb.rpc("duel_resolve", { p_duel: D.id });
    const nd = await loadDuel(D.id);
    resolving = false;
    if (nd && nd.status !== D.status) { D = nd; renderArena(D.id); }
  }

  // ═══════════ 상태별 단순 화면 ═══════════
  /* 수락/도망 공통 — 중복 클릭 차단 + 상태 어긋나면 알림 후 최신 화면으로 복구 */
  async function respond(accept, btn) {
    if (btn) { btn.disabled = true; btn.dataset.o = btn.textContent; btn.textContent = "처리 중…"; }
    const { data, error } = await sb.rpc("duel_respond", { p_duel: D.id, p_accept: accept });
    if (error || !data?.ok) {
      const r = data?.reason;
      // 사유가 없다 = RPC 자체가 실패(네트워크·세션만료·서버예외). 원인 없이 "실패"만 띄우면
      // 사용자도 우리도 못 고친다 → 콘솔에 원문 남기고, 화면엔 짧은 힌트를 붙인다.
      if (!r) console.error("[duel_respond] failed", { error, data, duel: D.id, accept });
      alert(reason(r) || `요청을 처리하지 못했어요.\n(${error?.message || "알 수 없는 오류"})\n새로고침 후 다시 시도해 주세요.`);
      if (btn) { btn.disabled = false; btn.textContent = btn.dataset.o || "다시 시도"; }
      if (!r || STALE.has(r)) renderArena(D.id);   // 끝난 결투·원인불명 → 갇히지 않게 최신 상태로
      return;
    }
    renderArena(D.id);
  }

  function renderPending() {
    const box = root();
    box.innerHTML = ringHeader() + `<div id="pa"></div>`;
    const pa = $("#pa");
    if (D._isOpp) {
      pa.innerHTML = `<div class="duel-card act-card">
        <div class="act-msg">💰 대결 GP <b>${D.stake}</b> · ${D.mode === "instant" ? "수락 즉시 실시간 대결 시작" : "예약 대결"}</div>
        <div class="act-msg sub">수락하면 같은 GP가 잠깁니다. 거절(도망) 시 위약금 200GP를 뺏겨요.</div>
        <div class="act-btns"><button class="duel-btn primary" id="acc">⚔️ 수락하고 참전</button>
        <button class="duel-btn ghost" id="dec">도망가기</button></div></div>`;
      $("#acc").onclick = () => respond(true, $("#acc"));
      $("#dec").onclick = () => { if (confirm("도망가면 위약금 200GP를 잃어요. 정말?")) respond(false, $("#dec")); };
    } else {
      pa.innerHTML = `<div class="duel-card act-card"><div class="act-msg">⏳ 상대의 수락을 기다리는 중… (${D.stake} GP 잠김)</div></div>`;
      pollStatus();
    }
  }
  function renderScheduled() {
    const box = root();
    const when = D.scheduled_at ? new Date(D.scheduled_at) : null;
    box.innerHTML = ringHeader() + `<div class="duel-card act-card">
      <div class="act-msg">⏰ 예약 대결 · ${when ? when.toLocaleString("ko-KR", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }) : ""}</div>
      <div class="act-msg sub" id="sched-cd"></div>
      ${D._isParty ? `<button class="duel-btn primary" id="enter">🥊 링에 입장</button>
        <div class="act-msg sub">양측 모두 입장하면 대결이 시작돼요. 유예 시간 초과 시 노쇼 몰수패.</div>` :
        `<div class="act-msg sub">시작되면 알림이 가요.</div>`}</div>`;
    if (D._isParty) $("#enter").onclick = async () => { const { data } = await sb.rpc("duel_enter", { p_duel: D.id }); if (!data?.ok) return alert(reason(data?.reason) || "실패"); renderArena(D.id); };
    const cd = $("#sched-cd");
    const tick = () => {
      if (!when) return;
      const left = when.getTime() - Date.now();
      cd.textContent = left > 0 ? `시작까지 ${mmss(left)}` : `대기 중 — ${D.chal_entered ? "도전자 입장✓ " : ""}${D.opp_entered ? "응전자 입장✓" : ""}`;
      if (left < -5 * 60000) resolveScheduled();
    };
    tick(); timers.push(setInterval(tick, 1000));
    pollStatus();
  }
  async function resolveScheduled() {
    const { data } = await sb.rpc("duel_noshow_check", { p_duel: D.id });
    if (data?.ok) { const nd = await loadDuel(D.id); if (nd.status !== D.status) { D = nd; renderArena(D.id); } }
  }
  // 대기 화면에서 상태 변화 감지(실시간)
  function pollStatus() {
    const ch = sb.channel("duel-wait-" + D.id)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "duels", filter: "id=eq." + D.id },
        p => { if (p.new.status !== D.status) { Object.assign(D, p.new); renderArena(D.id); } });
    ch.subscribe(); chans.push(ch);
  }

  // ═══════════ AI 심판 판정 중 ═══════════
  let judgeTriggered = {};
  async function renderJudging() {
    root().innerHTML = ringHeader() + `
      <div class="duel-card judging-card">
        <div class="judge-orb">⚖️</div>
        <div class="judge-msg">🤖 AI 심판이 대화록을 읽고 판정 중…</div>
        <div class="judge-sub">관중 표심이 갈리지 않아 AI가 승부를 가립니다</div>
      </div>`;
    triggerAiJudge(D.id);
    const ch = sb.channel("duel-judge-" + D.id)
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "duels", filter: "id=eq." + D.id },
        p => { if (p.new.status !== D.status) { Object.assign(D, p.new); renderArena(D.id); } });
    ch.subscribe(); chans.push(ch);
  }
  async function triggerAiJudge(id) {
    if (judgeTriggered[id]) return; judgeTriggered[id] = true;
    try { await sb.functions.invoke("duel-ai-judge", { body: { duel_id: Number(id) } }); } catch (e) {}
    // 폴백: 응답/실시간 누락 대비 재조회
    setTimeout(async () => { const nd = await loadDuel(id); if (nd && nd.status !== D.status) { D = nd; renderArena(id); } }, 4500);
  }

  async function renderClosed() {
    const box = root();
    // 종료된 대결의 변론 로그도 볼 수 있게
    const { data: msgs } = await sb.from("duel_messages").select("*").eq("duel_id", D.id).order("created_at").limit(200);
    const c = D.vote_challenger || 0, o = D.vote_opponent || 0, tot = Math.max(1, c + o);
    const cp = Math.round(c / tot * 100);
    // 🔁 설욕전: 승부가 갈린 판(무승부·무효 제외)에서 '진 당사자'에게만 재도전 버튼
    const isLoser = D._isParty && ME && D.winner && D.result !== "draw"
      && (ME === D.challenger || ME === D.opponent) && ME !== D.winner;
    let banner = "";
    if (D.status === "finished") banner = D.result === "draw" ? "🤝 무승부 — GP 반환" : `🏆 ${esc(nk(D.winner))} 승리 · ${D.stake * 2} GP 획득`;
    else if (D.status === "noshow") banner = `🏳️ ${esc(nk(D.fled_by))} 노쇼 — ${esc(nk(D.winner))} 부전승`;
    else if (D.status === "declined") banner = `🏳️ ${esc(nk(D.fled_by))} 도망 — 위약금 몰수`;
    else banner = "무효 처리됨";
    const hasLog = (msgs || []).length > 0;
    const log = (msgs || []).map(m => `<div class="rmsg ${m.side}"><span class="rmsg-body">${esc(m.body)}</span></div>`).join("");
    const verdictCard = (D.judge === "ai" && D.verdict)
      ? `<div class="duel-card verdict-card">🤖 <b>AI 심판</b> · ${esc(D.verdict)}</div>` : "";
    box.innerHTML = ringHeader() + `
      <div class="duel-card result-banner">${banner}</div>
      ${verdictCard}
      ${(D.status === "finished" || D.status === "noshow") ? `<div class="duel-card result-card">
        <div class="rc-bar"><div class="rc-fill chal" style="width:${cp}%">${c}</div><div class="rc-fill opp" style="width:${100 - cp}%">${o}</div></div>
        <div class="rc-legend"><span>🔵 ${esc(nk(D.challenger))} ${cp}%</span><span>🔴 ${esc(nk(D.opponent))} ${100 - cp}%</span></div></div>` : ""}
      ${hasLog ? `<div class="ring-label">📜 변론 기록</div><div class="ring-stream closed">${log}</div>`
               : `<div class="duel-card closed-note">이 일기토는 변론 없이 종료됐어요.</div>`}
      <div class="closed-acts">
        ${D._isParty && D.status === "declined" ? `<button class="duel-btn primary" id="again">⚔️ 다시 신청</button>` : ""}
        ${isLoser ? `<button class="duel-btn primary rematch-btn" id="rematch"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${DFX.ICON.rematch}</svg> 설욕전 신청</button>` : ""}
        <a class="duel-btn ghost" href="duel.html">로비로</a>
      </div>`;
    const REMATCH_LABEL = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${DFX.ICON.rematch}</svg> 설욕전 신청`;
    // 도망으로 끝난 판은 재도전이 자연스러운 다음 행동 — 로비로 되돌아가 헤매지 않게
    $("#again") && ($("#again").onclick = () => {
      const foe = D.challenger === ME ? D.opponent : D.challenger;
      location.href = `duel.html?challenge=${foe}&issue=${D.issue_id || ""}`;
    });
    // 설욕전 — 진 사람이 같은 상대·주제로 신청서 없이 즉시 재도전
    $("#rematch") && ($("#rematch").onclick = async () => {
      const btn = $("#rematch"); btn.disabled = true; btn.textContent = "신청 중…";
      const { data } = await sb.rpc("duel_rematch", { p_duel: D.id });
      if (!data?.ok) {
        btn.disabled = false; btn.innerHTML = REMATCH_LABEL;
        if (data?.reason === "no_rematch") { alert("설욕전권이 없어요. 상점에서 구매하세요."); return askBuy("duel_rematch_pass"); }
        if (data?.reason === "insufficient") return alert(`대결 GP(${D.stake})가 부족해요.`);
        if (data?.reason === "already") return alert("이미 이 상대와 진행 중인 대결이 있어요.");
        return alert(reason(data?.reason) || "설욕전 신청 실패");
      }
      btn.textContent = "신청 완료!";
      fxRematch();
      finisherToast("설욕전을 신청했어요! 상대의 수락을 기다립니다");
      setTimeout(() => { location.href = "duel.html?id=" + data.id; }, 1700);
    });
  }

  boot();
})();
