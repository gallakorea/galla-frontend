/* =========================================================
   GALLA — Issue Comment Battle System (실데이터 버전)
   - comments / comment_likes / comment_actions 테이블 연동
   - HP·전투 카운터는 battle_action RPC가 서버에서 갱신
========================================================= */

window.CURRENT_ISSUE_ID = null;

let BATTLE_MODE = null;
// BATTLE_MODE = { type: "attack"|"defend", targetId, targetUser } — 인라인 컴포저가 소유

const PAGE_SIZE = 8;

const state = {
  pro: { page: 1, data: [] },
  con: { page: 1, data: [] }
};

/* 로그인 사용자 상태 */
const ME = {
  userId: null,
  faction: null,      // 'pro' | 'con' — 이 이슈에 대한 내 투표(= 내 진영). 없으면 참전 불가
  likes: new Map(),   // comment_id -> 1 | -1
  actions: new Map()  // `${comment_id}:${action_type}` -> 마지막 액션 epoch ms (쿨다운)
};

/* 전투 쿨다운 (서버 battle_action의 c_cooldown과 동일하게 유지) */
const BATTLE_COOLDOWN_MS = 60 * 1000;
function cooldownLeft(commentId, action) {
  const t = ME.actions.get(`${commentId}:${action}`);
  if (!t) return 0;
  return Math.max(0, Math.ceil((t + BATTLE_COOLDOWN_MS - Date.now()) / 1000));
}
function markAction(commentId, action) {
  ME.actions.set(`${commentId}:${action}`, Date.now());
}

/* ⚡ 쿨다운 리셋권 — 쿨다운에 걸렸을 때 보유 시 사용 제안.
   승인되면 RESET_ARMED에 표시 → battle_action 호출에 p_use_reset 전달(서버가 소비) */
const RESET_ARMED = new Set();
/* 🛡↔⚡ 창과 방패 — 보호막 낀 상대를 칠 때 ⚡파쇄를 쓸지 그 자리에서 묻는다.
   (쓰면 방패를 부수고 정상 피해, 안 쓰면 절반 피해로 그냥 때림 — 선택은 유저 몫) */
const BREAK_ARMED = new Set();
async function offerBreaker(commentId) {
  try {
    const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
    const qty = inv.breaker || 0;
    if (qty <= 0) {
      // 살 기회를 그 자리에서 — '상점 가서 사세요' 문구 금지 규약
      ask({ emoji: "🛡", title: "상대가 보호막 중!",
        body: `지금은 피해가 절반(${Math.ceil(BATTLE_DMG.attack / 2)})만 들어가요.\n⚡ 파쇄(500 GP)가 있으면 방패를 부수고 ${BATTLE_DMG.attack} 전부!`,
        ok: "🛒 파쇄 사러 가기", cancel: "그냥 공격" }).then(go => { if (go) window.openShop?.(); });
      return false;
    }
    if (!(await ask({ emoji: "⚡", title: "파쇄로 방패를 부술까요?",
      body: `상대가 🛡 보호막 중이라 피해가 절반만 들어가요.\n파쇄를 쓰면 방패를 부수고 ${BATTLE_DMG.attack} 전부! (보유 ${qty}개)`, ok: "⚡ 파쇄 공격" }))) return false;
    BREAK_ARMED.add(String(commentId));
    return true;
  } catch (_) { return false; }
}
/* ⚡ 파쇄 연출 — 방패가 산산조각 나는 순간. 700GP 쓴 맛이 나야 한다 */
function breakerFx(unit) {
  if (!unit) return;
  try {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)").matches;
    unit.classList.remove("shatter-flash", "shatter-shake");
    void unit.offsetWidth;                       // 애니메이션 재시동
    unit.classList.add("shatter-flash", "shatter-shake");
    // 화면 전체 섬광 — 파쇄는 700GP짜리 순간이다
    const fl = document.createElement("div");
    fl.className = "shatter-screen";
    document.body.appendChild(fl);
    setTimeout(() => fl.remove(), 450);
    setTimeout(() => unit.classList.remove("shatter-flash", "shatter-shake"), 600);
    spawnCombatText?.(unit, "⚡ 방패 파쇄!", "crit");
    window.BattleFX?.banner?.("⚡ 파쇄! 방패가 부서졌다 — 풀데미지", "rally");
    window.BattleFX?.haptic?.("hit");
    if (reduced) return;
    // 유리 파편 — 유닛 중심에서 사방으로 튄다
    const r = unit.getBoundingClientRect();
    const cx = r.left + r.width / 2, cy = r.top + Math.min(r.height / 2, 90);
    for (let i = 0; i < 16; i++) {
      const sh = document.createElement("div");
      sh.className = "shard";
      const size = 6 + Math.random() * 12;
      sh.style.width = size + "px"; sh.style.height = size + "px";
      sh.style.left = cx + "px"; sh.style.top = cy + "px";
      document.body.appendChild(sh);
      const ang = (Math.PI * 2 * i) / 16 + Math.random() * .5;
      const dist = 70 + Math.random() * 130;
      sh.animate([
        { transform: "translate(-50%,-50%) rotate(0deg) scale(1)", opacity: 1 },
        { transform: `translate(calc(-50% + ${Math.cos(ang) * dist}px), calc(-50% + ${Math.sin(ang) * dist + 60}px)) rotate(${(Math.random() - .5) * 720}deg) scale(.4)`, opacity: 0 }
      ], { duration: 550 + Math.random() * 300, easing: "cubic-bezier(.15,.8,.4,1)" }).onfinish = () => sh.remove();
    }
  } catch (_) {}
}

/* 이 유닛이 보호막 중인지 — thread_shields(root:uid) 키맵 */
function isShielded(unit) {
  if (!unit) return false;
  const root = unit.closest(".comment");
  const uid = unit.dataset.uid;
  if (!root || !uid) return false;
  return !!SHIELDS[`${root.dataset.id}:${uid}`];
}
let SHIELDS = {};
/* 활성 보호막을 서버 기준으로 다시 읽어 화면에 반영 (10분 만료라 주기적으로도 갱신) */
async function refreshShields() {
  try {
    const { data } = await window.supabaseClient.rpc("thread_shields", { p_issue: window.CURRENT_ISSUE_ID });
    SHIELDS = data || {};
  } catch (_) { SHIELDS = {}; }
  paintShields();
}
/* 보호막 상태를 유닛에 표시 — 공격자가 '왜 반만 들어가지?'를 바로 알게 */
function paintShields() {
  document.querySelectorAll(".comment, .reply").forEach(el => {
    const on = isShielded(el);
    el.classList.toggle("shielded", on);
    let b = el.querySelector(":scope > .head .shield-badge");
    if (on && !b) {
      const head = el.querySelector(":scope > .head .user");
      head && head.insertAdjacentHTML("beforeend", `<span class="shield-badge" title="보호막 — 받는 피해 절반">🛡</span>`);
    } else if (!on && b) b.remove();
  });
}

/* 기본 confirm은 갈라 톤을 해친다 — 공용 확인 모달로. 미로드 시 confirm 폴백 */
const ask = (o) => window.GALLA_ask ? window.GALLA_ask(o) : Promise.resolve(confirm(o.title + "\n" + (o.body || "")));

/* '상점 가서 사세요'라고 말만 하지 않는다 — 의향을 묻고 그 자리에서 상점을 연다 */
async function askShop(msg) {
  if (!window.openShop) { alert(msg); return; }
  if (await ask({ emoji: "🛒", title: "상점에서 구매할까요?", body: msg, ok: "상점 가기" })) window.openShop();
}

async function offerCooldownReset(commentId, action, waitSec) {
  try {
    const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
    const qty = inv.cooldown_reset || 0;
    if (qty <= 0) {
      askShop(`재시도까지 ${waitSec}초 남았어요.\n⚡ 쿨다운 리셋권(300 GP)이 있으면 기다림 없이 바로 가능해요.`);
      return false;
    }
    if (!(await ask({ emoji: "⚡", title: "쿨다운을 건너뛸까요?",
      body: `재시도까지 ${waitSec}초 남았어요.\n리셋권을 쓰면 바로 실행! (보유 ${qty}개)`, ok: "⚡ 바로 실행" }))) return false;
    RESET_ARMED.add(`${commentId}:${action}`);
    ME.actions.delete(`${commentId}:${action}`); // 로컬 쿨다운 해제
    return true;
  } catch (_) {
    alert(`재시도까지 ${waitSec}초 남았어요.`);
    return false;
  }
}

/* 진영 이름 — 글쓴이가 정한 이름(issues.faction_a/b, issue.js가 window.ISSUE_FACTIONS로 노출).
   👍/👎 아이콘으로 두 편을 가른다. 고정된 '찬성/반대'가 아니다. */
function fName(side) {
  return window.ISSUE_FACTIONS?.[side] || (side === "pro" ? "찬성" : "반대");
}
function fLabel(side) {
  return (side === "pro" ? "👍 " : "👎 ") + fName(side);
}

/* 답글 체인의 최상위(루트) 댓글 id — 스레드는 1depth라 답글의 답글도 루트에 귀속 */
function rootIdOf(id) {
  let cur = allRows.find(r => r.id === id);
  let hop = 0;
  while (cur && cur.parent_id && hop < 20) {
    const p = allRows.find(r => r.id === cur.parent_id);
    if (!p) break;
    cur = p; hop++;
  }
  return cur ? cur.id : id;
}

let allRows = [];     // 이 이슈의 모든 댓글 행
let hlSet = new Set(); // 🚀 하이라이트 부스트된 댓글 id
let replyMap = {};    // parent_id -> [reply rows]
let likeAgg = {};     // comment_id -> { up, down }
let profileMap = {};  // user_id -> { nickname, level }
let authorVoteMap = {}; // user_id -> 'pro'|'con' (이 이슈의 작성자 실제 투표 진영, 침투 노출용)

let eventsBound = false;

// ============================
// 🧩 Comment Text Renderer
// ============================
function renderCommentText(text) {
  if (!text) return "";
  const escaped = text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
  let html = escaped.replace(
    /\[gif:(.*?)\]/g,
    (_, url) => {
      const clean = url.trim().replace(/["'<>]/g, "");
      return /^https:\/\//.test(clean) ? `<img src="${clean}" class="comment-gif" loading="lazy">` : "";
    }
  );
  // 갈라 전용 스티커 [emo:key] → <img> (emoticon.js가 제공)
  if (window.GALLA_renderEmoticons) html = window.GALLA_renderEmoticons(html);
  return html;
}

export async function initCommentSystem(issueId) {
  window.CURRENT_ISSUE_ID = issueId;
  console.log("💬 initCommentSystem:", issueId);

  // SPA 스택 재진입 대비 — 모듈은 1회 평가라 페이지 단위 상태를 여기서 초기화.
  // (MPA 첫 로드에선 어차피 초기값이라 동작 불변)
  state.pro = { page: 1, data: [] };
  state.con = { page: 1, data: [] };
  BATTLE_MODE = null;
  INFILTRATE = false; GHOST_ON = false;
  INFIL_LEFT = null; REPLY_LEFT = null;
  RESET_ARMED.clear(); BREAK_ARMED.clear();
  SHIELDS = {};
  COMBO = { n: 0, t: 0 };

  await new Promise(r => requestAnimationFrame(r));

  const zone = document.getElementById("battle-zone");
  if (!zone) {
    console.warn("[comments] battle-zone not found");
    return;
  }

  // 전선 라벨 = 글쓴이가 정한 진영 이름
  const alPro = document.getElementById("al-pro");
  const alCon = document.getElementById("al-con");
  if (alPro) alPro.textContent = fLabel("pro");
  if (alCon) alCon.textContent = fLabel("con");
  const bdCon = document.getElementById("bd-con-name");
  if (bdCon) bdCon.textContent = fName("con");   // 구분선 '여기부터 OO 진영'
  initZoneIndicator();                            // 🧭 스크롤 추적 현재구역 표시

  await loadComments(issueId);
  await initComposerUI();
  computeAce();
  renderSide("pro");
  renderSide("con");
  renderWarDashboard();
  renderMorale();
  bindEvents();
  startCooldownTicker();
  initBattleFeed(issueId);
  renderHonors();
  // 🛡 활성 보호막 반영 — 10분 만료라 주기적으로도 다시 읽는다(만료되면 배지가 사라져야 함)
  refreshShields();
  // 재init 시 인터벌 중복 방지(실시간 리로드 등)
  if (window.__shieldTimer) clearInterval(window.__shieldTimer);
  window.__shieldTimer = setInterval(refreshShields, 60000);

  // 투표수가 (재)로드되면 전선 게이지의 '여론' 축을 즉시 반영
  if (!window.__GALLA_FRONTLINE_SYNC__) {
    window.__GALLA_FRONTLINE_SYNC__ = true;
    window.addEventListener("galla:votes", () => renderMorale());
  }

  // 페이지를 연 뒤 투표하면 컴포저/전투버튼이 즉시 풀리도록 (새로고침 불필요)
  if (!window.__GALLA_VOTE_SYNC__) {
    window.__GALLA_VOTE_SYNC__ = true;
    document.addEventListener("galla:voted", async (e) => {
      const f = e.detail?.faction;
      if (f !== "pro" && f !== "con") return;
      if (ME.faction === f) return;
      ME.faction = f;
      window.MY_VOTE_TYPE = f;
      authorVoteMap[ME.userId] = f;   // 침투 노출 판정에 내 진영 반영
      await initComposerUI();
      renderSide("pro");
      renderSide("con");
      renderMorale();
    });
  }
}

/* ======================
   컴포저 UI — 내 진영 상태 / 적진 침투 모드
====================== */
let INFILTRATE = false;      // 침투 모드 (상대 진영으로 글쓰기)
let INFIL_LEFT = null;       // 오늘 남은 침투 횟수
let REPLY_LEFT = null;       // 오늘 남은 대댓글 횟수 (기본 40/일)
let GHOST_ON = false;        // 👻 유령(익명) 참전 모드 (유령권 필요)

// 유령 상태·토글은 공용 ghost.js(GALLA_ghostReady/GALLA_ghostBind)가 담당

/* 🗯️ 대댓글 연장권 — 하루 한도 소진 시 보유하면 사용 제안(+15). 침투권과 동일 패턴 */
async function ensureReplyQuota() {
  if (REPLY_LEFT === null) {
    try { const { data } = await window.supabaseClient.rpc("reply_status"); REPLY_LEFT = data?.left ?? 40; }
    catch (_) { REPLY_LEFT = 40; }
  }
  if (REPLY_LEFT > 0) return true;
  // 소진 → 연장권 제안
  const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
  if ((inv.reply_pass || 0) <= 0) {
    askShop("오늘의 대댓글 횟수(40회)를 모두 썼어요.\n🗯️ 대댓글 연장권(+15회, 300 GP)으로 바로 이어갈 수 있어요.");
    return false;
  }
  if (!confirm(`오늘 대댓글 40회를 다 썼어요.\n🗯️ 대댓글 연장권을 써서 15회 더 이어갈까요? (보유 ${inv.reply_pass})`)) return false;
  const { data: ur } = await window.supabaseClient.rpc("use_reply_pass");
  if (!ur?.ok) { alert("연장권 사용에 실패했어요."); return false; }
  REPLY_LEFT += 15;
  window.BattleFX?.banner?.("🗯️ 대댓글 연장권 사용! +15", "cheer");
  return true;
}

async function initComposerUI() {
  const bottom = document.querySelector(".battle-input-bottom");
  const input = document.getElementById("battle-comment-input");
  if (!bottom) return;

  // 미투표: 잠금 안내 — 진영은 투표로만 정해진다
  if (!ME.faction) {
    bottom.innerHTML = `
      <div class="composer-side locked" id="composer-side">
        <span class="cs-flag">🔒 위에서 투표해 진영을 정하면 참전할 수 있어요</span>
      </div>`;
    if (input) input.placeholder = "투표하고 참전하세요…";
    return;
  }

  // 투표자: 내 진영 상태바 + 침투 버튼
  const my = ME.faction;
  const myLabel = fLabel(my);
  const enemyLabel = fLabel(my === "pro" ? "con" : "pro");

  const { data: st } = await window.supabaseClient.rpc("infiltration_status");
  INFIL_LEFT = st?.left ?? 3;
  try { const { data: rs } = await window.supabaseClient.rpc("reply_status"); REPLY_LEFT = rs?.left ?? 40; }
  catch (_) { REPLY_LEFT = 40; }

  bottom.innerHTML = `
    <div class="composer-side ${my}" id="composer-side">
      <span class="cs-flag">🎖 ${myLabel} 진영으로 참전 중</span>
      <button type="button" class="ghost-toggle sm" id="ghost-toggle"><span class="gt-ic">👻</span> 유령</button>
      <button type="button" class="infiltrate-btn" id="infiltrate-btn">
        🕵️ 적진 침투 <b id="infil-left">${INFIL_LEFT}</b>/3
      </button>
    </div>`;
  if (input) input.placeholder = "아군 전선에 새 의견 쓰기…";

  // 👻 유령 토글 — 공용 바인더(ghost.js: 상태 라벨·페르소나 토스트·구매 유도 내장)
  if (window.GALLA_ghostBind) {
    window.GALLA_ghostBind(document.getElementById("ghost-toggle"), {
      onChange: (on) => {
        GHOST_ON = on;
        if (input) input.placeholder = on ? "👻 유령으로 참전 중…" : (INFILTRATE ? input.placeholder : "아군 전선에 새 의견 쓰기…");
        window.BattleFX?.haptic?.("tap");
      },
    });
  }

  document.getElementById("infiltrate-btn").addEventListener("click", async () => {
    if (!INFILTRATE && INFIL_LEFT <= 0) {
      // 🕵️ 침투권 보유 시 한도 +1 제안
      const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
      const passes = inv.infiltrate_pass || 0;
      if (passes <= 0) {
        askShop("오늘의 침투 횟수를 모두 썼어요.\n🕵️ 침투권(500 GP)이 있으면 한도 +1이에요.");
        return;
      }
      if (!confirm(`오늘 침투 한도를 모두 썼어요.\n🕵️ 침투권을 사용해 한도를 +1 할까요? (보유 ${passes}개)`)) return;
      const { data: ur } = await window.supabaseClient.rpc("use_infiltrate_pass");
      if (!ur?.ok) { alert("침투권 사용에 실패했어요."); return; }
      INFIL_LEFT += 1;
      const cntEl = document.getElementById("infil-left");
      if (cntEl) cntEl.textContent = INFIL_LEFT;
      window.BattleFX?.banner?.("🕵️ 침투권 사용! 한도 +1", "cheer");
    }
    INFILTRATE = !INFILTRATE;
    const box = document.getElementById("composer-side");
    box.classList.toggle("infiltrating", INFILTRATE);
    box.querySelector(".cs-flag").innerHTML = INFILTRATE
      ? `🕵️ <b>${enemyLabel} 진영 침투 모드</b> — 적진에 글이 올라갑니다`
      : `🎖 ${myLabel} 진영으로 참전 중`;
    if (input) input.placeholder = INFILTRATE
      ? `적진에 침투 글 쓰기… (오늘 ${INFIL_LEFT}회 남음)`
      : "아군 전선에 새 의견 쓰기…";
    window.BattleFX?.haptic("tap");
  });
}

function consumeInfiltration() {
  INFIL_LEFT = Math.max(0, (INFIL_LEFT ?? 3) - 1);
  const el = document.getElementById("infil-left");
  if (el) el.textContent = INFIL_LEFT;
  // 모드 해제 (1회 소모 후 복귀)
  INFILTRATE = false;
  const box = document.getElementById("composer-side");
  if (box) {
    box.classList.remove("infiltrating");
    box.querySelector(".cs-flag").innerHTML = `🎖 ${fLabel(ME.faction)} 진영으로 참전 중`;
  }
  const input = document.getElementById("battle-comment-input");
  if (input) input.placeholder = "아군 전선에 새 의견 쓰기…";
}

/* ======================
   💬 진영 작전회의 — 실시간 진영 전용 채팅 (상대 진영 입장 불가, RLS 강제)
====================== */
let CHAT_CHANNEL = null;
let CHAT_OPEN = false;

function chatRoomLabel() {
  return `${fLabel(ME.faction)} 진영 채팅방`;
}

function ensureChatUI() {
  let sheet = document.getElementById("faction-chat");
  if (sheet) return sheet;
  sheet = document.createElement("div");
  sheet.id = "faction-chat";
  sheet.className = "faction-chat " + (ME.faction || "");
  sheet.innerHTML = `
    <div class="fc-dim"></div>
    <div class="fc-sheet">
      <div class="fc-head">
        <span class="fc-title">${chatRoomLabel()}</span>
        <span class="fc-live">LIVE</span>
        <button class="fc-close" aria-label="닫기">✕</button>
      </div>
      <div class="fc-notice">🔒 우리 진영만 볼 수 있는 방입니다. 작전을 논의하세요!</div>
      <button class="fc-nanjang" id="fc-nanjang" type="button">
        🔥 난장으로 판 키우기 <i>이미지·투표·실시간 대군… 아군 총집결</i>
      </button>
      <div class="fc-list" id="fc-list"></div>
      <div class="fc-inputrow">
        <input id="fc-input" maxlength="500" placeholder="아군에게 메시지 보내기…">
        <button id="fc-send">전송</button>
      </div>
    </div>`;
  document.body.appendChild(sheet);

  sheet.querySelector(".fc-dim").onclick = closeFactionChat;
  sheet.querySelector(".fc-close").onclick = closeFactionChat;
  sheet.querySelector("#fc-nanjang").onclick = escalateToNanjang;
  const input = sheet.querySelector("#fc-input");
  const send = () => sendFactionChat(input);
  sheet.querySelector("#fc-send").onclick = send;
  input.addEventListener("keydown", e => { if (e.key === "Enter") send(); });
  return sheet;
}

function chatMsgHTML(m, prepend = false) {
  const mine = m.user_id === ME.userId;
  const nick = mine ? "" : `<div class="fc-nick">${escT(actorName(m.user_id))}</div>`;
  const t = new Date(m.created_at || Date.now());
  const hh = String(t.getHours()).padStart(2, "0") + ":" + String(t.getMinutes()).padStart(2, "0");
  return `<div class="fc-msg ${mine ? "mine" : ""}">
    ${nick}
    <div class="fc-row">
      ${mine ? `<span class="fc-time">${hh}</span>` : ""}
      <div class="fc-bubble">${escT(m.content)}</div>
      ${mine ? "" : `<span class="fc-time">${hh}</span>`}
    </div>
  </div>`;
}

async function openFactionChat() {
  const supabase = window.supabaseClient;
  if (!ME.faction) {
    alert("진영 작전회의는 투표한 사람만 입장할 수 있어요. 먼저 투표해 주세요!");
    return;
  }
  const sheet = ensureChatUI();
  sheet.classList.add("open");
  CHAT_OPEN = true;
  window.BattleFX?.haptic("tap");
  refreshNanjangBadge();   // 🔥 이미 열린 진영 난장이 있으면 '재입장 · N명' 배지

  // 최근 50개 로드 (RLS가 내 진영만 반환)
  const list = document.getElementById("fc-list");
  list.innerHTML = `<div class="fc-loading">불러오는 중…</div>`;
  const { data: msgs, error } = await supabase
    .from("faction_chats")
    .select("id,user_id,content,created_at")
    .eq("issue_id", window.CURRENT_ISSUE_ID)
    .eq("faction", ME.faction)
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) { list.innerHTML = `<div class="fc-loading">채팅을 불러오지 못했어요.</div>`; return; }

  const rows = (msgs || []).reverse();
  await fetchFeedNicks(rows.map(m => m.user_id));
  list.innerHTML = rows.length
    ? rows.map(m => chatMsgHTML(m)).join("")
    : `<div class="fc-loading">아직 메시지가 없어요. 첫 작전을 지시하세요!</div>`;
  list.scrollTop = list.scrollHeight;

  // 실시간 구독 (RLS 덕에 상대 진영 메시지는 아예 수신 안 됨)
  if (CHAT_CHANNEL) { supabase.removeChannel(CHAT_CHANNEL); CHAT_CHANNEL = null; }
  CHAT_CHANNEL = supabase
    .channel("fchat-" + window.CURRENT_ISSUE_ID + "-" + ME.faction)
    .on("postgres_changes", {
      event: "INSERT", schema: "public", table: "faction_chats",
      filter: "issue_id=eq." + window.CURRENT_ISSUE_ID
    }, async payload => {
      const m = payload.new;
      if (m.faction !== ME.faction) return;            // 안전망 (RLS가 1차 차단)
      if (m.user_id === ME.userId) return;             // 내 메시지는 전송 시 이미 그림
      await fetchFeedNicks([m.user_id]);
      const l = document.getElementById("fc-list");
      if (!l) return;
      l.querySelector(".fc-loading")?.remove();
      l.insertAdjacentHTML("beforeend", chatMsgHTML(m));
      l.scrollTop = l.scrollHeight;
      window.BattleFX?.haptic("tap");
    })
    .subscribe();
}

function closeFactionChat() {
  const sheet = document.getElementById("faction-chat");
  sheet?.classList.remove("open");
  CHAT_OPEN = false;
  if (CHAT_CHANNEL) { window.supabaseClient.removeChannel(CHAT_CHANNEL); CHAT_CHANNEL = null; }
}

/* 🔥 난장 파이프라인 — 같은 편만. 이슈×진영 전용 난장(kind='faction')을 찾거나 만들고 입장.
   서버(issue_faction_room)가 '내 투표=이 진영'을 검증하므로 적군은 애초에 못 들어온다.
   (반대 진영을 한 방에 몰아넣는 유도는 없음 — 그건 개싸움이 되니까. 각 진영은 각자의 난장.) */
/* 이미 열린 우리 진영 난장이 있으면 버튼을 '재입장 · N명 참전 중'으로 — issue_faction_room_peek */
async function refreshNanjangBadge() {
  const btn = document.getElementById("fc-nanjang");
  if (!btn) return;
  try {
    const { data } = await window.supabaseClient.rpc("issue_faction_room_peek", { p_issue: window.CURRENT_ISSUE_ID });
    const row = Array.isArray(data) ? data[0] : data;
    if (row && row.room_id) {
      btn.classList.add("live");
      btn.innerHTML = `🔥 난장 다시 입장 <i>이미 ${row.member_count}명 참전 중 · 아군 총집결</i>`;
    }
  } catch (_) {}
}

let NANJANG_BUSY = false;
async function escalateToNanjang() {
  if (NANJANG_BUSY) return;
  const supabase = window.supabaseClient;
  if (!ME.faction) { alert("난장은 투표한 사람만 — 먼저 진영을 정해 주세요!"); return; }
  const btn = document.getElementById("fc-nanjang");
  NANJANG_BUSY = true;
  if (btn) { btn.disabled = true; btn.dataset.label = btn.innerHTML; btn.innerHTML = "🔥 난장 판 까는 중…"; }
  try {
    const { data: rid, error } = await supabase.rpc("issue_faction_room", { p_issue: window.CURRENT_ISSUE_ID });
    if (error || !rid) {
      const msg = error?.message === "no_vote"
        ? "투표한 사람만 난장에 참전할 수 있어요."
        : "난장을 여는 데 실패했어요 — 잠시 후 다시 시도해 주세요.";
      alert(msg);
      return;
    }
    window.BattleFX?.haptic("heavy");
    // 난장(DM 페이지)으로 이동 — 딥링크가 방을 바로 연다
    location.href = "dm.html?room=" + encodeURIComponent(rid);
  } catch (e) {
    console.error("[nanjang] escalate", e);
    alert("난장을 여는 데 실패했어요.");
  } finally {
    NANJANG_BUSY = false;
    if (btn) { btn.disabled = false; if (btn.dataset.label) btn.innerHTML = btn.dataset.label; }
  }
}

async function sendFactionChat(input) {
  const content = (input.value || "").trim();
  if (!content) return;
  const supabase = window.supabaseClient;
  input.value = "";

  const { data, error } = await supabase.from("faction_chats").insert({
    issue_id: window.CURRENT_ISSUE_ID,
    user_id: ME.userId,
    faction: ME.faction,
    content
  }).select("id,user_id,content,created_at").single();

  if (error) {
    console.error("[fchat] send failed", error);
    alert("전송에 실패했어요. 진영 투표 상태를 확인해 주세요.");
    return;
  }
  const l = document.getElementById("fc-list");
  l.querySelector(".fc-loading")?.remove();
  l.insertAdjacentHTML("beforeend", chatMsgHTML(data));
  l.scrollTop = l.scrollHeight;
}

/* ======================
   게임 유틸 (HP 티어 / 전투력 / 에이스 / FX)
====================== */
let ACE = { pro: null, con: null };

function hpTier(hp) {
  if (hp <= 0) return "ko";
  if (hp <= 30) return "lo";
  if (hp <= 60) return "mid";
  return "hi";
}
/* ============================================================
   전선 점수 설계 (승패 요인)
     최종 = 여론(투표) × 0.6  +  댓글대전 × 0.4
   댓글 하나의 '영향력' = 생존도 × 설득력 × 가중치
     생존도 = HP/100        → 격파(HP 0)당하면 영향력 0 (공격에 의미가 생김)
     설득력 = 1 + 추천 + 지원받음 + 방어받음×0.5 − 반대×0.5
     가중치 = 본댓글 1.0 / 대댓글 0.5
   ⚠️ 기존 식은 '받은 공격'이 점수를 올려(맞을수록 강해짐) 공격할 이유가 없었고,
      HP 100이 기본이라 내용 없이 댓글만 많이 써도 이기는 물량전이었다.
============================================================ */
const W_VOTE = 0.6;    // 여론(투표) 비중
const W_BATTLE = 0.4;  // 댓글 대전 비중

function influence(c) {
  const agg = likeAgg[c.id] || { up: 0, down: 0 };
  const survival = Math.max(0, Math.min(100, c.hp | 0)) / 100;   // 격파 = 0
  const persuasion = 1
    + (agg.up || 0)
    + (c.support_count || 0)
    + (c.defense_count || 0) * 0.5
    - (agg.down || 0) * 0.5;
  const weight = c.parent_id ? 0.5 : 1;                          // 대댓글은 절반
  return survival * Math.max(0, persuasion) * weight;
}

// 화면 표시용(댓글 칩) — 소수 첫째자리
function combatPower(c) {
  return Math.round(influence(c) * 10) / 10;
}

/* 종료 카운트다운 / 정산 결과 배너
   - 진행 중: 남은 시간 (7일 뒤 자동 종료)
   - 종료됨: 승리 진영 + 최종 구성(여론/대전) */
function settleBannerHTML() {
  const iss = window.GALLA_ISSUE;
  if (!iss || !iss.ends_at) return "";

  if (iss.settled_at && iss.winner) {
    const w = iss.winner;
    if (w === "draw") {
      return `<div class="fl-settled draw">🤝 <b>무승부</b> — 전선 50 : 50으로 끝났습니다.</div>`;
    }
    const pct = w === "pro" ? iss.final_pro_pct : 100 - iss.final_pro_pct;
    const vp = w === "pro" ? iss.final_vote_pct : 100 - iss.final_vote_pct;
    const bp = w === "pro" ? iss.final_battle_pct : 100 - iss.final_battle_pct;
    return `<div class="fl-settled ${w}">
      🏆 <b>${fLabel(w)} 진영 승리</b> · 최종 ${Math.round(pct)}%
      <small>여론 ${Math.round(vp)}% · 댓글 대전 ${Math.round(bp)}%</small>
    </div>`;
  }

  const left = new Date(iss.ends_at).getTime() - Date.now();
  if (left <= 0) return `<div class="fl-countdown ending">⏳ 종료 — 곧 결과가 확정됩니다</div>`;
  const d = Math.floor(left / 86400000);
  const h = Math.floor((left % 86400000) / 3600000);
  const m = Math.floor((left % 3600000) / 60000);
  const t = d > 0 ? `${d}일 ${h}시간` : h > 0 ? `${h}시간 ${m}분` : `${m}분`;
  return `<div class="fl-countdown${d === 0 ? " urgent" : ""}">⏳ 종료까지 <b>${t}</b> — 끝나면 승리 진영에 <b>GP 보상</b></div>`;
}

/* 전선 종합: 여론·대전·최종 비율(모두 pro 기준 0~1) */
function frontline() {
  let bPro = 0, bCon = 0;
  allRows.forEach(r => {
    const inf = influence(r);
    if (r.faction === "pro") bPro += inf;
    else if (r.faction === "con") bCon += inf;
  });
  const bTot = bPro + bCon;
  const battlePro = bTot > 0 ? bPro / bTot : 0.5;   // 댓글 없으면 중립

  const v = window.GALLA_ISSUE_VOTES || { pro: 0, con: 0 };
  const vTot = (v.pro || 0) + (v.con || 0);
  const votePro = vTot > 0 ? v.pro / vTot : 0.5;    // 투표 없으면 중립

  const finalPro = votePro * W_VOTE + battlePro * W_BATTLE;
  return {
    votePro, battlePro, finalPro,
    battleRaw: { pro: bPro, con: bCon },
    votes: v, hasVotes: vTot > 0, hasBattle: bTot > 0,
  };
}
function computeAce() {
  ACE = { pro: null, con: null };
  ["pro", "con"].forEach(side => {
    let best = null;
    allRows.forEach(r => {
      if (r.faction !== side || r.hp <= 0) return;
      if (!best || r.hp > best.hp || (r.hp === best.hp && combatPower(r) > combatPower(best))) best = r;
    });
    if (best) ACE[side] = best.id;
  });
}

/* HP 바 마크업 (티어 색 + 격파 상태) */
function hpBarHTML(c) {
  const hp = Math.max(0, c.hp | 0);
  const tier = hpTier(c.hp);
  return `
    <div class="hp-wrap ${tier === "ko" ? "ko" : ""}">
      <div class="hp-bar hp-${tier}">
        <div class="hp-ghost" style="width:${hp}%"></div>
        <div class="hp-fill" style="width:${hp}%"></div>
      </div>
      <span class="hp-text">${hp <= 0 ? "💀 격파" : "HP " + hp}</span>
      ${hp <= 0 && ME.userId && c.user_id === ME.userId
        ? `<button class="revive-btn" data-id="${c.id}">✨ 부활</button>` : ""}
    </div>`;
}

/* 플로팅 전투 텍스트 (-12 / +8 / +12 CRIT 등) */
function spawnCombatText(unit, text, kind) {
  if (!unit) return;
  const el = document.createElement("div");
  el.className = "combat-float " + kind;
  el.textContent = text;
  unit.appendChild(el);
  setTimeout(() => el.remove(), 1100);
}

/* 전투 보상 연출 — battle_action 반환의 reward/ko를 GP 배너로. (서버가 무료 GP 지급) */
function showBattleReward(bd) {
  if (!bd || !bd.ok) return;
  const FX = window.BattleFX;
  const rw = bd.reward || {};
  const gp = Number(rw.gp || 0);
  if (gp > 0) {
    const label = rw.kind === "ko"    ? `💥 격파 성공! +${gp} GP · 전공 +1`
                : rw.kind === "guard" ? `🛡 아군 수호! +${gp} GP`
                : `+${gp} GP`;
    FX?.banner?.(label, "cheer");
    FX?.haptic?.("cheer");
    document.dispatchEvent(new CustomEvent("galla:gp-changed"));
  } else if (bd.ko && bd.refarm) {
    FX?.banner?.("💥 격파! (재격파는 보상 없음)", "info");
  } else if (bd.ko) {
    FX?.banner?.("💥 격파! (오늘 전투 보상 한도 도달)", "info");
  } else if ((rw.kind === "guard") && gp === 0) {
    FX?.banner?.("🛡 수호! (오늘 전투 보상 한도 도달)", "info");
  }
}
/* 피격/힐 임팩트 */
function hitFx(unit, kind) {
  if (!unit) return;
  unit.classList.remove("fx-hit", "fx-heal");
  void unit.offsetWidth; // reflow로 애니메이션 리셋
  unit.classList.add(kind === "heal" ? "fx-heal" : "fx-hit");
  setTimeout(() => unit.classList.remove("fx-hit", "fx-heal"), 600);
}
/* HP 바 즉시 갱신(격파 반영) */
/* HP는 (스레드, 유저) 풀이라 한 명을 때리면 그 사람의 '스레드 내 모든 댓글'이 함께 내려간다.
   서버(_sync_pool_hp)가 DB를 그렇게 갱신하므로 화면도 같이 반영해야 진실이 맞는다. */
function applyPoolHp(targetUnit, hp) {
  if (!targetUnit) return;
  const uid = targetUnit.dataset.uid;
  const root = targetUnit.closest(".comment");
  if (!uid || !root) { applyHpToUnit(targetUnit, hp); return; }
  const scope = [root, ...root.querySelectorAll(".reply")];
  scope.filter(el => el.dataset.uid === uid).forEach(el => applyHpToUnit(el, hp));
}

function applyHpToUnit(unit, hp) {
  if (!unit) return;
  const clamped = Math.max(0, hp | 0);
  unit.dataset.hp = clamped;
  const bar = unit.querySelector(".hp-bar");
  const fill = unit.querySelector(".hp-fill");
  const ghost = unit.querySelector(".hp-ghost");
  const text = unit.querySelector(".hp-text");
  if (fill) fill.style.width = clamped + "%";
  if (ghost) setTimeout(() => { ghost.style.width = clamped + "%"; }, 260);
  if (text) text.textContent = clamped <= 0 ? "💀 격파" : "HP " + clamped;
  if (bar) { bar.className = "hp-bar hp-" + hpTier(hp); }
  const wrap = unit.querySelector(".hp-wrap");
  if (wrap) wrap.classList.toggle("ko", clamped <= 0);
  if (clamped <= 0) unit.classList.add("ko");
}

/* 진영 사기 게이지 (전투력 tug-of-war) */
function renderMorale() {
  const host = document.querySelector(".comment-war-header");
  if (!host) return;
  let bar = document.getElementById("battle-morale");
  if (!bar) {
    bar = document.createElement("div");
    bar.id = "battle-morale";
    bar.className = "battle-morale";
    host.appendChild(bar);
  }
  const F = frontline();
  const proPct = Math.round(F.finalPro * 100);
  const votePct = Math.round(F.votePro * 100);
  const battlePct = Math.round(F.battlePro * 100);
  const lead = proPct > 50 ? "pro" : proPct < 50 ? "con" : "even";

  // 여론에서 지고 있는데 최종은 이기고 있으면 '역전 중' — 댓글 대전의 가치를 즉시 체감시킨다
  const flipPro = votePct < 50 && proPct > 50;
  const flipCon = votePct > 50 && proPct < 50;
  const status = flipPro || flipCon
    ? `🔥 여론은 밀리지만 <b>댓글 대전 우세로 역전 중!</b>`
    : lead === "even" ? "⚖️ 팽팽한 접전" : `${fLabel(lead)} 진영 우세`;

  bar.innerHTML = `
    ${settleBannerHTML()}
    <div class="bm-top">
      <span class="bm-side pro ${lead === "pro" ? "lead" : ""}">${fLabel("pro")} ${proPct}%</span>
      <span class="bm-vs">전선</span>
      <span class="bm-side con ${lead === "con" ? "lead" : ""}">${100 - proPct}% ${fName("con")} 👎</span>
    </div>
    <div class="bm-track">
      <div class="bm-pro" style="width:${proPct}%"></div>
      <div class="bm-con" style="width:${100 - proPct}%"></div>
      <div class="bm-needle" style="left:${proPct}%"></div>
    </div>
    <div class="bm-status ${flipPro || flipCon ? "flip" : ""}">${status} · ${proPct}%</div>

    <!-- 최종 점수가 무엇으로 만들어지는지 분해해서 보여준다 → '댓글을 왜 쓰는가'가 명확해짐 -->
    <div class="fl-break">
      <div class="fl-row">
        <span class="fl-name">🗳 여론<em>60%</em></span>
        <span class="fl-mini"><i class="fl-p" style="width:${votePct}%"></i></span>
        <span class="fl-val">${votePct}<small>%</small></span>
      </div>
      <div class="fl-row">
        <span class="fl-name">⚔️ 댓글 대전<em>40%</em></span>
        <span class="fl-mini"><i class="fl-p" style="width:${battlePct}%"></i></span>
        <span class="fl-val">${battlePct}<small>%</small></span>
      </div>
      <div class="fl-hint">추천·지원을 받으면 <b>영향력</b>이 오르고, <b>격파</b>당하면 0이 됩니다 — 댓글 대전이 전선의 40%를 움직입니다.</div>
    </div>
    <div class="bm-war">
      <div class="bmw-box pro">
        <div class="bmw-label">👍 ${fLabel("pro")}</div>
        <div class="bmw-stat">총 댓글 <b id="stat-pro-total">0</b></div>
        <div class="bmw-sub">동진영 <span id="stat-pro-same">0</span> · 적진 <span id="stat-pro-oppo">0</span></div>
      </div>
      <div class="bmw-box neutral">
        <div class="bmw-label">⚡ 전체 전장</div>
        <div class="bmw-stat">총 교전 <b id="stat-total">0</b></div>
        <div class="bmw-sub">💥<span id="stat-atk">0</span> · 💣<span id="stat-sup">0</span> · 🛡<span id="stat-def">0</span></div>
      </div>
      <div class="bmw-box con">
        <div class="bmw-label">👎 ${fLabel("con")}</div>
        <div class="bmw-stat">총 댓글 <b id="stat-con-total">0</b></div>
        <div class="bmw-sub">동진영 <span id="stat-con-same">0</span> · 적진 <span id="stat-con-oppo">0</span></div>
      </div>
    </div>
    ${ME.faction
      ? `<div class="bm-mine ${ME.faction}">🎖 내 진영: ${fLabel(ME.faction)} — <b>적군</b>을 공격하고 <b>아군</b>을 지켜라!</div>
         <button type="button" class="fc-enter ${ME.faction}" id="fc-open">
           <span class="fc-enter-ico">💬</span>
           <span class="fc-enter-tx">
             <b>실시간 진영 채팅방 <span class="fc-enter-live">LIVE</span></b>
             <small>우리 ${fLabel(ME.faction)} 진영끼리만 · 지금 입장해 대화하기</small>
           </span>
           <span class="fc-enter-arrow">›</span>
         </button>`
      : `<div class="bm-mine none">🔒 위에서 투표하면 진영이 정해지고 참전할 수 있어요</div>`}`;

  const openBtn = bar.querySelector("#fc-open");
  if (openBtn) openBtn.onclick = openFactionChat;

  // 슬림 전황 수치 채우기 (전황표 3박스를 이 한 줄로 통합)
  renderWarDashboard();
  renderBillboard();        // 🏆 명예의 전당(빌보드) 복원 — 항상 최신 상태와 동기화
}

/* 🏆 명예의 전당(빌보드) — 영향력 최상위 댓글 TOP3(진영색). 클릭 시 그 댓글로 스크롤.
   b1ebefb 단일리스트 개편 때 사라졌던 빌보드 복원(사장님 요청). allRows만 써서 추가쿼리 0. */
function renderBillboard() {
  const host = document.querySelector(".comment-war-header");
  if (!host) return;
  const ranked = allRows
    .filter(c => (c.faction === "pro" || c.faction === "con") && influence(c) > 0)
    .sort((a, b) => influence(b) - influence(a))
    .slice(0, 3);
  let box = document.getElementById("battle-billboard");
  if (!ranked.length) { if (box) box.remove(); return; }
  if (!box) {
    box = document.createElement("div");
    box.id = "battle-billboard";
    box.className = "billboard-board";
    (document.getElementById("battle-morale") || host).after(box);
  }
  const medals = ["🥇", "🥈", "🥉"];
  const nameOf = (c) => c.is_anonymous ? "익명 전사" : (profileMap[c.user_id]?.nickname || actorName(c.user_id));
  box.innerHTML = `<div class="bb-title">🏆 명예의 전당 · 최강 전사</div>
    <div class="bb-list">` + ranked.map((c, i) => `
      <button type="button" class="bb-card ${c.faction}" data-goto="${c.id}">
        <span class="bb-rank">${medals[i]}</span>
        <span class="bb-mid">
          <b class="bb-name">${c.faction === "pro" ? "👍" : "👎"} ${escT(nameOf(c))}</b>
          <span class="bb-quote">${escT((c.content || "").replace(/\s+/g, " ").slice(0, 42))}</span>
        </span>
        <span class="bb-power">⚡${combatPower(c)}</span>
      </button>`).join("") + `</div>`;
  box.querySelectorAll("[data-goto]").forEach(btn => {
    btn.onclick = () => scrollToComment(btn.dataset.goto);
  });
}
function scrollToComment(id) {
  const el = document.querySelector(`.comment[data-id="${id}"], .reply[data-id="${id}"]`);
  if (!el) return;
  el.scrollIntoView({ behavior: "smooth", block: "center" });
  el.classList.add("hl");
  setTimeout(() => el.classList.remove("hl"), 1600);
}

/* 🧭 현재 진영 구역 표시 — 스크롤에 따라 지금 보는 구역(찬/반)을 fixed 배지로 항상 노출.
   overflow-x:hidden 환경이라 CSS sticky가 불안정 → fixed + 스크롤 계산으로 확실하게 잡는다. */
let ZONE_LST = null;   // { target, onScroll } — unmount/재init 시 해제용
function unbindZoneIndicator() {
  if (!ZONE_LST) return;
  try { ZONE_LST.target.removeEventListener("scroll", ZONE_LST.onScroll); } catch (_) {}
  try { window.removeEventListener("resize", ZONE_LST.onScroll); } catch (_) {}
  ZONE_LST = null;
}
function initZoneIndicator() {
  const ind = document.getElementById("zone-indicator");
  if (!ind) return;
  const hide = () => { if (!ind.hidden) { ind.hidden = true; ind.setAttribute("aria-hidden", "true"); } };
  const update = () => {
    const pro = document.getElementById("pro-list");
    const con = document.getElementById("con-list");
    if (!pro || !con) return hide();
    const refY = 96;                       // 헤더(64) 아래 기준선
    const pr = pro.getBoundingClientRect();
    const cr = con.getBoundingClientRect();
    const div = document.querySelector(".battle-divider");
    let side = null;
    if (cr.top <= refY && cr.bottom >= refY) side = "con";
    else if (pr.top <= refY && pr.bottom >= refY) side = "pro";
    else if (div) {                        // 리스트 사이 여백(구분선 근처) 보정
      const dr = div.getBoundingClientRect();
      if (pr.bottom <= refY && dr.bottom >= refY) side = "pro";
      else if (dr.top <= refY && cr.top >= refY) side = "con";
    }
    if (!side) return hide();
    ind.hidden = false; ind.setAttribute("aria-hidden", "false");
    ind.className = "zone-indicator " + side;
    ind.querySelector(".zi-ico").textContent = side === "pro" ? "👍" : "👎";
    ind.querySelector(".zi-name").textContent = " " + fName(side);
  };
  update();
  // 재init(SPA 재진입 포함) — 이전 리스너를 걷고 새 DOM에 다시 건다
  unbindZoneIndicator();
  let ticking = false;
  const onScroll = () => {
    if (ticking) return; ticking = true;
    requestAnimationFrame(() => { update(); ticking = false; });
  };
  // 스크롤 컨테이너: SPA 스택 뷰는 .view-host가 자체 스크롤(window 스크롤 이벤트가 안 옴).
  // MPA에선 .view-host가 없어 기존처럼 window.
  const target = document.getElementById("battle-zone")?.closest(".view-host") || window;
  target.addEventListener("scroll", onScroll, { passive: true });
  window.addEventListener("resize", onScroll, { passive: true });
  ZONE_LST = { target, onScroll };
}

/* ======================
   실시간 전장 (킬 피드 / HP 동기화 / 격파 배너 / 전공 / 콤보)
====================== */
let FEED_CHANNEL = null;
let feedNickCache = {};          // user_id → nickname
let COMBO = { n: 0, t: 0 };      // 연속 참전 콤보 (10초 창)

function escT(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function actorName(uid) {
  if (!uid) return "익명";
  return feedNickCache[uid] || profileMap[uid]?.nickname || "익명 전사";
}
async function fetchFeedNicks(ids) {
  const need = [...new Set(ids.filter(u => u && !feedNickCache[u] && !profileMap[u]))];
  if (!need.length) return;
  const { data } = await window.supabaseClient
    .from("user_profiles").select("user_id,nickname").in("user_id", need);
  (data || []).forEach(p => { feedNickCache[p.user_id] = p.nickname; });
}

/* ⚔️ 전투 수치 — 서버 battle_action(c_atk/c_def/c_sup)과 반드시 동일하게 유지.
   v2(2026-07-16): 힐 < 공격이어야 격파가 가능하다. HP는 (스레드,유저) 풀 공유이며
   유효회복 = min(총회복, 총피해×0.3) 이라 지원을 아무리 눌러도 누적피해 143이면 격파. */
const BATTLE_DMG = { attack: 14, defend: 6, support: 8 };
const ACTION_META = {
  attack:  { icon: "💥", verb: "공격", delta: `-${BATTLE_DMG.attack}`,  cls: "atk" },
  defend:  { icon: "🛡", verb: "방어", delta: `+${BATTLE_DMG.defend}`,  cls: "def" },
  support: { icon: "💣", verb: "지원", delta: `+${BATTLE_DMG.support}`, cls: "sup" }
};

function feedLineHTML(a, isNew) {
  const meta = ACTION_META[a.action_type] || ACTION_META.attack;
  const target = allRows.find(r => r.id === a.comment_id);
  const targetName = target ? (target.is_anonymous ? "익명" : (profileMap[target.user_id]?.nickname || "익명")) : "???";
  const targetSide = target?.faction === "pro" ? "👍" : "👎";
  const t = a.created_at ? new Date(a.created_at) : new Date();
  const hh = String(t.getHours()).padStart(2, "0") + ":" + String(t.getMinutes()).padStart(2, "0");
  return `<div class="bf-line ${meta.cls} ${isNew ? "new" : ""}">
    <span class="bf-time">${hh}</span>
    <b class="bf-actor ${a.side === "pro" ? "pro" : "con"}">${escT(actorName(a.user_id))}</b>
    <span class="bf-verb">${meta.icon} ${meta.verb}</span>
    <span class="bf-arrow">→</span>
    <span class="bf-target">${targetSide} ${escT(targetName)}</span>
    <b class="bf-delta">${meta.delta}</b>
  </div>`;
}

function ensureFeedBox() {
  let box = document.getElementById("battle-feed");
  if (box) return box;
  const anchor = document.getElementById("battle-morale") || document.querySelector(".comment-war-header");
  if (!anchor) return null;
  box = document.createElement("div");
  box.id = "battle-feed";
  box.className = "battle-feed";
  box.innerHTML = `<div class="bf-title">📡 전장 속보 <span class="bf-live">LIVE</span></div><div class="bf-list" id="bf-list"><div class="bf-empty">아직 교전 기록이 없습니다.</div></div>`;
  anchor.after(box);
  return box;
}

async function initBattleFeed(issueId) {
  const supabase = window.supabaseClient;
  const box = ensureFeedBox();
  if (!box) return;

  // 초기 로그: 이 이슈 댓글들에 대한 최근 액션 8건
  const ids = allRows.map(r => r.id);
  if (ids.length) {
    const { data: logs } = await supabase
      .from("comment_actions")
      .select("comment_id,user_id,side,action_type,created_at")
      .in("comment_id", ids)
      .order("created_at", { ascending: false })
      .limit(8);
    if (logs?.length) {
      await fetchFeedNicks(logs.map(l => l.user_id));
      document.getElementById("bf-list").innerHTML = logs.map(l => feedLineHTML(l, false)).join("");
    }
  }

  // 실시간 구독: 새 전투 로그 + 댓글 HP 변동
  if (FEED_CHANNEL) { supabase.removeChannel(FEED_CHANNEL); FEED_CHANNEL = null; }
  FEED_CHANNEL = supabase
    .channel("battle-" + issueId)
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "comment_actions" }, async payload => {
      const a = payload.new;
      if (!allRows.some(r => r.id === a.comment_id)) return; // 다른 이슈
      await fetchFeedNicks([a.user_id]);
      pushFeedLine(a);
    })
    .on("postgres_changes", { event: "UPDATE", schema: "public", table: "comments" }, payload => {
      const c = payload.new;
      const row = allRows.find(r => r.id === c.id);
      if (!row) return; // 다른 이슈
      const oldHp = row.hp;
      if (typeof c.hp === "number" && c.hp !== oldHp) {
        row.hp = c.hp;
        row.attack_count = c.attack_count; row.defense_count = c.defense_count; row.support_count = c.support_count;
        syncUnitHp(c.id, oldHp, c.hp);
        renderMorale();
      }
    })
    // 새 댓글/답글 실시간 부분 삽입 — 남의 참전·전투 답글이 그 자리에 바로 나타난다
    .on("postgres_changes", { event: "INSERT", schema: "public", table: "comments", filter: "issue_id=eq." + issueId }, async payload => {
      const c = payload.new;
      if (!c || c.user_id === ME.userId) return;          // 내 것은 로컬에서 이미 처리
      if (allRows.some(r => r.id === c.id)) return;
      if (c.status === "deleted") return;

      await fetchFeedNicks([c.user_id]);
      if (!profileMap[c.user_id] && feedNickCache[c.user_id]) {
        profileMap[c.user_id] = { nickname: feedNickCache[c.user_id], level: 1 };
      }
      // 침투 노출 판정용 작성자 투표 진영 (미보유 시 단건 조회)
      if (!authorVoteMap[c.user_id]) {
        const { data: v } = await window.supabaseClient
          .from("votes").select("type")
          .eq("issue_id", issueId).eq("user_id", c.user_id).limit(1);
        const t = v?.[0]?.type;
        if (t === "pro" || t === "con") authorVoteMap[c.user_id] = t;
      }

      allRows.unshift(c);

      if (c.parent_id) {
        const rootId = rootIdOf(c.id);
        (replyMap[rootId] ||= []).push(c);
        const rootUnit = document.querySelector(`.comment[data-id="${rootId}"]`);
        const repliesBox = rootUnit?.querySelector(":scope > .replies");
        if (repliesBox) {
          repliesBox.insertAdjacentHTML("beforeend", makeReply(c));
          const el = repliesBox.lastElementChild; el?.classList.add("just-in");
          if (el) window.BattleFX?.burstAt?.(el, "spawn");
          applySideColoring();
          updateReplyMeta(rootUnit, rootId);
        }
      } else if (c.faction === "pro" || c.faction === "con") {
        state[c.faction].data.unshift(c);
        const list = document.getElementById(c.faction + "-list");
        if (list && state[c.faction].page === 1) {
          list.querySelector(".empty-zone")?.remove();
          list.insertAdjacentHTML("afterbegin", makeComment(c));
          const el = list.firstElementChild; el?.classList.add("just-in");
          if (el) { window.BattleFX?.burstAt?.(el, "spawn"); el.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
          applySideColoring();
        }
      }
      renderWarDashboard();
      renderMorale();
    })
    .subscribe();
}

function pushFeedLine(a) {
  const list = document.getElementById("bf-list");
  if (!list) return;
  list.querySelector(".bf-empty")?.remove();
  list.insertAdjacentHTML("afterbegin", feedLineHTML(a, true));
  while (list.children.length > 8) list.lastElementChild.remove();
}

/* 남이 때린/살린 HP 변동을 내 화면에도 반영 (본인 조작분은 로컬 연출과 중복돼도 무해) */
function syncUnitHp(commentId, oldHp, newHp) {
  const unit = document.querySelector(`.comment[data-id="${commentId}"], .reply[data-id="${commentId}"]`);
  if (!unit) return;
  const shown = Number(unit.dataset.hp);
  if (shown === newHp) return; // 이미 로컬 연출로 반영됨
  applyPoolHp(unit, newHp);    // 풀 공유 — 그 사람의 다른 댓글들도 같이 갱신

  const FX = window.BattleFX;
  const row = allRows.find(r => r.id === commentId);
  const isMine = !!(ME.userId && row && row.user_id === ME.userId);
  const isMySide = !!(ME.faction && row && row.faction === ME.faction);

  if (newHp < oldHp) {
    hitFx(unit, "hit");
    spawnCombatText(unit, String(newHp - oldHp), newHp <= 0 ? "crit" : "dmg");
    if (FX) FX.burstAt(unit, newHp <= 0 ? "ko" : "attack");
    // ⚠ 내 댓글 피격 경고 (실시간)
    if (isMine && FX) {
      FX.vignette("danger");
      FX.banner(newHp <= 0 ? "💀 내 댓글이 격파당했다!" : "⚠ 내 댓글이 공격받고 있다!", "warn");
      FX.haptic(newHp <= 0 ? "ko" : "warn");
    } else if (isMySide && newHp <= 0 && FX) {
      FX.vignette("danger");
      FX.haptic("warn");
    }
    if (newHp <= 0) showKoBanner(commentId);
  } else {
    hitFx(unit, "heal");
    spawnCombatText(unit, "+" + (newHp - oldHp), "heal");
    if (FX) FX.burstAt(unit, "support");
    const revived = oldHp <= 0 && newHp > 0;
    if (revived) spawnCombatText(unit, "✨ 부활!", "heal");
    // 🎉 내 댓글을 아군이 지켜줌 (실시간 환호)
    if (isMine && FX) {
      FX.vignette("heal");
      FX.banner(revived ? "✨ 아군이 내 댓글을 부활시켰다!" : "🛡 아군이 내 댓글을 지켜줬다!", "cheer");
      FX.confetti(40);
      FX.haptic("cheer");
    }
  }
}

/* 💀 격파 배너 (전장 전체 연출) */
function showKoBanner(commentId) {
  const row = allRows.find(r => r.id === commentId);
  const name = row ? (row.is_anonymous ? "익명" : (profileMap[row.user_id]?.nickname || "익명")) : "???";
  const side = row?.faction === "pro" ? "👍" : "👎";
  const el = document.createElement("div");
  el.className = "ko-banner";
  el.innerHTML = `<div class="ko-inner"><span class="ko-skull">💀</span><b>${side} ${escT(name)}</b>의 댓글 <span class="ko-word">격파!</span></div>`;
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 2200);
}

/* 🔥 콤보 (10초 내 연속 참전) */
function bumpCombo() {
  const now = Date.now();
  COMBO.n = (now - COMBO.t < 10000) ? COMBO.n + 1 : 1;
  COMBO.t = now;
  if (COMBO.n >= 2) {
    const el = document.createElement("div");
    el.className = "combo-pop";
    el.textContent = `🔥 ${COMBO.n} COMBO!`;
    document.body.appendChild(el);
    setTimeout(() => el.remove(), 1300);
  }
}

/* 🎖 전공 훈장 — 이 전장 최다 공격/방어/지원 */
async function renderHonors() {
  const ids = allRows.map(r => r.id);
  if (!ids.length) return;
  const { data: logs } = await window.supabaseClient
    .from("comment_actions")
    .select("user_id,action_type")
    .in("comment_id", ids)
    .limit(2000);
  if (!logs?.length) return;

  const agg = {}; // uid → {attack,defend,support}
  logs.forEach(l => {
    const a = agg[l.user_id] ||= { attack: 0, defend: 0, support: 0 };
    if (a[l.action_type] !== undefined) a[l.action_type]++;
  });
  const top = (k) => Object.entries(agg).sort((x, y) => y[1][k] - x[1][k])[0];
  const picks = [
    { k: "attack", icon: "💥", label: "최다 공격" },
    { k: "defend", icon: "🛡", label: "최다 방어" },
    { k: "support", icon: "💣", label: "최다 지원" }
  ].map(p => ({ ...p, e: top(p.k) })).filter(p => p.e && p.e[1][p.k] > 0);
  if (!picks.length) return;

  await fetchFeedNicks(picks.map(p => p.e[0]));

  let box = document.getElementById("battle-honors");
  if (!box) {
    box = document.createElement("div");
    box.id = "battle-honors";
    box.className = "battle-honors";
    (document.getElementById("battle-feed") || document.getElementById("battle-morale") || document.querySelector(".comment-war-header"))?.after(box);
  }
  box.innerHTML = `<div class="bh-title">🎖 전공 훈장</div><div class="bh-row">` +
    picks.map(p => `
      <div class="bh-card ${p.k}">
        <span class="bh-ic">${p.icon}</span>
        <b class="bh-name">${escT(actorName(p.e[0]))}</b>
        <span class="bh-label">${p.label} ${p.e[1][p.k]}회</span>
      </div>`).join("") + `</div>`;
}

/* ======================
   Data Loading
====================== */

/* 내 프로필을 profileMap에 보장 — 새 댓글 낙관적 렌더가 '익명'으로 그려지는 것 방지 */
async function ensureMyProfile() {
  if (!ME.userId || profileMap[ME.userId]?.nickname) return;
  try {
    const { data: u } = await window.supabaseClient
      .from("users").select("id,nickname,avatar_url").eq("id", ME.userId).maybeSingle();
    if (u) {
      if (!profileMap[ME.userId]) profileMap[ME.userId] = { level: 1 };
      profileMap[ME.userId].nickname = u.nickname || profileMap[ME.userId].nickname;
      profileMap[ME.userId].avatar_url = u.avatar_url;
    }
  } catch (_) {}
}

async function loadComments(issueId) {
  const supabase = window.supabaseClient;

  // 🔥 세션 복원 지연(iOS Safari 등) 대응 — 로그인 상태면 세션이 준비될 때까지 잠깐 기다린다.
  //    안 그러면 getSession()이 일시적으로 null → 내 투표(진영)를 못 읽어, 로그인·투표를
  //    했는데도 컴포저/전투 버튼이 잘못 잠긴다("투표 후 참전"). vote-bar(forceInitialVoteSync)와
  //    동일한 대비를 댓글 시스템에도 적용. 로그아웃 유저는 토큰이 없어 대기 없이 통과.
  let hasToken = false;
  try { hasToken = Object.keys(localStorage).some(k => /^sb-.*-auth-token$/.test(k)); } catch (_) {}
  let sess = (await supabase.auth.getSession())?.data || null;
  if (hasToken) {
    for (let i = 0; i < 20 && !sess?.session; i++) {
      await new Promise(r => setTimeout(r, 120));
      sess = (await supabase.auth.getSession())?.data || null;
    }
  }
  ME.userId = sess?.session?.user?.id || null;

  // 내 진영 = 이 이슈에 대한 내 투표 (서버 RPC도 동일 기준으로 강제)
  ME.faction = null;
  if (ME.userId) {
    const { data: myVote } = await supabase
      .from("votes")
      .select("type")
      .eq("issue_id", issueId)
      .eq("user_id", ME.userId)
      .limit(1);
    const t = myVote?.[0]?.type;
    if (t === "pro" || t === "con") ME.faction = t;
  }
  window.MY_VOTE_TYPE = ME.faction;

  const { data: rows, error } = await supabase
    .from("comments")
    .select("id,user_id:author_id,content,created_at,faction,hp,attack_count,defense_count,support_count,parent_id,is_anonymous,ghost_seed,battle_action")
    .eq("issue_id", issueId)
    .neq("status", "deleted")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[comments] load failed", error);
    return;
  }
  allRows = rows || [];

  // 🚀 하이라이트 부스트(24h) 적용 대상
  hlSet = new Set();
  try {
    const ids = allRows.map(r => r.id);
    if (ids.length) {
      const { data: hb } = await supabase.from("content_boosts")
        .select("target_id").eq("kind", "highlight").gt("until", new Date().toISOString()).in("target_id", ids);
      (hb || []).forEach(b => hlSet.add(Number(b.target_id)));
    }
  } catch (_) {}

  // 작성자 프로필
  profileMap = {};
  const userIds = [...new Set(allRows.map(r => r.user_id).filter(Boolean))];
  if (userIds.length) {
    const { data: profiles } = await supabase
      .from("user_profiles")
      .select("user_id,nickname,level")
      .in("user_id", userIds);
    profiles?.forEach(p => profileMap[p.user_id] = p);

    // 닉네임 정본 + 프로필 사진은 users 테이블 (user_profiles는 PII 잠금·nickname은 캐시일 뿐)
    const { data: avatars } = await supabase
      .from("users")
      .select("id,nickname,avatar_url")
      .in("id", userIds);
    avatars?.forEach(u => {
      if (!profileMap[u.id]) profileMap[u.id] = { level: 1 };
      // users.nickname이 정본 — 있으면 무조건 우선 (없을 때만 user_profiles 캐시 유지)
      if (u.nickname) profileMap[u.id].nickname = u.nickname;
      profileMap[u.id].avatar_url = u.avatar_url;
    });
  }
  // 내가 이 이슈에 첫 댓글을 달 때도 '익명'이 아니라 내 닉네임으로 즉시 그려지도록 보장
  await ensureMyProfile();

  // 작성자별 이 이슈 투표 진영 (침투 노출용 — votes SELECT 공개 정책)
  // 침투 = 작성자 실제 투표 진영 ≠ 글이 놓인 진영. 정체를 숨기지 않고 모두에게 노출한다.
  authorVoteMap = {};
  if (userIds.length) {
    const { data: avotes } = await supabase
      .from("votes")
      .select("user_id,type")
      .eq("issue_id", issueId)
      .in("user_id", userIds);
    avotes?.forEach(v => { if (v.type === "pro" || v.type === "con") authorVoteMap[v.user_id] = v.type; });
  }

  // 좋아요 집계 + 내 좋아요
  likeAgg = {};
  ME.likes = new Map();
  const ids = allRows.map(r => r.id);
  if (ids.length) {
    const { data: likes } = await supabase
      .from("comment_likes")
      .select("comment_id,user_id,value")
      .in("comment_id", ids);
    likes?.forEach(l => {
      const a = likeAgg[l.comment_id] ||= { up: 0, down: 0 };
      if (l.value === 1) a.up++; else a.down++;
      if (ME.userId && l.user_id === ME.userId) ME.likes.set(l.comment_id, l.value);
    });
  }

  // 내 전투 액션 최근 시각 (쿨다운 계산용) — key `${comment_id}:${action_type}` → epoch ms
  ME.actions = new Map();
  if (ME.userId && ids.length) {
    const { data: acts } = await supabase
      .from("comment_actions")
      .select("comment_id,action_type,created_at")
      .eq("user_id", ME.userId)
      .in("comment_id", ids)
      .order("created_at", { ascending: false });
    acts?.forEach(a => {
      const k = `${a.comment_id}:${a.action_type}`;
      if (!ME.actions.has(k)) ME.actions.set(k, new Date(a.created_at).getTime());
    });
  }

  // 댓글/대댓글 분류 — 답글의 답글(parent가 답글)은 최상위 댓글 스레드로 승격(1depth 유지).
  // 승격 없이는 replyMap[답글id]가 렌더되지 않아 화면에서 영영 안 보이는 버그가 있었다.
  replyMap = {};
  const top = { pro: [], con: [] };
  allRows.forEach(r => {
    if (r.parent_id) {
      (replyMap[rootIdOf(r.id)] ||= []).push(r);
    } else if (r.faction === "pro" || r.faction === "con") {
      top[r.faction].push(r);
    }
  });
  // 대댓글은 오래된 순으로 표시
  Object.values(replyMap).forEach(list => list.reverse());

  // 교전 점수순 정렬 → 빌보드 상위 노출
  const score = c =>
    (c.attack_count || 0) + (c.defense_count || 0) + (c.support_count || 0) +
    ((likeAgg[c.id]?.up) || 0) + ((replyMap[c.id]?.length) || 0);
  top.pro.sort((a, b) => score(b) - score(a));
  top.con.sort((a, b) => score(b) - score(a));

  state.pro.data = top.pro;
  state.con.data = top.con;
}

/* ======================
   Rendering
====================== */

function ghostPersona(c) {
  return (window.GALLA_ghost ? window.GALLA_ghost(c.ghost_seed)
    : { name: "익명의 유령", color: "#8a7bb0", avatarHTML: "" });
}
function displayName(c) {
  if (c.is_anonymous) return ghostPersona(c).name;
  return profileMap[c.user_id]?.nickname || "익명";
}
// 닉네임 클릭 → 유저 시트. 유령은 프로필 이동 불가(ghost.js가 애니메이션 처리)
function nameSpan(c) {
  if (c.is_anonymous) {
    const g = ghostPersona(c);
    return `<span class="user-name ghost-nick" style="color:${g.color}">${g.name}</span>`;
  }
  const nm = displayName(c);
  if (!c.user_id) return `<span class="user-name">${escT(nm)}</span>`;
  return `<span class="user-name userlink" data-user-id="${c.user_id}" data-user-nick="${escT(nm).replace(/"/g, "&quot;")}">${escT(nm)}</span>`;
}

/* 프로필 사진 — 클릭 시 마이페이지 이동(data-profile-uid 전역 핸들러가 처리).
   익명 댓글은 이동 없이 기본 아이콘만. size: 'c'(댓글) | 'r'(답글) */
function avatarHTML(c, size) {
  const cls = `c-avatar c-avatar-${size || "c"}`;
  // 👻 유령: 시드 기반 절차적 아바타 (프로필 이동 불가 → ghost.js 애니메이션)
  if (c.is_anonymous) {
    const g = ghostPersona(c);
    return `<span class="${cls} ghost-av-wrap ghost-nick">${g.avatarHTML}</span>`;
  }
  const url = profileMap[c.user_id]?.avatar_url;
  const src = (!c.user_id)
    ? (window.GALLA_DEFAULT_AVATAR || "/assets/app-icons/default-avatar.png")
    : (window.GALLA_avatarSrc ? window.GALLA_avatarSrc(url) : (url || ""));
  const fallback = window.GALLA_DEFAULT_AVATAR || "/assets/app-icons/default-avatar.png";
  const img = `<img src="${escT(src).replace(/"/g, "&quot;")}" alt="프로필" loading="lazy" onerror="this.onerror=null;this.src='${fallback}'">`;
  if (!c.user_id) return `<span class="${cls} anon-av">${img}</span>`;
  return `<span class="${cls}" data-profile-uid="${c.user_id}" role="button" aria-label="프로필 보기">${img}</span>`;
}

// ⋯ 액션 시트: 일기토 신청 / 신고 / 차단 (자체 스타일)
function openCommentMoreMenu({ uid, nick, cid }) {
  const meId = ME?.userId || null;
  const isOther = uid && uid !== meId;
  document.getElementById("cmm-sheet")?.remove();
  const sheet = document.createElement("div");
  sheet.id = "cmm-sheet";
  sheet.style.cssText = "position:fixed;inset:0;z-index:99998;display:flex;align-items:flex-end;justify-content:center";
  const opt = (icon, label, cls) => `<button class="cmm-opt ${cls}" style="display:flex;gap:10px;align-items:center;width:100%;padding:15px 18px;border:none;background:transparent;color:#eef0f4;font-size:15px;font-weight:700;cursor:pointer;border-bottom:1px solid rgba(255,255,255,.06)"><span style="font-size:18px">${icon}</span>${label}</button>`;
  sheet.innerHTML = `
    <div style="position:absolute;inset:0;background:rgba(0,0,0,.5)"></div>
    <div style="position:relative;width:100%;max-width:480px;background:#16171c;border-radius:18px 18px 0 0;padding:8px 0 max(8px,env(safe-area-inset-bottom));animation:cmmUp .22s ease">
      ${isOther ? opt("⚔️", `<b style="color:#c9d1e0">일기토 신청</b> · ${escT(nick)}`, "duel") : ""}
      ${isOther ? opt("🚨", "신고", "report") : ""}
      ${isOther ? opt("🚫", "이 사용자 차단", "block") : opt("✏️", "댓글 수정", "edit")}
      ${isOther ? "" : opt("✨", "하이라이트 (800GP · 24h)", "hl")}
      ${isOther ? "" : opt("🗑️", "댓글 삭제", "del")}
      ${opt("🔗", "이 댓글 공유", "share")}
      <button class="cmm-opt cancel" style="width:100%;padding:15px;border:none;background:transparent;color:#8a8f9a;font-weight:800;cursor:pointer">닫기</button>
    </div>`;
  if (!document.getElementById("cmm-css")) {
    const s = document.createElement("style"); s.id = "cmm-css";
    s.textContent = "@keyframes cmmUp{from{transform:translateY(100%)}}.cmm-opt:active{background:rgba(255,255,255,.06)!important}";
    document.head.appendChild(s);
  }
  document.body.appendChild(sheet);
  const close = () => sheet.remove();
  sheet.firstElementChild.addEventListener("click", close);
  sheet.querySelector(".cancel").addEventListener("click", close);
  sheet.querySelector(".duel")?.addEventListener("click", () => {
    close();
    location.href = `duel.html?challenge=${uid}&issue=${window.CURRENT_ISSUE_ID || ""}`;
  });
  const goReport = () => {
    close();
    if (window.GALLA_openReportMenu) window.GALLA_openReportMenu({ contentType: "comment", contentId: cid, authorId: uid, authorName: nick });
    else alert("신고 기능을 불러오지 못했어요.");
  };
  sheet.querySelector(".report")?.addEventListener("click", goReport);
  sheet.querySelector(".block")?.addEventListener("click", goReport);
  // 🔗 댓글·대댓글 공유 — 인용 카드(/share/comment/issue/<cid>) + 자동 초대링크
  sheet.querySelector(".share")?.addEventListener("click", () => {
    close();
    const raw = allRows.find(r => String(r.id) === String(cid))?.content || "";
    const url = window.GALLA_shareCommentUrl ? window.GALLA_shareCommentUrl("issue", cid) : (location.origin + "/share/comment/issue/" + cid);
    const title = "🗯️ " + (raw ? `“${String(raw).replace(/\s+/g, " ").trim().slice(0, 40)}”` : "이 댓글");
    const text = `${nick || "누군가"}의 한마디 — 갈라에서 받아쳐봐`;
    if (window.GALLA_share) window.GALLA_share({ url, title, text });
    else if (navigator.share) navigator.share({ title, text, url }).catch(() => {});
    else { try { navigator.clipboard.writeText(url); (window.GALLA_toast || alert)("🔗 댓글 링크 복사됨"); } catch (_) {} }
  });
  // 내 댓글 수정/삭제 (소프트삭제: status='deleted')
  sheet.querySelector(".edit")?.addEventListener("click", () => {
    close();
    const raw = allRows.find(r => String(r.id) === String(cid))?.content || "";
    window.GALLA_cmtEdit?.({
      table: "comments", id: cid, bodyCol: "content", current: raw,
      onSaved: (txt) => {
        const row = allRows.find(r => String(r.id) === String(cid)); if (row) row.content = txt;
        const unit = document.querySelector(`.comment[data-id="${cid}"], .reply[data-id="${cid}"]`);
        const body = unit?.querySelector(":scope > .body");
        if (body) body.innerHTML = renderCommentText(txt);
      },
    });
  });
  sheet.querySelector(".del")?.addEventListener("click", () => {
    close();
    window.GALLA_cmtDelete?.({
      table: "comments", id: cid, soft: true,
      onDone: () => { document.querySelector(`.comment[data-id="${cid}"], .reply[data-id="${cid}"]`)?.remove(); },
    });
  });
  sheet.querySelector(".hl")?.addEventListener("click", async () => {
    close();
    if (!confirm("이 댓글을 24시간 하이라이트할까요? (800 GP)")) return;
    const { data } = await window.supabaseClient.rpc("buy_boost", { p_type: "comment", p_id: Number(cid), p_kind: "highlight" });
    if (!data?.ok) {
      if (data?.reason === "insufficient" && window.GALLA_needGP) window.GALLA_needGP(800, "부스트에 GP가 부족해요");
      else alert(data?.reason === "insufficient" ? "GP가 부족해요. (800GP 필요)" : "부스트 실패");
      return;
    }
    hlSet.add(Number(cid));
    document.querySelector(`.comment[data-id="${cid}"], .reply[data-id="${cid}"]`)?.classList.add("hl");
    window.BattleFX?.banner?.("✨ 하이라이트 적용! (24h)", "cheer");
  });
}
function displayLevel(c) {
  return profileMap[c.user_id]?.level || 1;
}
function likeUI(c) {
  const agg = likeAgg[c.id] || { up: 0, down: 0 };
  const mine = ME.likes.get(c.id);
  return `
    <span class="like ${mine === 1 ? "active-like" : ""}" data-id="${c.id}">👍${agg.up}</span>
    <span class="dislike ${mine === -1 ? "active-dislike" : ""}" data-id="${c.id}">👎${agg.down}</span>`;
}

/* 진영 규칙 (서버 battle_action RPC와 동일)
   - 내 진영 없음(미투표) → 참전 불가
   - 반대 진영 댓글 → 💥공격만 (60초 쿨다운 후 재공격 가능)
   - 같은 진영 댓글  → 🛡방어 · 💣지원만 (동일 쿨다운) */
const ACTION_LABEL = { attack: "💥공격", defend: "🛡방어", support: "💣지원" };

/* 침투자 판별 — 작성자의 실제 투표 진영 ≠ 글이 놓인 진영.
   위장 없음: 침투자의 실제 입장(진영)을 모두에게 노출한다(싸움 유도). */
function isInfiltrator(c) {
  const v = authorVoteMap[c.user_id];
  return !!(v && (c.faction === "pro" || c.faction === "con") && v !== c.faction);
}
/* 화면 표시용 진영 — 침투자는 '실제 진영'을 노출, 그 외는 글이 놓인 진영 */
function shownFaction(c) {
  return isInfiltrator(c) ? authorVoteMap[c.user_id] : c.faction;
}

/* 관계 태그 — 침투자는 모두에게 노출('적진 침투'), 그 외는 내 기준 아군/적군.
   아군/적군 판정도 표시 진영(shownFaction) 기준. */
function relTag(c) {
  if (isInfiltrator(c)) {
    const mine = ME.userId && c.user_id === ME.userId;
    return `<span class="rel-tag infil">🕵️ ${mine ? "내 침투" : "침투자"} · 원래 ${fLabel(authorVoteMap[c.user_id])}</span>`;
  }
  if (!ME.faction) return "";
  return ME.faction === shownFaction(c)
    ? `<span class="rel-tag ally">아군</span>`
    : `<span class="rel-tag enemy">적군</span>`;
}
function battleBtn(c, action, customLabel) {
  const base = customLabel || ACTION_LABEL[action];
  const left = cooldownLeft(c.id, action);
  const cd = left > 0 ? ` cooldown" data-cd="${action}" data-until="${ME.actions.get(c.id + ":" + action) + BATTLE_COOLDOWN_MS}` : "";
  const label = left > 0 ? `${base} ${left}s` : base;
  const lbl = customLabel ? ` data-lbl="${customLabel}"` : "";
  return `<span class="action-${action}${cd}" data-id="${c.id}"${lbl}>${label}</span>`;
}
function battleButtonsFor(c) {
  const my = ME.faction;
  if (!my) {
    return `<span class="action-locked" data-id="${c.id}">🔒 투표 후 참전</span>`;
  }
  if (my !== c.faction) {
    // 적진의 침투자는 '격퇴' — 침입자를 몰아낸다는 게임 서사 (동작은 attack 그대로)
    return battleBtn(c, "attack", isInfiltrator(c) ? "💥격퇴" : null);
  }
  // 아군: 방어·지원 + 🛡보호막(아이템). 지키는 행위에 아이템을 쓰게 유도하는 자리.
  return battleBtn(c, "defend") + battleBtn(c, "support") +
    `<span class="action-shield" data-id="${c.id}" title="보호막 — 10분간 받는 피해 절반">🛡보호막</span>`;
}

/* 쿨다운 카운트다운 티커 (1초마다 버튼 라벨 갱신, 끝나면 활성화)
   — top-level 자동실행이었으나 SPA unmount에서 해제할 수 있게 핸들 보관.
     initCommentSystem이 시작시키므로 MPA 동작은 동일. */
let CD_TICKER = null;
function startCooldownTicker() {
  if (CD_TICKER) return;
  CD_TICKER = setInterval(() => {
    document.querySelectorAll("[data-cd]").forEach(el => {
      const until = Number(el.dataset.until);
      const left = Math.ceil((until - Date.now()) / 1000);
      const action = el.dataset.cd;
      const base = el.dataset.lbl || ACTION_LABEL[action];
      if (left > 0) {
        el.textContent = `${base} ${left}s`;
      } else {
        el.textContent = base;
        el.classList.remove("cooldown");
        delete el.dataset.cd;
        delete el.dataset.until;
      }
    });
  }, 1000);
}

function makeReply(r) {
  const chip = r.battle_action === "attack"
    ? `<span class="reply-chip atk">💥 공격 −${BATTLE_DMG.attack}</span>`
    : r.battle_action === "defend"
      ? `<span class="reply-chip def">🛡 방어 +${BATTLE_DMG.defend}</span>`
      : "";
  const ko = r.hp <= 0 ? " ko" : "";
  const infil = isInfiltrator(r) ? " infil-unit" : "";
  // 대댓글은 단순화 — 작은 아바타 + 닉네임만(레벨·아군태그 생략), HP는 얇은 바
  return `
  <div class="reply${ko}${infil}" data-hp="${r.hp}" data-id="${r.id}" data-uid="${r.user_id || ""}" data-side="${r.faction}">
    <div class="head">
      ${avatarHTML(r, "r")}
      <div class="user">${nameSpan(r)}</div>
      ${hpBarHTML(r)}
    </div>
    <div class="body">${chip}${renderCommentText(r.content)}</div>
    <div class="reply-actions" data-side="${r.faction}">
      ${likeUI(r)}
      ${battleButtonsFor(r)}
    </div>
  </div>`;
}

// ⚔️ 격론 감지(정밀 규칙): 한 스레드에서 두 유저가 '실제로 주고받은 왕복(교차)' 횟수 기준.
//   교차 = 발언자가 A→B 또는 B→A로 바뀐 횟수 (한쪽 도배는 격론이 아님 — 예전 단순 개수 규칙의 오탐 제거)
//   레벨: 교차 2회(A-B-A) 신경전 → 4회 설전 → 6회+ 전면전. 유령·익명은 집계 제외.
//   당사자 화면: 단계별 일기토 도전 버튼 / 관전자 화면: 교차 4회+부터 '격론 중' 배지.
function threadHeat(c) {
  const thread = [c, ...(replyMap[c.id] || [])]
    .filter(r => r.user_id && !r.is_anonymous)
    .sort((x, y) => new Date(x.created_at) - new Date(y.created_at));
  const seq = thread.map(r => r.user_id);
  const uniq = [...new Set(seq)];
  let best = { a: null, b: null, sw: 0 };
  for (let i = 0; i < uniq.length; i++) for (let j = i + 1; j < uniq.length; j++) {
    const s = seq.filter(u => u === uniq[i] || u === uniq[j]);
    let sw = 0;
    for (let k = 1; k < s.length; k++) if (s[k] !== s[k - 1]) sw++;
    if (sw > best.sw) best = { a: uniq[i], b: uniq[j], sw };
  }
  best.lv = best.sw >= 6 ? 3 : best.sw >= 4 ? 2 : best.sw >= 2 ? 1 : 0;
  return best;
}
const HEAT_LABEL = {
  1: "⚔️ 신경전 감지 — 일기토로 끝장?",
  2: "🔥 설전 격화! 일기토 개전",
  3: "💥 전면전! 지금 옥타곤에서 결판",
};
function duelHeatBtn(c) {
  const h = threadHeat(c);
  if (!h.lv) return "";
  const nickOf = uid => (profileMap[uid]?.nickname || feedNickCache[uid] || "상대").replace(/"/g, "&quot;");
  // 내가 당사자면: 단계별 도전 버튼 (상대 = 나 아닌 쪽)
  if (ME.userId && (h.a === ME.userId || h.b === ME.userId)) {
    const foe = h.a === ME.userId ? h.b : h.a;
    if (!foe || foe === ME.userId) return "";
    return `<button type="button" class="c-duel lv${h.lv}" data-uid="${foe}" data-nick="${nickOf(foe)}">${HEAT_LABEL[h.lv]}</button>`;
  }
  // 관전자: 설전(교차 4회) 이상이면 격론 중 배지 (탭 액션 없음)
  if (h.lv >= 2) {
    return `<span class="c-duel-watch">🔥 격론 중 · <b>${nickOf(h.a)}</b> vs <b>${nickOf(h.b)}</b></span>`;
  }
  return "";
}

function makeComment(c) {
  const replies = replyMap[c.id] || [];
  const battleButtons = battleButtonsFor(c);

  const ko = c.hp <= 0 ? " ko" : "";
  const isAce = ACE[c.faction] === c.id;
  const infil = isInfiltrator(c) ? " infil-unit" : "";
  const power = combatPower(c);

  // 답글 상시 노출 — 4개 초과면 최근 3개만 펼치고 위에 로컬 '이전 답글 보기' 버튼
  const shown = replies.length > 4 ? replies.slice(-3) : replies;
  const hiddenCount = replies.length - shown.length;

  return `
    <div class="comment${ko}${isAce ? " ace" : ""}${infil}${hlSet.has(c.id) ? " hl" : ""}" data-hp="${c.hp}" data-side="${c.faction}" data-id="${c.id}" data-uid="${c.user_id || ""}">
    <div class="head">
      ${avatarHTML(c, "c")}
      <div class="user">
        <span class="side-icon"></span>
        ${nameSpan(c)}
        <span class="level-badge">Lv.${displayLevel(c)}</span>
        ${relTag(c)}
        ${isAce ? `<span class="ace-badge" title="에이스">👑</span>` : ``}
        ${c.is_anonymous ? `<span class="anon">익명</span>` : ``}
      </div>
      ${hpBarHTML(c)}
    </div>

    <div class="body">${renderCommentText(c.content)}</div>

    <div class="actions">
      ${likeUI(c)}
      ${battleButtons}
      ${duelHeatBtn(c)}
      <span class="cp-chip${c.hp <= 0 ? " ko" : ""}" title="영향력 = 생존도(HP) × 설득력(추천·지원·방어 − 반대). 격파당하면 0이 됩니다.">⚡ 영향력 ${power}</span>
      <span class="action-more">⋯</span>
    </div>

    <div class="reply-meta">
      ${replies.length
        ? `<button type="button" class="rm-replies" data-id="${c.id}">💬 답글 ${replies.length}</button>`
        : `<span class="rm-stat">💬 답글 0</span>`}
      <span class="rm-stat" title="이 댓글이 받은 공격·방어·지원 횟수">💥 ${c.attack_count || 0} · 🛡 ${c.defense_count || 0} · 💣 ${c.support_count || 0}</span>
    </div>

    <div class="replies" data-id="${c.id}">
      ${hiddenCount > 0 ? `<button type="button" class="reply-older" data-id="${c.id}">이전 답글 ${hiddenCount}개 보기</button>` : ``}
      ${shown.map(makeReply).join("")}
    </div>
  </div>`;
}

/* ======================
   Engine
====================== */

function renderSide(side) {
  const s = state[side];
  const list = document.getElementById(side + "-list");
  if (!list) {
    console.warn("renderSide target missing:", side);
    return;
  }

  if (s.data.length === 0) {
    list.innerHTML = `<div class="empty-zone">아직 이 진영의 댓글이 없습니다. 첫 포문을 여세요!</div>`;
    buildPager(side, 0);
    return;
  }

  // 교전 점수순 정렬(로드 시) 유지 — 상위가 곧 전선의 최전방
  list.innerHTML = s.data
    .slice((s.page - 1) * PAGE_SIZE, s.page * PAGE_SIZE)
    .map(makeComment)
    .join("");

  buildPager(side, Math.ceil(s.data.length / PAGE_SIZE));
  applySideColoring();
}

function buildPager(side, total) {
  const pager = document.getElementById(`${side}-pager`);
  if (!pager) return;
  const s = state[side];
  pager.innerHTML = "";
  if (total <= 1) return;

  for (let i = 1; i <= total; i++) {
    const b = document.createElement("button");
    b.textContent = i;
    if (s.page === i) b.classList.add("active");
    b.onclick = () => { s.page = i; renderSide(side); };
    pager.appendChild(b);
  }
}

function renderWarDashboard() {
  // index.js의 loadWarData와 동일한 집계 방식 (피드 전황표와 수치 일치)
  const w = {
    pro: { total: 0, same: 0, oppo: 0 },
    con: { total: 0, same: 0, oppo: 0 },
    atk: 0, def: 0, sup: 0
  };

  allRows.forEach(row => {
    const f = row.faction;
    if (!w[f]) return;
    w[f].total++;
    w.atk += row.attack_count || 0;
    w.def += row.defense_count || 0;
    w.sup += row.support_count || 0;
    w[f].same += (row.defense_count || 0) + (row.support_count || 0);
    const enemy = f === "pro" ? "con" : "pro";
    w[enemy].oppo += row.attack_count || 0;
  });

  const set = (id, v) => {
    const el = document.getElementById(id);
    if (!el) return;
    if (typeof v === "number" && window.GALLA_countUp) window.GALLA_countUp(el, v, "");
    else el.textContent = v;
  };
  set("stat-pro-total", w.pro.total);
  set("stat-pro-same", w.pro.same);
  set("stat-pro-oppo", w.pro.oppo);
  set("stat-con-total", w.con.total);
  set("stat-con-same", w.con.same);
  set("stat-con-oppo", w.con.oppo);
  set("stat-total", w.atk + w.def + w.sup);
  set("stat-atk", w.atk);
  set("stat-sup", w.sup);
  set("stat-def", w.def);

  // 승세 진영 강조 (왕관 + 글로우 펄스)
  const proBox = document.querySelector(".bmw-box.pro");
  const conBox = document.querySelector(".bmw-box.con");
  proBox?.classList.toggle("win", w.pro.total > w.con.total);
  conBox?.classList.toggle("win", w.con.total > w.pro.total);
}

function requireLogin() {
  if (ME.userId) return true;
  // 전역 통일 모달 — 밋밋한 alert 대신(참전·좋아요·싫어요·이모티콘·GIF·공유 모두 동일)
  if (window.GALLA_needLogin) window.GALLA_needLogin("로그인 후 참전할 수 있어요.");
  else alert("로그인이 필요합니다.");
  return false;
}

/* 서버 battle_action 거부 사유 → 사용자 메시지 */
function battleReasonMsg(reason, data) {
  switch (reason) {
    case "no_faction": return "먼저 이 이슈에 투표해 진영을 정해야 참전할 수 있어요.";
    case "same_faction": return "같은 진영은 공격할 수 없어요.";
    case "cross_faction": return "같은 진영 댓글만 방어·지원할 수 있어요.";
    case "cooldown": return `쿨다운 중이에요. ${data?.wait ?? 60}초 후 다시 시도하세요.`;
    case "already": return "이미 이 댓글에 같은 행동을 했어요.";
    case "unauthorized": return "로그인이 필요합니다.";
    default: return null;
  }
}

/* ======================
   Interaction
====================== */

function bindEvents() {
  // 하단 컴포저(입력창·전송)는 요소 직결 — SPA 재진입 시 새 DOM이라 매번 재바인딩
  bindComposerEls();
  // 아래 document 위임 리스너는 문서당 1회면 충분(위임이라 새 DOM에도 그대로 작동)
  if (eventsBound) return;
  eventsBound = true;

  /* iOS: 컴포저 키보드가 떠 있을 때 다른 전투 버튼을 탭하면
     blur → 키보드 닫힘 → 레이아웃 이동이 click보다 먼저 일어나
     click이 옛 좌표의 엉뚱한 곳에 떨어진다(버튼 안 먹힘·버퍼).
     pointerdown preventDefault로 포커스 이동 자체를 막으면
     키보드가 유지되고 화면이 안 움직여 click이 그대로 명중한다. */
  document.addEventListener("pointerdown", e => {
    if (!e.target.closest(".action-attack, .action-defend, .action-support, .action-shield, .ic-send, .ic-close")) return;
    /* 키보드가 떠 있을 때만 포커스를 지킨다 — 무조건 preventDefault하면
       iOS가 span 버튼의 click 생성을 막아 '보호막 버튼 안 먹음'이 됐다.
       (키보드 유지가 필요한 상황 = 입력창에 포커스가 있을 때뿐) */
    const ae = document.activeElement;
    const typing = ae && (ae.tagName === "INPUT" || ae.tagName === "TEXTAREA" || ae.isContentEditable);
    if (typing) e.preventDefault();
  });

  document.addEventListener("click", async e => {
    // ⚔️ 격론 → 일기토 신청 (그 상대·이 이슈로)
    const cd = e.target.closest(".c-duel");
    if (cd) {
      e.stopPropagation();
      location.href = `duel.html?challenge=${cd.dataset.uid}&issue=${window.CURRENT_ISSUE_ID || ""}`;
      return;
    }
    // ✨ 부활권: 격파당한 내 댓글 부활
    if (e.target.classList.contains("revive-btn")) {
      e.stopPropagation();
      const rid = Number(e.target.dataset.id);
      const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
      const owned = inv.revive || 0;
      if (owned <= 0) { askShop("✨ 부활권이 없어요. (800 GP)"); return; }
      if (!(await ask({ emoji: "✨", title: "댓글을 부활시킬까요?",
        body: `부활권을 사용해 HP 50으로 되살립니다. (보유 ${owned}개)`, ok: "✨ 부활" }))) return;
      const { data: rv } = await window.supabaseClient.rpc("use_revive", { p_comment_id: rid });
      if (!rv?.ok) { alert("부활에 실패했어요: " + (rv?.reason || "오류")); return; }
      const unit = e.target.closest(".reply, .comment");
      if (unit) {
        applyHpToUnit(unit, rv.hp);
        e.target.remove();
        const FX = window.BattleFX;
        if (FX) { FX.burstAt(unit, "support"); FX.banner("✨ 댓글 부활!", "cheer"); FX.haptic("heal"); }
      }
      const row = allRows.find(r => r.id === rid);
      if (row) row.hp = rv.hp;
      return;
    }


    // 💬 답글 N → 그 댓글의 답글 목록으로 이동
    const rm = e.target.closest(".rm-replies");
    if (rm) {
      e.stopPropagation();
      const box = document.querySelector(`.replies[data-id="${rm.dataset.id}"]`);
      if (box) {
        box.scrollIntoView({ behavior: "smooth", block: "center" });
        box.classList.add("replies-flash");
        setTimeout(() => box.classList.remove("replies-flash"), 900);
      }
      return;
    }

    // 🔒 진영 미선택(미투표) → 참전 안내
    if (e.target.classList.contains("action-locked")) {
      alert("먼저 이 이슈에 투표해 진영을 정해야 참전할 수 있어요.");
      return;
    }

    // 💥🛡 전투 버튼 클릭 → 해당 유닛 아래 인라인 컴포저 (누구를 왜 치는지 그 자리에서 보이게)
    if (e.target.classList.contains("action-attack") || e.target.classList.contains("action-defend")) {
      if (!requireLogin()) return;
      const type = e.target.classList.contains("action-attack") ? "attack" : "defend";

      // 가장 가까운 유닛(답글이면 답글, 아니면 댓글) — .comment를 먼저 찾으면 답글의 진영을 잘못 판정한다
      const targetEl = e.target.closest(".reply, .comment");
      if (!targetEl) return;
      const targetSide = targetEl.dataset.side || "pro";

      // 진영 규칙 프론트 사전 검사 (서버 RPC가 최종 강제)
      if (!ME.faction) { alert("먼저 이 이슈에 투표해 진영을 정해야 참전할 수 있어요."); return; }
      if (type === "attack" && ME.faction === targetSide) { alert("같은 진영은 공격할 수 없어요. 상대 진영을 공격하세요."); return; }
      if (type === "defend" && ME.faction !== targetSide) { alert("같은 진영 댓글만 방어할 수 있어요."); return; }

      const cdLeft = cooldownLeft(Number(e.target.dataset.id), type);
      if (cdLeft > 0) {
        // ⚡ 쿨다운 리셋권 보유 시 즉시 사용 제안
        if (!(await offerCooldownReset(Number(e.target.dataset.id), type, cdLeft))) return;
      }

      const targetId = Number(e.target.dataset.id || targetEl.dataset.id);
      const nameEl = targetEl.querySelector(".head .user-name");
      const targetUser = nameEl ? nameEl.textContent.trim() : "익명";

      // 🛡↔⚡ 보호막 낀 상대면 파쇄를 쓸지 먼저 묻는다(취소해도 절반 피해로 공격은 가능)
      // 판정 직전에 서버 기준으로 새로 읽는다 — 60초 주기 캐시만 믿으면
      // '방금 걸린 방패'를 몰라 파쇄 제안이 안 뜬다(사장님 재현)
      if (type === "attack") {
        await refreshShields();
        if (isShielded(targetEl)) await offerBreaker(targetId);
      }

      openInlineComposer(type, targetId, targetUser, targetEl);
      return;
    }

    // 🛡 보호막 → 아군 유닛에 10분 보호막 (아이템 소모)
    if (e.target.classList.contains("action-shield")) {
      if (!requireLogin()) return;
      const sid = Number(e.target.dataset.id);
      if (!sid) return;
      const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
      const have = inv.shield || 0;
      if (have <= 0) { askShop("🛡 보호막이 없어요. (400 GP)\n10분간 받는 피해가 절반으로 줄어요."); return; }
      if (!(await ask({ emoji: "🛡", title: "보호막을 사용할까요?",
        body: `보유 ${have}개\n10분간 받는 피해가 절반(${BATTLE_DMG.attack}→${Math.ceil(BATTLE_DMG.attack / 2)})으로 줄어요.\n상대의 ⚡파쇄엔 뚫립니다.`, ok: "🛡 사용" }))) return;
      const { data, error } = await window.supabaseClient.rpc("use_shield", { p_comment_id: sid });
      if (error || !data?.ok) {
        const M = { already_shielded: "이미 보호막이 걸려 있어요.", no_item: "🛡 보호막이 없어요.",
                    cross_faction: "같은 진영 댓글만 보호할 수 있어요.", no_faction: "먼저 투표해 진영을 정하세요." };
        alert(M[data?.reason] || "보호막 사용에 실패했어요.");
        return;
      }
      await refreshShields();
      const u = e.target.closest(".reply, .comment");
      if (u) { hitFx(u, "heal"); spawnCombatText(u, "🛡 보호막!", "heal"); }
      window.BattleFX?.burstAt?.(u, "defend");
      window.BattleFX?.banner?.("🛡 보호막 전개 — 10분간 피해 절반", "cheer");
      return;
    }

    // 💣 지원 → RPC로 HP/카운터 갱신 (같은 진영만)
    if (e.target.classList.contains("action-support")) {
      if (!requireLogin()) return;
      const id = Number(e.target.dataset.id);
      if (!id) return;

      const supUnit = e.target.closest(".reply") || e.target.closest(".comment");
      const supSide = supUnit?.dataset.side;
      if (!ME.faction) { alert("먼저 이 이슈에 투표해 진영을 정해야 참전할 수 있어요."); return; }
      if (ME.faction !== supSide) { alert("같은 진영 댓글만 지원할 수 있어요."); return; }

      const supLeft = cooldownLeft(id, "support");
      if (supLeft > 0) {
        if (!(await offerCooldownReset(id, "support", supLeft))) return;
      }

      const { data, error } = await window.supabaseClient.rpc("battle_action", {
        p_comment_id: id, p_action: "support",
        p_use_reset: RESET_ARMED.has(id + ":support")
      });
      RESET_ARMED.delete(id + ":support");
      if (error || !data?.ok) {
        alert(battleReasonMsg(data?.reason, data) || "지원에 실패했습니다.");
        if (!data?.reason) console.error("[support] failed", error || data);
        return;
      }

      markAction(id, "support");
      e.target.classList.add("cooldown");
      e.target.dataset.cd = "support";
      e.target.dataset.until = String(Date.now() + BATTLE_COOLDOWN_MS);
      e.target.textContent = `${ACTION_LABEL.support} 60s`;

      // 해당 유닛 HP 즉시 반영 + 힐 FX + 플로팅 텍스트
      const unit = e.target.closest(".reply") || e.target.closest(".comment");
      if (unit) {
        applyPoolHp(unit, data.hp);
        hitFx(unit, "heal");
        spawnCombatText(unit, `+${BATTLE_DMG.support} 지원!`, "heal");
        const FX = window.BattleFX;
        if (FX) {
          FX.burstAt(unit, "support");
          FX.shockwave(unit, "rgba(53,224,160,.9)");
          FX.haptic("heal");
          if (Number(unit.dataset.hp) >= 100) { FX.banner("💪 풀피 지원!", "cheer"); }
        }
        showBattleReward(data);   // 🛡 수호 보상
        bumpCombo();
        renderMorale();
        renderHonors();
      }
      return;
    }

    // 👍👎 좋아요/싫어요 → comment_likes 테이블
    if (e.target.classList.contains("like") || e.target.classList.contains("dislike")) {
      if (!requireLogin()) return;
      const id = Number(e.target.dataset.id);
      if (!id) return;

      const supabase = window.supabaseClient;
      const desired = e.target.classList.contains("like") ? 1 : -1;
      const current = ME.likes.get(id);
      const agg = likeAgg[id] ||= { up: 0, down: 0 };

      if (current === desired) {
        // 취소
        const { error } = await supabase.from("comment_likes")
          .delete().eq("comment_id", id).eq("user_id", ME.userId);
        if (error) return console.error("[like] delete failed", error);
        ME.likes.delete(id);
        desired === 1 ? agg.up-- : agg.down--;
      } else {
        const { error } = await supabase.from("comment_likes")
          .upsert({ comment_id: id, user_id: ME.userId, value: desired });
        if (error) return console.error("[like] upsert failed", error);
        if (current === 1) agg.up--;
        if (current === -1) agg.down--;
        desired === 1 ? agg.up++ : agg.down++;
        ME.likes.set(id, desired);
      }

      // 같은 댓글의 표시들 갱신 (빌보드/스레드에 중복 표시될 수 있음)
      document.querySelectorAll(`.like[data-id="${id}"]`).forEach(el => {
        el.textContent = "👍" + agg.up;
        el.classList.toggle("active-like", ME.likes.get(id) === 1);
      });
      document.querySelectorAll(`.dislike[data-id="${id}"]`).forEach(el => {
        el.textContent = "👎" + agg.down;
        el.classList.toggle("active-dislike", ME.likes.get(id) === -1);
      });
      return;
    }

    // ⋯ 메뉴 — 일기토 신청 / 신고 / 차단
    if (e.target.classList.contains("action-more")) {
      const unit = e.target.closest(".comment");
      const nameEl = unit?.querySelector(".user-name[data-user-id]");
      const uid = nameEl?.getAttribute("data-user-id");
      const nick = nameEl?.getAttribute("data-user-nick") || "상대";
      const cid = unit?.getAttribute("data-id");
      openCommentMoreMenu({ uid, nick, cid });
      return;
    }

    // 이전 답글 로컬 펼침 (리로드 없음 — 답글은 항상 노출, 4개 초과분만 접혀 있음)
    const older = e.target.closest(".reply-older");
    if (older) {
      const id = Number(older.dataset.id);
      const wrap = older.closest(".replies");
      if (wrap) {
        wrap.innerHTML = (replyMap[id] || []).map(makeReply).join("");
        applySideColoring();
      }
      return;
    }
  });

}

/* 하단 참전 컴포저(입력창·전송 버튼) 바인딩 — 요소별 가드로 중복 방지.
   MPA에선 1회, SPA에선 mount마다 새 요소에 다시 걸린다. */
function bindComposerEls() {
  // 입력창 자체도 로그인 게이트 — 미로그인이 탭/포커스하면 바로 로그인 유도(키보드 안 뜸)
  const battleInput = document.getElementById("battle-comment-input");
  if (battleInput && !battleInput.__gateBound) {
    battleInput.__gateBound = true;
    const inputGate = (e) => {
      if (ME.userId) return;            // 로그인 상태면 통과(미투표는 참전 시 안내)
      if (e) e.preventDefault();
      battleInput.blur();
      if (window.GALLA_needLogin) window.GALLA_needLogin("로그인 후 참전할 수 있어요.");
    };
    battleInput.addEventListener("pointerdown", inputGate);  // 포커스(키보드) 자체를 막음
    battleInput.addEventListener("focus", inputGate);         // 프로그램적 포커스 대비
  }

  // 전송 — 하단 바는 '새 최상위 의견(참전/침투)' 전용. 전투 답글은 인라인 컴포저가 처리.
  const submitBtn = document.getElementById("battle-comment-submit");
  if (submitBtn && !submitBtn.__bound) {
    submitBtn.__bound = true;
    submitBtn.addEventListener("click", async () => {
      if (!requireLogin()) return;

      const input = document.getElementById("battle-comment-input");
      if (!input) return;

      const supabase = window.supabaseClient;

      // 진영은 투표로 고정 — 미투표자는 참전 불가
      if (!ME.faction) {
        alert("먼저 위에서 투표해 진영을 정하면 참전할 수 있어요.");
        return;
      }
      const side = INFILTRATE ? (ME.faction === "pro" ? "con" : "pro") : ME.faction;

      const text = input.value.trim();
      if (!text) {
        alert("의견을 입력하세요.");
        return;
      }

      const wasInfiltration = INFILTRATE;
      const { data: newRow, error } = await supabase.from("comments").insert({
        issue_id: window.CURRENT_ISSUE_ID,
        user_id: ME.userId,
        faction: side,
        content: text,
        is_anonymous: GHOST_ON     // 👻 유령 참전 (seed는 서버 트리거가 강제 주입)
      }).select("id,user_id:author_id,content,created_at,faction,hp,attack_count,defense_count,support_count,parent_id,is_anonymous,ghost_seed,battle_action").single();
      if (error) {
        if (String(error.message || "").includes("no_ghost_pass")) {
          askShop("👻 유령권이 만료됐어요.");
          GHOST_ON = false; document.getElementById("ghost-toggle")?.classList.remove("on");
          return;
        }
        if (String(error.message || "").includes("infiltration_limit")) {
          alert("오늘의 침투 횟수(3회)를 모두 썼어요. 내일 다시 침투할 수 있어요.");
          consumeInfiltration(); // 카운터 0 동기화 + 모드 해제
          return;
        }
        // ⚔️ 참전 제한 룰
        if (String(error.message || "").includes("battle_ko_locked")) {
          // 격파당한 내 참전 댓글이 있으면 새 참전 불가 — 부활권으로 되살려 재참전
          const inv = window.GALLA_myItems ? await window.GALLA_myItems() : {};
          if ((inv.revive || 0) > 0)
            alert("💀 격파당한 내 참전 댓글이 있어요.\n먼저 그 댓글의 ✨ 부활권으로 되살려 재참전하세요.\n(새로 똑같이 다시 달 순 없어요 — 그게 격파의 무게예요)");
          else
            askShop("💀 격파당하면 새로 참전할 수 없어요.\n✨ 부활권(800 GP)으로 격파된 내 댓글을 되살려 재참전하세요.");
          return;
        }
        if (String(error.message || "").includes("battle_cap_reached")) {
          alert("이 이슈엔 최대 2번까지 참전할 수 있어요.\n더 하고 싶으면 상대 댓글에 ⚔️ 대댓글로 물고 늘어지세요!");
          return;
        }
        console.error("[comment] insert failed", error);
        alert("댓글 등록에 실패했습니다.");
        return;
      }

      // ✨ 참전/침투 연출
      const FX = window.BattleFX;
      if (FX) {
        if (wasInfiltration) {
          FX.burstAt(input, "ko");
          FX.shockwave(input, "rgba(201,209,224,.9)");
          FX.flash("rgba(201,209,224,.14)", 220);
          FX.banner("🕵️ 적진 침투 성공!", "warn");
          FX.haptic("attack");
        } else {
          FX.burstAt(input, side === "pro" ? "pro" : "con");
          FX.shockwave(input, side === "pro" ? "rgba(77,163,255,.85)" : "rgba(255,92,92,.85)");
          FX.flash(side === "pro" ? "rgba(77,163,255,.12)" : "rgba(255,92,92,.12)");
          FX.banner(`${fLabel(side)} 진영 참전!`, "info");
          FX.haptic("tap");
        }
      }
      if (wasInfiltration) consumeInfiltration();

      input.value = "";
      finishComposing(input);

      // 부분 삽입 — 전체 리로드 없이 내가 쓴 존 맨 위에 바로 표시 (스크롤·상태 유지)
      authorVoteMap[ME.userId] = ME.faction; // 침투 노출 판정에 내 실제 진영 반영
      allRows.unshift(newRow);
      state[side]?.data.unshift(newRow);
      const list = document.getElementById(side + "-list");
      if (list) {
        list.querySelector(".empty-zone")?.remove();
        list.insertAdjacentHTML("afterbegin", makeComment(newRow));
        applySideColoring();
        const el = list.firstElementChild;
        if (el) el.scrollIntoView({ block: "center", behavior: "smooth" });
      }
      renderWarDashboard();
      renderMorale();
    });
  }
}

/* ======================
   인라인 전투 컴포저 — 공격/방어를 '그 자리에서' 쓰고 결과도 그 자리에 남긴다
====================== */
function ensureInlineComposer() {
  let box = document.getElementById("inline-composer");
  if (box) return box;
  box = document.createElement("div");
  box.id = "inline-composer";
  box.className = "inline-composer";
  box.innerHTML = `
    <div class="ic-head">
      <span class="ic-title" id="ic-title"></span>
      <button type="button" class="ic-close" aria-label="닫기">✕</button>
    </div>
    <div class="ic-row">
      <input id="ic-input" maxlength="500" autocomplete="off">
      <button type="button" id="ic-send" class="ic-send"></button>
    </div>`;
  box.querySelector(".ic-close").addEventListener("click", closeInlineComposer);
  box.querySelector("#ic-send").addEventListener("click", submitInline);
  box.querySelector("#ic-input").addEventListener("keydown", e => {
    if (e.key === "Enter") submitInline();
    if (e.key === "Escape") closeInlineComposer();
  });
  return box;
}

function openInlineComposer(type, targetId, targetUser, unit) {
  const box = ensureInlineComposer();
  BATTLE_MODE = { type, targetId, targetUser };

  // 일반 대상 = 공격/방어(심플), 침투자 대상 = 격퇴 (게임 서사)
  const isInfil = unit.classList.contains("infil-unit");
  const atkVerb = isInfil ? "격퇴" : "공격";

  box.classList.remove("atk", "def");
  box.classList.add(type === "attack" ? "atk" : "def");
  box.querySelector("#ic-title").innerHTML = type === "attack"
    ? `💥 <b>${escT(targetUser)}</b> ${atkVerb} — 이유를 남겨야 데미지가 들어갑니다`
    : `🛡 <b>${escT(targetUser)}</b> 방어 — 지원 근거가 방어막이 됩니다`;
  const input = box.querySelector("#ic-input");
  input.placeholder = type === "attack" ? "반박 근거를 입력…" : "지지 근거를 입력…";
  box.querySelector("#ic-send").textContent = type === "attack" ? `💥 −${BATTLE_DMG.attack}` : `🛡 +${BATTLE_DMG.defend}`;

  // 대상 유닛 바로 아래에 부착 (최상위 댓글이면 스레드 끝, 답글이면 그 답글 뒤)
  if (unit.classList.contains("reply")) {
    unit.insertAdjacentElement("afterend", box);
  } else {
    const replies = unit.querySelector(":scope > .replies") || unit;
    replies.insertAdjacentElement("afterend", box);
  }
  input.value = "";
  input.focus();
  /* 아이폰: 키보드가 다 올라온 뒤(visualViewport 축소 후) 컴포저가
     키보드에 가려 있으면 화면 가운데로 끌어올린다 */
  setTimeout(() => {
    const r = box.getBoundingClientRect();
    const vh = window.visualViewport?.height || window.innerHeight;
    if (r.bottom > vh - 8 || r.top < 0) {
      try { box.scrollIntoView({ block: "center", behavior: "smooth" }); } catch (_) {}
    }
  }, 300);
  window.BattleFX?.haptic("tap");
}

function closeInlineComposer() {
  document.getElementById("inline-composer")?.remove();
  BATTLE_MODE = null;
  document.body.classList.remove("kb-open");
}

async function submitInline() {
  if (!BATTLE_MODE) return;
  const input = document.getElementById("ic-input");
  const text = (input?.value || "").trim();
  if (!text) { alert("의견을 입력하세요."); return; }
  const { type, targetId, targetUser } = BATTLE_MODE;
  await submitBattleReply(type, targetId, targetUser, text);
}

/* 전투 답글 제출 — insert + battle_action RPC + 부분 삽입(리로드 없음) */
async function submitBattleReply(type, targetId, targetUser, text) {
  const supabase = window.supabaseClient;

  // 대댓글 하루 한도 검사 (소진 시 연장권 제안)
  if (!(await ensureReplyQuota())) return;

  // 답글의 답글도 최상위 스레드에 붙인다(1depth) — 대상은 @멘션으로 보존
  const rootId = rootIdOf(targetId);
  const content = rootId !== targetId ? `@${targetUser} ${text}` : text;

  const { data: newRow, error: insertErr } = await supabase.from("comments").insert({
    issue_id: window.CURRENT_ISSUE_ID,
    user_id: ME.userId,
    parent_id: rootId,
    faction: ME.faction,
    content,
    battle_action: type,
    is_anonymous: GHOST_ON     // 👻 유령 답글
  }).select("id,user_id:author_id,content,created_at,faction,hp,attack_count,defense_count,support_count,parent_id,is_anonymous,ghost_seed,battle_action").single();
  if (insertErr) {
    if (String(insertErr.message || "").includes("no_ghost_pass")) {
      askShop("👻 유령권이 만료됐어요.");
      GHOST_ON = false; document.getElementById("ghost-toggle")?.classList.remove("on"); return;
    }
    if (String(insertErr.message || "").includes("reply_limit")) {
      REPLY_LEFT = 0;
      askShop("오늘의 대댓글 횟수를 모두 썼어요.\n🗯️ 대댓글 연장권(+15회, 300 GP)으로 바로 이어갈 수 있어요.");
      return;
    }
    console.error("[battle reply] insert failed", insertErr);
    alert("답글 등록에 실패했습니다.");
    return;
  }
  if (REPLY_LEFT !== null) REPLY_LEFT = Math.max(0, REPLY_LEFT - 1);

  // 전투 액션 기록 + 대상 HP 갱신 (이미 했으면 답글만 등록)
  const { data: bd } = await supabase.rpc("battle_action", {
    p_comment_id: targetId, p_action: type,
    p_use_reset: RESET_ARMED.has(`${targetId}:${type}`),
    p_break: BREAK_ARMED.has(String(targetId))
  });
  RESET_ARMED.delete(`${targetId}:${type}`);
  BREAK_ARMED.delete(String(targetId));
  if (bd?.ok && bd.broke) breakerFx(document.querySelector(`.comment[data-id="${targetId}"], .reply[data-id="${targetId}"]`));
  if (bd?.ok && (bd.broke || bd.shielded)) refreshShields();   // 방패 상태가 바뀌었으니 서버 기준으로 다시

  closeInlineComposer();

  // 로컬 상태 + DOM 부분 삽입 — 방금 단 답글이 그 자리에 바로 보인다
  authorVoteMap[ME.userId] = ME.faction;
  allRows.unshift(newRow);
  (replyMap[rootId] ||= []).push(newRow);

  const rootUnit = document.querySelector(`.comment[data-id="${rootId}"]`);
  const repliesBox = rootUnit?.querySelector(":scope > .replies");
  if (repliesBox) {
    repliesBox.insertAdjacentHTML("beforeend", makeReply(newRow));
    applySideColoring();
    updateReplyMeta(rootUnit, rootId);
  }

  // FX + 대상 HP 반영
  const targetUnit = document.querySelector(`.comment[data-id="${targetId}"], .reply[data-id="${targetId}"]`);
  if (bd?.ok && targetUnit) {
    // 쿨다운 로컬 시작 (서버 comment_actions와 동기)
    markAction(targetId, type);
    document.querySelectorAll(`.action-${type}[data-id="${targetId}"]`).forEach(el => {
      el.classList.add("cooldown");
      el.dataset.cd = type;
      el.dataset.until = String(Date.now() + BATTLE_COOLDOWN_MS);
    });

    applyPoolHp(targetUnit, bd.hp);   // 풀이라 그 사람의 스레드 내 모든 댓글이 함께 내려간다
    const FX = window.BattleFX;
    if (type === "attack") {
      hitFx(targetUnit, "hit");
      const crit = bd.hp <= 0;
      spawnCombatText(targetUnit, crit ? `-${BATTLE_DMG.attack} 격파!` : `-${BATTLE_DMG.attack}`, crit ? "crit" : "dmg");
      if (FX) {
        FX.shockwave(targetUnit, "rgba(255,80,50,.9)");
        FX.burstAt(targetUnit, crit ? "ko" : "attack");
        FX.haptic(crit ? "ko" : "attack");
        if (crit) FX.flash("rgba(255,40,40,.18)", 240);
      }
      if (crit) showKoBanner(targetId);
    } else {
      hitFx(targetUnit, "heal");
      spawnCombatText(targetUnit, `+${BATTLE_DMG.defend} 방어`, "heal");
      if (FX) {
        FX.burstAt(targetUnit, "defend");
        FX.shockwave(targetUnit, "rgba(120,190,255,.9)");
        FX.banner("🛡 방어 성공!", "cheer");
        FX.confetti(46);
        FX.haptic("cheer");
      }
    }
    showBattleReward(bd);   // 💥 격파 / 🛡 수호 보상
    bumpCombo();
    renderMorale();
    renderWarDashboard();
    renderHonors();
  } else if (bd && !bd.ok && bd.reason !== "already") {
    const m = battleReasonMsg(bd.reason, bd);
    if (m) alert(m);
  }
}

/* 루트 댓글의 답글/교전 카운터 표시 갱신 */
function updateReplyMeta(rootUnit, rootId) {
  const meta = rootUnit.querySelector(":scope > .reply-meta");
  const row = allRows.find(r => r.id === rootId);
  if (!meta || !row) return;
  const n = (replyMap[rootId] || []).length;
  meta.textContent = `💬 ${n} · 💥 ${row.attack_count || 0} · 🛡 ${row.defense_count || 0} · 💣 ${row.support_count || 0}`;
}

/* 전송 완료 후 컴포저 정리 — 모바일 키보드 모드(kb-open)를 확실히 해제.
   전송 버튼 탭 시 input이 blur되지 않아 focusout이 안 나면
   kb-open이 남아 하단 네비가 사라진 채 화면이 먹통처럼 고정된다. */
function finishComposing(input) {
  try { input?.blur(); } catch (_) {}
  document.body.classList.remove("kb-open");
}

/* 중립 플랫폼: 내 진영 기준(아군/적군)이 아니라 진영 자체로 색을 칠한다.
   찬성(pro) = 파랑 👍 / 반대(con) = 빨강 👎 */
function applySideColoring() {
  document.querySelectorAll(".comment, .reply").forEach(unit => {
    let side =
      unit.dataset.side ||
      unit.querySelector(".reply-actions")?.dataset.side;

    if (!side) return;

    // 🕵️ 침투자는 실제 진영으로 색을 칠한다(위장 없음, 모두에게 노출).
    // 반대 진영 영역에 실제 진영 색으로 껴 있어 '적진 침투'가 한눈에 드러난다.
    const row = allRows.find(r => r.id === Number(unit.dataset.id));
    if (row) side = shownFaction(row);

    const user = unit.querySelector(".user");
    const name = unit.querySelector(".user-name") || user;
    const level = unit.querySelector(".level-badge");
    const icon = unit.querySelector(".side-icon");

    if (!user) return;

    let realIcon = icon;
    if (!realIcon) {
      realIcon = document.createElement("span");
      realIcon.className = "side-icon";
      user.prepend(realIcon);
    }

    name.classList.remove("ally-user", "enemy-user");
    level?.classList.remove("ally-level", "enemy-level");
    realIcon.classList.remove("ally-icon", "enemy-icon");

    if (side === "pro") {
      name.classList.add("ally-user");     // 파랑 = 찬성
      level?.classList.add("ally-level");
      realIcon.classList.add("ally-icon");
      realIcon.textContent = "👍";
    } else {
      name.classList.add("enemy-user");    // 빨강 = 반대
      level?.classList.add("enemy-level");
      realIcon.classList.add("enemy-icon");
      realIcon.textContent = "👎";
    }
  });
}

/* =========================================================
   모바일 키보드 대응
   - 입력창 포커스 시: 하단 네비를 숨기고 컴포저를 bottom:0으로 내림
   - iOS/안드로이드가 fixed 요소를 키보드 위로 배치하므로,
     bottom:0 하나만 남기면 키보드 바로 위에 깔끔히 붙는다.
     (gap 수동 계산은 iOS 자동추적과 겹쳐 이중으로 밀리므로 사용하지 않음)
========================================================= */
(function () {
  const isInput = (el) => el && (el.id === "battle-comment-input" || el.id === "ic-input");
  const SPA = () => document.body && document.body.dataset.page === "spa";

  /* SPA: 입력바가 transform된 스택 뷰 안 fixed라 iOS의 '키보드 위 자동 추적'이 안 먹는다
     (containing block이 뷰포트가 아님). visualViewport로 키보드 높이를 직접 계산해 올린다. */
  function kbLift() {
    if (!SPA()) return;
    const bar = document.querySelector(".battle-input-bar");
    if (!bar) return;
    const vv = window.visualViewport;
    const kb = vv ? Math.max(0, window.innerHeight - vv.height - vv.offsetTop) : 0;
    bar.style.bottom = kb > 0 ? kb + "px" : "";
  }
  function armVV() {
    const vv = window.visualViewport;
    if (!vv || armVV._on) return;
    armVV._on = true;
    vv.addEventListener("resize", kbLift);
    vv.addEventListener("scroll", kbLift);
  }
  const open = () => { document.body.classList.add("kb-open"); if (SPA()) { armVV(); setTimeout(kbLift, 80); setTimeout(kbLift, 350); } };
  const close = () => {
    document.body.classList.remove("kb-open");
    const bar = document.querySelector(".battle-input-bar"); if (bar) bar.style.bottom = "";
  };

  document.addEventListener("focusin", (e) => { if (isInput(e.target)) open(); });
  document.addEventListener("focusout", (e) => { if (isInput(e.target)) setTimeout(close, 100); });
})();

/* =========================================================
   SPA 언마운트 정리 — issue.js(GALLA_PAGE_ISSUE.unmount)가 호출.
   MPA(단독 문서)에선 아무도 안 부르므로 동작 불변.
   해제 대상: 실시간 채널 2개(전장 피드·진영 채팅), 타이머 2개(보호막·쿨다운),
   스크롤/리사이즈 리스너(구역 표시), body 부착 오버레이(진영채팅 시트·⋯시트),
   이슈 종속 전역/모듈 상태.
========================================================= */
export function destroyCommentSystem() {
  // 타이머
  if (window.__shieldTimer) { clearInterval(window.__shieldTimer); window.__shieldTimer = null; }
  if (CD_TICKER) { clearInterval(CD_TICKER); CD_TICKER = null; }
  // 실시간 구독
  try { if (FEED_CHANNEL) { window.supabaseClient.removeChannel(FEED_CHANNEL); FEED_CHANNEL = null; } } catch (_) {}
  try { closeFactionChat(); } catch (_) {}                 // CHAT_CHANNEL 해제 포함
  // body에 부착돼 뷰 제거로 안 사라지는 오버레이들
  document.getElementById("faction-chat")?.remove();
  document.getElementById("cmm-sheet")?.remove();
  try { closeInlineComposer(); } catch (_) {}
  // 전역 리스너(구역 표시 스크롤 추적)
  unbindZoneIndicator();
  // 이슈 종속 상태 — 다음 mount의 initCommentSystem/loadComments가 새로 채운다
  window.CURRENT_ISSUE_ID = null;
  window.MY_VOTE_TYPE = null;
  allRows = []; replyMap = {}; likeAgg = {}; profileMap = {}; authorVoteMap = {};
  hlSet = new Set(); SHIELDS = {}; feedNickCache = {};
  ACE = { pro: null, con: null };
  BATTLE_MODE = null;
  ME.userId = null; ME.faction = null;
  ME.likes = new Map(); ME.actions = new Map();
}
