/* =========================================================
   GALLA SHORTS / REELS ENGINE (FINAL)
   - index 기반 전환 (scroll 폐기)
   - transform + drag
   - 완전한 릴스/쇼츠 UX
========================================================= */

window.__SHORTS_OPEN_QUEUE__ = window.__SHORTS_OPEN_QUEUE__ || [];
window.__SHORTS_VOTING_LOCK__ = false;
window.currentCommentStance = "pro";   // pro | con
window.currentCommentSort = "latest"; // latest | popular

window.__COMMENT_OPEN__ = false;
window.__COMMENT_STATE__ = "closed"; // closed | half | full

function isScrollableTarget(el) {
  return el && el.closest && el.closest(".comment-list");
}

let shortsList = [];
let currentIndex = 0;
let overlay, track;
let SHORTS_ENTRY = 'detail';   // 진입: 'feed'(인덱스=+ 만들기) / 'detail'(상세=‹ 닫기)

let isDragging = false;
let startX = 0;
let startY = 0;
let currentTranslateY = 0;
let velocityY = 0;

const SWIPE_THRESHOLD = 70;
const CLOSE_THRESHOLD_X = 120;

function getViewportHeight() {
  return window.visualViewport
    ? window.visualViewport.height
    : window.innerHeight;
}

let VIEWPORT_H = getViewportHeight();

function updateViewportHeight() {
  VIEWPORT_H = getViewportHeight();

  if (track) {
    track.style.height = `${shortsList.length * VIEWPORT_H}px`;
    track.style.transition = "none";
    track.style.transform = `translateY(-${currentIndex * VIEWPORT_H}px)`;
  }
}
window.addEventListener("resize", updateViewportHeight);
window.addEventListener("orientationchange", updateViewportHeight);

if (window.visualViewport) {
  window.visualViewport.addEventListener("resize", updateViewportHeight);
  window.visualViewport.addEventListener("scroll", updateViewportHeight);
}

/* =========================
   OPEN API
========================= */
window.__SHORTS_ENGINE_READY__ = false;

window.openShorts = function (list, startId, startTime, entry) {
  try {
    if (typeof window.__OPEN_SHORTS_INTERNAL__ === "function") {
      window.__OPEN_SHORTS_INTERNAL__(list, startId, startTime, entry);
    } else {
      console.warn("[SHORTS] __OPEN_SHORTS_INTERNAL__ missing, queueing");
      window.__SHORTS_OPEN_QUEUE__.push({ list, startId, startTime, entry });
      document.addEventListener("DOMContentLoaded", () => {
        if (typeof window.__OPEN_SHORTS_INTERNAL__ === "function") {
          window.__OPEN_SHORTS_INTERNAL__(list, startId, startTime, entry);
        }
      }, { once: true });
    }
  } catch (e) {
    console.error("[SHORTS] openShorts failed", e);
  }
};

/* =========================
   CORE OPEN
========================= */
function __openShortsInternal(list, startId, startTime, entry) {
  SHORTS_ENTRY = entry === 'feed' ? 'feed' : 'detail';   // 인덱스=+ / 상세(기본)=‹
  // 이어보기: 시작 아이템을 이 위치(초)부터 재생 (인덱스 인라인에서 넘어옴)
  window.__SHORTS_PENDING_SEEK__ = (startTime && startTime > 0.3) ? { id: Number(startId), time: startTime } : null;
  // 🔥 HARD FIX: 항상 video_url 있는 항목만, 순서 고정
  shortsList = (list || [])
    .filter(v => v && v.video_url)
    .map(v => ({
      id: Number(v.id),
      video_url: v.video_url,
      title: v.title || "",
      author: v.author || "익명",
      avatar_url: v.avatar_url || null,
      level: v.level != null ? v.level : "",
      category: v.category || "",
      user_id: v.user_id || "",
      faction_a: v.faction_a || "",
      faction_b: v.faction_b || ""
    }));
  if (!shortsList.length) return;

  // 릴스 진입 = 몰입 뷰 → 소리 ON (전역 통일). 여기서 음소거하면 인덱스로도 이어진다.
  if (window.GALLA_enterImmersive) window.GALLA_enterImmersive();
  else window.__REELS_MUTED__ = false;

  overlay = document.getElementById("shortsOverlay");
  if (!overlay) {
    overlay = document.createElement("div");
    overlay.id = "shortsOverlay";
    document.body.appendChild(overlay);
  }

  // Clear overlay for fresh rendering
  overlay.innerHTML = `
    <div id="shortsContainer">
      <div class="shorts-scrim shorts-scrim-top"></div>
      <div class="shorts-scrim shorts-scrim-bottom"></div>
      <div class="shorts-top">
        <button id="shortsCloseBtn" class="sh-icon-btn" aria-label="${SHORTS_ENTRY === 'feed' ? '만들기' : '닫기'}">
          ${SHORTS_ENTRY === 'feed'
            ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>'
            : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>'}
        </button>
        <!-- 상단 음성 버튼 제거(사장님 확정) — 음소거는 화면 탭으로 토글, 상태는 중앙 배지로 안내 -->
      </div>
      <div id="shortsTrack"></div>
      <div id="shortsProgress"><div id="shortsProgressFill"></div></div>
      <div id="shortsVoteBar" class="shorts-vote gv"></div>
    </div>
  `;
  // ===== Inject overlay styles for shorts meta (once) =====
  if (!document.getElementById("shortsMetaStyle")) {
    const style = document.createElement("style");
    style.id = "shortsMetaStyle";
    style.textContent = `
.shorts-meta{
  position:absolute; left:16px; right:84px;
  bottom:calc(env(safe-area-inset-bottom) + 172px);  /* 통합 진영바(약 135px) 위로 — 가림 방지 */
  z-index:30; color:#fff;
  font-family:"Pretendard",system-ui,-apple-system,BlinkMacSystemFont,sans-serif;
  pointer-events:auto;
}
.shorts-author{ display:flex; gap:11px; align-items:flex-start; }
.author-avatar{
  width:46px; height:46px; border-radius:50%; object-fit:cover; flex:none;
  border:2px solid rgba(255,255,255,.92); box-shadow:0 2px 12px rgba(0,0,0,.55);
}
.author-avatar-init{
  display:flex; align-items:center; justify-content:center;
  font-weight:800; font-size:18px; color:#0a0a0b;
  background:linear-gradient(135deg,#c9d1e0,#ff9b4d);
}
.author-info{ display:flex; flex-direction:column; gap:5px; min-width:0; }
.author-line{ display:flex; align-items:center; gap:7px; font-size:15.5px; font-weight:800; line-height:1.15; }
.author-name{ text-shadow:0 1px 6px rgba(0,0,0,.75); }
.author-level{
  font-size:11px; padding:2px 8px; border-radius:999px; font-weight:800;
  background:rgba(201,209,224,.2); color:#c9d1e0; border:1px solid rgba(201,209,224,.42);
}
.shorts-cat{ font-size:12px; color:#c9d1e0; font-weight:700; opacity:.95; text-shadow:0 1px 4px rgba(0,0,0,.6); }
.shorts-title{
  margin-top:2px; font-size:14.5px; font-weight:600; line-height:1.42; color:#f2f3f5;
  text-shadow:0 1px 6px rgba(0,0,0,.7);
  display:-webkit-box; -webkit-line-clamp:2; -webkit-box-orient:vertical; overflow:hidden;
}
.shorts-goto{ cursor:pointer; }
.shorts-goto:active{ opacity:.7; }
.shorts-goto-chip, .author-follow{ display:none; }
/* iOS는 cursor:pointer 없으면 click을 디스패치 안 함 → 탭 대상 전부 지정 */
.author-name, .author-avatar-link, .author-avatar, .author-avatar-init{ cursor:pointer; }
.shorts-action-btn{ cursor:pointer; }
`;
    document.head.appendChild(style);
  }

  // === 댓글 모달 HTML 생성 추가 ===
  if (!document.getElementById("shortsCommentModal")) {
    const modal = document.createElement("div");
    modal.id = "shortsCommentModal";
    modal.innerHTML = `
    <style>
    /* ===== Shorts Comment Modal UI (Issue Tone) ===== */
    #shortsCommentModal .comment-sheet{
      background:#0d0e12;
      color:#fff;
      border-top:1px solid rgba(255,255,255,.08);
      box-shadow:0 -20px 60px rgba(0,0,0,.6);
    }
    .comment-summary{
      padding:14px;
      border-bottom:1px solid rgba(255,255,255,.12);
    }
    .comment-summary .summary-bar{
      display:flex;
      align-items:center;
      gap:8px;
      font-size:13px;
      font-weight:700;
    }
    .comment-summary .bar{
      flex:1;
      height:6px;
      background:#222;
      border-radius:4px;
      overflow:hidden;
    }
    .comment-summary .bar-pro{
      height:100%;
      background:linear-gradient(90deg,#3d6bff,#6f93ff);
    }
    .comment-summary .summary-meta{
      margin-top:6px;
      font-size:11px;
      opacity:.7;
    }

    .comment-tabs.tabs-menu{
      position: sticky;
      top: 72px; /* summary height 기준 고정 */
      z-index: 5;

      display:flex;
      margin:0 14px 10px;
      padding:6px;
      gap:0;

      border-radius:14px;
      background:rgba(255,255,255,.04);
      border:1px solid rgba(255,255,255,.08);
    }
    .comment-tabs .stance-tab{
      flex:1;
      padding:10px 0;
      border-radius:10px;
      border:none;
      background:transparent;
      color:#9aa0ad;
      font-weight:800;
      letter-spacing:.5px;
      transition:.15s;
    }
    .comment-tabs .stance-tab.active{
      color:#fff;
      background:rgba(255,255,255,.08);
    }
    .comment-tabs .stance-tab.active.pro{
      background:rgba(61,107,255,.2); color:#a9c0ff;
    }
    .comment-tabs .stance-tab.active.con{
      background:rgba(255,77,103,.2); color:#ffb3c0;
    }

    /* ===============================
       COMMENT BILLBOARD (STICKY)
    ================================ */
    .comment-billboard.sticky{
      position: sticky;
      top: 128px; /* summary + tabs 높이 합 */
      z-index: 4;

      margin: 0 14px 10px;
      padding: 10px;
      border-radius: 12px;

      background:
        linear-gradient(180deg,rgba(255,255,255,.12),rgba(0,0,0,.85)),
        repeating-linear-gradient(45deg,#050505,#050505 6px,#0a0a0a 6px,#0a0a0a 12px);

      box-shadow: 0 0 28px rgba(255,255,255,.35);
    }

    .comment-billboard .billboard-item{
      padding: 8px;
      border-radius: 8px;
      font-size: 12px;
      margin-bottom: 6px;
      background: linear-gradient(180deg,#1a1a1a,#020202);
    }
    .comment-billboard .billboard-item:last-child{
      margin-bottom: 0;
    }

    .comment-list-wrap{
      flex:1;
      display:flex;
      flex-direction:column;
      overflow:hidden;
    }
    .comment-sort{
      display:none; /* 최신순 고정 */
    }
    .comment-list{
      flex:1;
      overflow-y:auto;
      padding:10px 14px;
    }

    .comment-input{
      padding:10px 14px;
      border-top:1px solid rgba(255,255,255,.15);
      display:flex;
      gap:8px;
    }
    .comment-input input{
      flex:1;
      background:#050505;
      border:1px solid rgba(255,255,255,.25);
      border-radius:10px;
      color:#fff;
      padding:10px;
    }
    .comment-input button{
      min-width:64px;
      border-radius:10px;
      border:none;
      background:linear-gradient(180deg,#ff9b2f,#ff6a00);
      color:#000;
      font-weight:800;
    }

    /* ===== 실데이터 댓글 아이템 ===== */
    .sc-empty{ padding:24px 0; text-align:center; color:#777; font-size:13px; }
    .sc-item{ padding:12px 0; border-bottom:1px solid #1e1e1e; }
    .sc-item.sc-reply{ border-bottom:none; padding:10px 0 0; }
    .sc-head{ display:flex; align-items:baseline; gap:6px; margin-bottom:4px; }
    .sc-nick{ font-size:13px; }
    .sc-nick.pro{ color:#5bbcff; }
    .sc-nick.con{ color:#ff6b6b; }
    .sc-lv{ font-size:11px; color:#f5c518; }
    .sc-time{ font-size:11px; color:#666; }
    .sc-body{ font-size:14px; line-height:1.5; color:#eee; word-break:break-word; }
    .sc-acts{ display:flex; align-items:center; gap:10px; margin-top:6px; }
    .sc-like{
      background:#141414; border:1px solid #2c2c2c; color:#aaa;
      padding:3px 10px; border-radius:999px; font-size:12px; cursor:pointer;
    }
    .sc-like.on{ border-color:#4a7bff; color:#8fb6ff; background:rgba(74,123,255,.12); }
    .sc-toggle{ background:none; border:none; color:#888; font-size:12px; cursor:pointer; }
    .sc-replies{ margin-left:14px; padding-left:12px; border-left:1px solid rgba(255,255,255,.12); }
    .billboard-item .bb-like{ color:#f5c518; font-size:11px; margin-left:4px; }
    </style>
  <div class="comment-dim"></div>

  <div class="comment-sheet">

    <!-- A. 전황 요약 (FIXED) -->
    <div class="comment-summary">
      <div class="summary-bar">
        <span class="pro">찬성 62%</span>
        <div class="bar">
          <div class="bar-pro" style="width:62%"></div>
        </div>
        <span class="con">반대 38%</span>
      </div>
      <div class="summary-meta">(총 댓글 184 · 참여자 129)</div>
    </div>

    <!-- B. 찬성 / 반대 탭 (STICKY) -->
    <div class="comment-tabs tabs-menu">
      <button class="stance-tab pro active" data-stance="pro">찬성</button>
      <button class="stance-tab con" data-stance="con">반대</button>
    </div>

    <!-- B-2. 빌보드 (STICKY, 조건부 노출 / 최대 3) -->
    <div id="commentBillboard" class="comment-billboard sticky" hidden>
      <div class="billboard-item">🔥 빌보드 댓글 1</div>
      <div class="billboard-item">🔥 빌보드 댓글 2</div>
      <div class="billboard-item">🔥 빌보드 댓글 3</div>
    </div>

    <!-- D. 댓글 리스트 (ONLY SCROLL AREA) -->
    <div class="comment-list-wrap">
      <div class="comment-sort">
        <button class="sort-btn active" data-sort="latest">최신순</button>
        <button class="sort-btn" data-sort="popular">인기순</button>
      </div>

      <div id="shortsCommentList" class="comment-list"></div>
    </div>

    <!-- E. 댓글 입력 -->
    <div class="comment-input">
      <input id="shortsCommentInput" placeholder="댓글을 입력하세요" />
      <button id="shortsCommentSend">등록</button>
    </div>

  </div>
    `;
    document.body.appendChild(modal);
  }

  track = overlay.querySelector("#shortsTrack");

  /* ===== overlay style ===== */
  Object.assign(overlay.style, {
    position: "fixed",
    inset: "0",
    zIndex: "900",   // 🔥 nav(2000)보다 낮아야 함
    background: "#000",
    overflow: "hidden",
    touchAction: "none",
    overscrollBehavior: "contain",
    display: "block",
    pointerEvents: "auto"
  });

  /* ===== close btn ===== */
  const closeBtn = overlay.querySelector("#shortsCloseBtn");
  Object.assign(closeBtn.style, {
    background: "rgba(0,0,0,.5)", 
    color: "#fff",
    border: "none",
    fontSize: "18px",
    padding: "6px 10px",
    borderRadius: "10px",
  });
  // 인덱스 진입(+) = 이슈 만들기(작성 허브) / 상세 진입(‹) = 닫기
  closeBtn.onclick = SHORTS_ENTRY === 'feed'
    ? () => { closeShorts(); if (window.openWriteHub) window.openWriteHub('galla'); else (window.GALLA_nav || function (u) { location.href = u; })('write.html'); }
    : closeShorts;

  /* ===== track ===== */
  Object.assign(track.style, {
    width: "100%",
    height: `${shortsList.length * VIEWPORT_H}px`,
    transition: "transform 0.35s cubic-bezier(.4,0,.2,1)",
    willChange: "transform"
  });

  // Remove any previous children in track
  track.innerHTML = "";

  shortsList.forEach(item => {
    const section = document.createElement("section");
    section.className = "short";
    section.dataset.issueId = item.id;
    if (item.user_id) section.dataset.authorId = item.user_id;

    Object.assign(section.style, {
      height: `${VIEWPORT_H}px`,
      width: "100%",
      maxWidth: "480px",
      margin: "0 auto",
      position: "relative",
      overflow: "hidden"
    });

    section.innerHTML = `
    <video
      data-src="${item.video_url}"
      playsinline webkit-playsinline muted loop
      preload="none"
      style="width:100%;height:100%;object-fit:cover"
    ></video>

    <!-- LEFT META (AUTHOR) -->
    <div class="shorts-meta">
      <div class="shorts-author">
        <span class="author-avatar-link" ${item.user_id ? `data-profile-uid="${item.user_id}"` : ""}>${window.GALLA_avatarImg ? window.GALLA_avatarImg(item.avatar_url, "author-avatar") : `<div class="author-avatar author-avatar-init">${(item.author || "익").trim().charAt(0) || "익"}</div>`}</span>
        <div class="author-info">
          <div class="author-line">
            <span class="author-name" ${item.user_id ? `data-profile-uid="${item.user_id}"` : ""}>${item.author || "익명"}</span>
            ${item.level !== "" ? `<span class="author-level">Lv.${item.level}</span>` : ""}
          </div>
          ${item.category ? `<div class="shorts-cat">${item.category}</div>` : ""}
          <div class="shorts-title shorts-goto" data-goto="${item.id}" role="link">${item.title || ""}
            <span class="shorts-goto-chip">게시물 보기 ›</span>
          </div>
        </div>
      </div>
    </div>

    <!-- RIGHT ACTIONS -->
    <div class="shorts-actions">
      <button class="shorts-action-btn comment" aria-label="댓글">
        <span class="sa-ic"><svg viewBox="0 0 24 24">
          <path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>
        </svg></span>
        <span class="sa-label">댓글</span>
      </button>

      <button class="shorts-action-btn share" aria-label="공유">
        <span class="sa-ic"><svg viewBox="0 0 24 24">
          <path d="M22 2L11 13"/>
          <path d="M22 2L15 22L11 13L2 9L22 2Z"/>
        </svg></span>
        <span class="sa-label">공유</span>
      </button>

      <button class="shorts-action-btn galvis" data-galvis data-gv-type="issue" data-gv-id="${item.id}" data-gv-title="${String(item.title || "").replace(/"/g, "&quot;").slice(0, 120)}" aria-label="갈비스와 얘기">
        <span class="sa-ic"><svg viewBox="0 0 24 24" fill="none" class="gv-galvis" stroke="currentColor"><circle cx="12" cy="12" r="8.2" stroke-width="1.5" stroke-dasharray="2.3 2.2"/><circle cx="12" cy="12" r="4.7" stroke-width="1.3"/><circle cx="12" cy="12" r="1.9" fill="currentColor" stroke="none"/></svg></span>
        <span class="sa-label">갈비스</span>
      </button>

      <button class="shorts-action-btn goto shorts-goto" data-goto="${item.id}" aria-label="게시물">
        <span class="sa-ic"><svg viewBox="0 0 24 24">
          <path d="M4 5a1 1 0 0 1 1-1h9l6 6v9a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1z"/>
          <path d="M14 4v6h6"/>
        </svg></span>
        <span class="sa-label">게시물</span>
      </button>
    </div>
    `;

    track.appendChild(section);
    wireSlideControls(section, item);
  });

  currentIndex = Math.max(
    0,
    shortsList.findIndex(v => v.id === startId)
  );

  /* 🔥 추가: 쇼츠 복귀용 상태 저장 */
  sessionStorage.setItem("__SHORTS_RETURN__", JSON.stringify({
    list: shortsList,
    index: currentIndex,
    issueId: shortsList[currentIndex]?.id
  }));

  // 🔒 shorts-open 모드 명시 (vote / index 충돌 방지)
  document.body.classList.add("shorts-open");
  shortsNavHide(true);   // 셸 하단 nav 숨김(릴스는 풀스크린)
  window.__CURRENT_SHORT_ISSUE_ID__ = shortsList[currentIndex]?.id || null;

  bindGestures();
  bindWheel();
  bindTapControls();
  bindKeyboard();

  moveToIndex(currentIndex, true);

  updateShortsVoteBar();

  document.body.style.overflow = "hidden";

  const voteBar = overlay.querySelector("#shortsVoteBar");
  voteBar?.addEventListener("click", async e => {
    e.preventDefault();
    e.stopPropagation();

    const btn = e.target.closest(".gv-btn");
    if (!btn) return;

    const type = btn.classList.contains("gv-pro") ? "pro" : "con";
    const issueId = voteBar.dataset.issueId;

    // 0) 로그인 필수 — 팝업 없이 '바로' 로그인 페이지로(사장님 확정: 릴스 위 모달은
    //    셸 nav가 떠서 지저분했다). 셸 iframe이면 최상위 문서를 통째로 이동.
    {
      let uid = null;
      try { const { data: s2 } = await window.supabaseClient.auth.getSession(); uid = s2?.session?.user?.id || null; } catch (e) {}
      if (!uid) { showShortsLoginPopup("진영 선택은 로그인 후 가능해요"); return; }
    }

    if (window.GALLA_VOTE && issueId) {
      // 0-1) 이미 투표했으면 서버 기준 잠금+안내 후 중단(변경 불가)
      if (window.GALLA_VoteBar && await window.GALLA_VoteBar.guardLocked(voteBar, issueId)) return;
      // 1) 낙관적 즉시 반영(첫 클릭에도 바로 움직임)
      if (window.GALLA_VoteBar) window.GALLA_VoteBar.applyVote(voteBar, type);
      // 2) 실제 투표 + 서버 수치로 조용히 수렴
      const stance = await window.GALLA_VOTE(issueId, type, { scope: "shorts" });
      if (window.GALLA_VoteBar && typeof window.GALLA_GET_VOTE_STATS === "function") {
        const s = await window.GALLA_GET_VOTE_STATS(issueId);
        if (s && voteBar.dataset.issueId == String(issueId)) window.GALLA_VoteBar.update(voteBar, s, { myStance: stance || type, animate: false });
      }
    }
  });

  // 음소거 토글(전역 사운드 선호와 통일)
  const muteBtn = overlay.querySelector("#shortsMuteBtn");
  const syncMute = () => {
    const on = window.GALLA_soundOn ? window.GALLA_soundOn() : !window.__REELS_MUTED__;
    overlay.classList.toggle("is-muted", !on);
  };
  muteBtn?.addEventListener("click", e => {
    e.stopPropagation();
    if (window.GALLA_setSound) window.GALLA_setSound(!(window.GALLA_soundOn && window.GALLA_soundOn()));
    else window.__REELS_MUTED__ = !window.__REELS_MUTED__;
    const cur = document.querySelectorAll("#shortsTrack video")[currentIndex];
    if (cur) cur.muted = !!window.__REELS_MUTED__;
    syncMute();
  });
  window.addEventListener("galla:sound", syncMute);
  syncMute();
}

/* 진행바: 현재 영상의 재생 위치를 하단 바에 반영 */
function bindShortsProgress(v) {
  const fill = document.getElementById("shortsProgressFill");
  if (!fill) return;
  if (window.__shortsProgVideo && window.__shortsProgHandler) {
    window.__shortsProgVideo.removeEventListener("timeupdate", window.__shortsProgHandler);
  }
  const h = () => { if (v.duration) fill.style.width = (v.currentTime / v.duration * 100) + "%"; };
  v.addEventListener("timeupdate", h);
  window.__shortsProgVideo = v;
  window.__shortsProgHandler = h;
  h();
}

/* =========================
   MOVE / PLAY
========================= */
function moveToIndex(idx, instant = false) {
  // 범위를 벗어나면 끝으로 스냅(항상 transform 재설정 → 드래그 잔상/튐 방지)
  idx = Math.max(0, Math.min(shortsList.length - 1, idx));

  currentIndex = idx;

  track.style.transition = instant ? "none" : "transform 0.35s cubic-bezier(.4,0,.2,1)";
  // 🔥 실제 화면 높이 기준 이동 (모바일 주소창 / iOS 대응)
  track.style.transform = `translateY(-${idx * VIEWPORT_H}px)`;
  window.__CURRENT_SHORT_ISSUE_ID__ = shortsList[currentIndex]?.id || null;

  playOnlyCurrent();
  updateShortsVoteBar();   // 통합 진영바: 마운트 + 통계/내진영 반영
}

function playOnlyCurrent() {
  document.querySelectorAll("#shortsTrack video").forEach((v, i) => {
    // 현재/인접 슬라이드만 HLS 부착(즉시 전환 위해 다음 것도 미리 버퍼)
    if (Math.abs(i - currentIndex) <= 1 && window.GALLA_attachHls && v.dataset.src) {
      v.preload = "auto";
      window.GALLA_attachHls(v, v.dataset.src);
    }
    if (i === currentIndex) {
      // 🔁 무한 재생 (사용자가 멈출 때까지)
      v.loop = true;
      v.setAttribute("loop", "");
      // 소리는 기본 ON, 사용자가 음소거하면 다음 영상까지 그 상태 유지(스티키)
      v.muted = !!window.__REELS_MUTED__;

      // 이어보기: 인덱스에서 넘어온 재생 위치 적용(해당 아이템 최초 활성화 시 1회)
      const seek = window.__SHORTS_PENDING_SEEK__;
      if (seek && shortsList[currentIndex] && seek.id === shortsList[currentIndex].id) {
        const apply = () => { try { if (v.duration && seek.time < v.duration - 0.3) v.currentTime = seek.time; } catch (_) {} };
        if (v.readyState >= 1) apply();
        else v.addEventListener("loadedmetadata", apply, { once: true });
        window.__SHORTS_PENDING_SEEK__ = null;
      }

      // 진행바 연결(현재 영상 timeupdate)
      bindShortsProgress(v);

      const playPromise = v.play();
      if (playPromise && typeof playPromise.catch === "function") {
        playPromise.catch(err => {
          if (err && err.name === "NotAllowedError") {
            // 진짜 자동재생 정책 차단(제스처 없음)일 때만 음소거로 폴백
            v.muted = true;
            v.play().catch(() => {});
          } else {
            // 데이터 부족 등 → 소리 유지한 채 준비되면 재시도(느린 R2 대응)
            v.addEventListener("canplay", () => {
              v.muted = !!window.__REELS_MUTED__;
              v.play().catch(() => { v.muted = true; v.play().catch(() => {}); });
            }, { once: true });
          }
        });
      }
      v.playbackRate = 1;
    } else {
      v.pause();
      v.currentTime = 0;
    }
  });
}

/* =========================
   TOUCH GESTURE
========================= */
/* 🖐 UI 컨트롤(진영바·액션·상단버튼) 위 터치인가? — 제스처가 이걸 삼키면
   touchend에서 moveToIndex()가 진영바를 재생성하고, iOS는 '눌렀던 버튼이 사라지면
   click을 발사하지 않는다' → 아이폰만 진영 버튼 무반응(사장님 재현: PC·안드로이드는 정상). */
function isReelControl(t) {
  return !!(t && t.closest && t.closest("#shortsVoteBar, .gv, .shorts-actions, .shorts-action-btn, .shorts-top, .shorts-meta, #shortsLoginPop, button, a, input, textarea"));
}

function bindGestures() {
  overlay.addEventListener("touchstart", e => {
    if (window.__COMMENT_OPEN__) return;
    if (isReelControl(e.target)) { isDragging = false; return; }   // 컨트롤 탭은 제스처 대상 아님
    isDragging = true;
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
    currentTranslateY = -currentIndex * VIEWPORT_H;
    track.style.transition = "none";
  }, { passive: true });

  overlay.addEventListener("touchmove", e => {
    if (window.__COMMENT_OPEN__) return;
    if (!isDragging) return;

    const dx = e.touches[0].clientX - startX;
    const dy = e.touches[0].clientY - startY;

    if (Math.abs(dx) > Math.abs(dy)) {
      // 🔒 block vertical movement, but DO NOT move track horizontally
      return;
    }

    track.style.transform = `translateY(${currentTranslateY + dy}px)`;
  }, { passive: true });

  overlay.addEventListener("touchend", e => {
    if (window.__COMMENT_OPEN__) return;
    // ⚠️ 컨트롤 위에서 손 떼면 즉시 종료 — 여기서 moveToIndex()를 부르면 진영바가 다시 그려져
    //    iOS가 click을 취소한다(아이폰 전용 무반응의 직접 원인).
    if (isReelControl(e.target)) { isDragging = false; return; }
    isDragging = false;
    track.style.transition = "transform 0.35s cubic-bezier(.4,0,.2,1)";
    track.style.opacity = "1";

    const dy = e.changedTouches[0].clientY - startY;
    const dx = e.changedTouches[0].clientX - startX;
    const horizontal = Math.abs(dx) > Math.abs(dy);

    // 👉 오른쪽으로 확실히 밀면 → 릴스만 닫고 원래 피드로 복귀 (딴 페이지로 안 감)
    if (horizontal && dx > CLOSE_THRESHOLD_X) {
      closeShorts();
      return;
    }

    // 가로 스와이프(왼쪽/애매한 대각선)는 아무 이동 없이 제자리 스냅
    if (horizontal) {
      moveToIndex(currentIndex);
      return;
    }

    // 세로 스와이프 → 릴스 한 칸씩 (범위 밖이면 clamp되어 제자리 스냅)
    if (dy < -SWIPE_THRESHOLD) moveToIndex(currentIndex + 1);
    else if (dy > SWIPE_THRESHOLD) moveToIndex(currentIndex - 1);
    else moveToIndex(currentIndex);
  });
}

/* =========================
   TAP / DOUBLE TAP
========================= */
/* 릴스 조작:
   - 한 번 탭  → 음소거 토글 (음소거하면 다음 영상까지 유지)
   - 더블 탭 후 누르고 있기 → 누르는 동안 2배속, 떼면 1배속
*/
/* 🔊 음소거/소리 배지 아이콘 — 이모지 대신 SVG(톤 통일, 사장님 확정) */
const REEL_ICONS = {
  soundOn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M18.5 5.5a9 9 0 0 1 0 13"/></svg>',
  soundOff: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"><path d="M11 5 6 9H2v6h4l5 4z"/><path d="M22 9l-6 6"/><path d="M16 9l6 6"/></svg>',
  speed: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 6l8 6-8 6V6z"/><path d="M13 6l8 6-8 6V6z"/></svg>'
};
function reelBadge(section, html, isSpeed) {
  if (!section) return null;
  let b = section.querySelector(`.reel-badge.${isSpeed ? "speed" : "mute"}`);
  if (!b) {
    b = document.createElement("div");
    b.className = `reel-badge ${isSpeed ? "speed" : "mute"}`;
    section.appendChild(b);
  }
  b.innerHTML = html;
  return b;
}
function flashBadge(section, html) {
  const b = reelBadge(section, html, false);
  if (!b) return;
  b.classList.add("show");
  clearTimeout(b.__t);
  b.__t = setTimeout(() => b.classList.remove("show"), 650);
}
function showSpeedBadge(section, on) {
  const b = reelBadge(section, REEL_ICONS.speed + '<i class="rb-tx">2배속</i>', true);
  if (!b) return;
  b.classList.toggle("show", on);
}

function curVideoAndSection() {
  const video = document.querySelectorAll("#shortsTrack video")[currentIndex];
  const section = document.querySelectorAll(".short")[currentIndex];
  return { video, section };
}

// 슬라이드 컨트롤 직접 바인딩 — 문서 위임/iOS click 디스패치 이슈에 안전.
function shareShort(item) {
  if (!item) return;
  const url = location.origin + "/share/issue/" + item.id;
  const title = (item.title || "GALLA").trim();
  if (window.GALLA_share) window.GALLA_share({ url, title, text: title });
  else if (navigator.share) navigator.share({ url, title }).catch(() => {});
  else { try { navigator.clipboard.writeText(url); } catch (e) {} }
}
// 모바일 신뢰성: click 대신 touchend(탭) 직접 처리 + 데스크톱 click 폴백.
// 릴스 오버레이 제스처와 충돌 없이 확실히 발화(스와이프면 무시).
function onTap(el, fn) {
  if (!el) return;
  let sx = 0, sy = 0, moved = false, handled = false;
  el.addEventListener("touchstart", (e) => {
    const t = e.touches[0]; sx = t.clientX; sy = t.clientY; moved = false;
  }, { passive: true });
  el.addEventListener("touchmove", (e) => {
    const t = e.touches[0];
    if (Math.abs(t.clientX - sx) > 10 || Math.abs(t.clientY - sy) > 10) moved = true;
  }, { passive: true });
  el.addEventListener("touchend", (e) => {
    if (moved) return;                 // 스와이프 → 슬라이드 이동에 양보
    e.preventDefault();                // 뒤따르는 ghost click 억제(중복 방지)
    e.stopPropagation();
    handled = true; setTimeout(() => { handled = false; }, 600);
    fn(e);
  });
  el.addEventListener("click", (e) => {
    if (handled) { handled = false; return; }  // 터치로 이미 처리됨
    e.preventDefault(); e.stopPropagation();
    fn(e);
  });
}
function wireSlideControls(section, item) {
  onTap(section.querySelector(".shorts-action-btn.comment"), () => { openCommentModal(); loadShortsComments(); });
  onTap(section.querySelector(".shorts-action-btn.share"), () => shareShort(item));
  section.querySelectorAll(".shorts-goto").forEach(g => onTap(g, () => {
    const cv = document.querySelectorAll("#shortsTrack video")[currentIndex];
    const t = (cv && cv.currentTime > 0.3) ? "&t=" + cv.currentTime.toFixed(1) : "";   // 보던 위치 이어보기
    const url = "issue.html?id=" + item.id + t;
    // SPA(앱): 릴스 닫고 스택 push로 진입 — location.href 하드내비는 MPA로 이탈해 스크롤이 죽는다(프로필 열기와 동일 규약)
    if (document.body.dataset.page === "spa" && window.GALLA_nav) { try { closeShorts(); } catch (_) {} window.GALLA_nav(url); return; }
    location.href = url;
  }));
  section.querySelectorAll("[data-profile-uid]").forEach(p => onTap(p, () => {
    const uid = p.getAttribute("data-profile-uid");
    if (!uid) return;
    // SPA(app.html): 릴스 닫고 스택 push(문서 이탈 시 nav.js 셸 복귀가 ?user를 버림)
    if (document.body.dataset.page === "spa" && window.GALLA_gotoProfile) { try { closeShorts(); } catch (_) {} window.GALLA_gotoProfile(uid); return; }
    location.href = "mypage.html?user=" + encodeURIComponent(uid);
  }));
}

function bindTapControls() {
  let tapTimer = null;
  let waitingSecond = false;
  let holding2x = false;
  let downX = 0, downY = 0, moved = false;

  const isControl = t =>
    t.closest &&
    t.closest(".shorts-vote,.vote-btn,.shorts-actions,.shorts-action-btn,#shortsCloseBtn,.shorts-top,.author-follow,.shorts-goto,#shortsCommentModal,[data-profile-uid]");

  overlay.addEventListener("pointerdown", e => {
    if (isControl(e.target)) return;
    downX = e.clientX; downY = e.clientY; moved = false;
    if (waitingSecond) {
      // 더블탭의 두 번째 탭 → 누르는 동안 2배속
      if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; }
      waitingSecond = false;
      const { video, section } = curVideoAndSection();
      if (video) { video.playbackRate = 2; holding2x = true; showSpeedBadge(section, true); }
    }
  });

  overlay.addEventListener("pointermove", e => {
    if (Math.abs(e.clientX - downX) > 12 || Math.abs(e.clientY - downY) > 12) moved = true;
  });

  const endHold = () => {
    if (!holding2x) return;
    holding2x = false;
    const { video, section } = curVideoAndSection();
    if (video) video.playbackRate = 1;
    showSpeedBadge(section, false);
  };

  overlay.addEventListener("pointerup", e => {
    if (isControl(e.target)) { endHold(); return; }
    if (holding2x) { endHold(); return; }
    if (moved) { // 스와이프였음 → 탭 아님
      if (tapTimer) { clearTimeout(tapTimer); tapTimer = null; }
      waitingSecond = false;
      return;
    }
    // 깔끔한 탭 → 더블탭 여부 확인 후 단일 탭이면 음소거 토글
    waitingSecond = true;
    tapTimer = setTimeout(() => {
      waitingSecond = false; tapTimer = null;
      const { video, section } = curVideoAndSection();
      if (!video) return;
      // 전역 선호를 뒤집어 인덱스·이슈와 통일 (현재 뮤트면 → 켜기)
      if (window.GALLA_setSound) window.GALLA_setSound(window.__REELS_MUTED__);
      else window.__REELS_MUTED__ = !window.__REELS_MUTED__;
      video.muted = window.__REELS_MUTED__;
      flashBadge(section, window.__REELS_MUTED__ ? REEL_ICONS.soundOff : REEL_ICONS.soundOn);
    }, 260);
  });

  overlay.addEventListener("pointercancel", endHold);
}

/* =========================
   WHEEL (PC)
========================= */
function bindWheel() {
  let lock = false;
  let unlockTimer = null;
  overlay.addEventListener("wheel", e => {
    e.preventDefault();
    // 관성/연속 휠이 들어오는 동안 계속 잠금 유지 → 스크롤 1번 = 릴스 1칸
    clearTimeout(unlockTimer);
    unlockTimer = setTimeout(() => { lock = false; }, 260);

    if (lock) return;
    if (Math.abs(e.deltaY) < 8) return;   // 미세 스크롤 무시
    lock = true;

    if (e.deltaY > 0) moveToIndex(currentIndex + 1);
    else moveToIndex(currentIndex - 1);
  }, { passive: false });
}

/* =========================
   KEYBOARD
========================= */
function bindKeyboard() {
  window.addEventListener("keydown", e => {
    if (!overlay) return;
    if (e.key === "ArrowDown") moveToIndex(currentIndex + 1);
    if (e.key === "ArrowUp") moveToIndex(currentIndex - 1);
    if (e.key === "Escape") closeShorts();
  });
}

/* =========================
   VOTE SYNC (기존 시스템 연동)
========================= */
function syncVote() {
  const issueId = shortsList[currentIndex].id;
  if (window.GALLA_CHECK_VOTE) {
    window.GALLA_CHECK_VOTE(issueId, { force: true });
  }
}

function bumpReelView(issueId) {
  if (!issueId) return;
  const key = "gv_viewed_" + issueId;
  try { if (sessionStorage.getItem(key)) return; sessionStorage.setItem(key, "1"); } catch (e) {}
  try { window.supabaseClient?.rpc("bump_view", { p_issue: issueId }); } catch (e) {}
}

function updateShortsVoteBar() {
  const bar = document.getElementById("shortsVoteBar");
  if (!bar || !window.GALLA_VoteBar) return;
  const cur = shortsList[currentIndex] || {};
  const issueId = cur.id;
  bar.dataset.issueId = issueId || "";
  if (!issueId) { console.warn("[SHORTS][VOTE] missing issueId"); return; }
  bumpReelView(issueId);   // 조회수(유튜브식): 릴스 시청도 세션당 1회 카운트

  // 통합 진영바 마운트(슬라이드마다 진영명 갱신)
  window.GALLA_VoteBar.mount(bar, {
    factionA: cur.faction_a || "찬성이오", factionB: cur.faction_b || "난 반댈세",
    pro: 0, con: 0
  });
  // 실제 통계 + 내 진영 반영(애니메이션 없이 초기 세팅)
  (async () => {
    if (typeof window.GALLA_GET_VOTE_STATS === "function") {
      const s = await window.GALLA_GET_VOTE_STATS(issueId);
      if (s && bar.dataset.issueId == String(issueId)) window.GALLA_VoteBar.update(bar, s, { animate: false });
    }
    if (typeof window.GALLA_GET_MY_VOTE === "function") {
      const mine = await window.GALLA_GET_MY_VOTE(issueId);
      if (mine && bar.dataset.issueId == String(issueId)) window.GALLA_VoteBar.setMine(bar, mine);
    }
  })();
}

/* =========================
   CLOSE
========================= */

/* 🛡 릴스 진영/댓글 로그인 게이트 — document 캡처 단계 위임.
   릴스 위에서 다른 핸들러·레이어가 클릭을 삼켜도 여기서 '먼저' 잡는다(사장님: 강하게 막히는 느낌).
   미로그인이면 즉시 팝업 + 이벤트 중단(투표 진행 차단). 로그인 상태면 그냥 흘려보낸다. */
(function () {
  if (window.__shortsGateBound) return; window.__shortsGateBound = 1;
  let cachedUid = undefined;
  async function uid() {
    try { const { data } = await window.supabaseClient.auth.getSession(); return data?.session?.user?.id || null; }
    catch (e) { return null; }
  }
  document.addEventListener("click", function (e) {
    if (!document.getElementById("shortsOverlay")) return;          // 릴스 열려있을 때만
    const t = e.target.closest && e.target.closest(".gv-btn, #shortsCommentSend, #shortsCommentModal .sc-like");
    if (!t) return;
    if (cachedUid) return;                                          // 로그인 확인됨 → 통과
    // 미확인/미로그인 → 일단 막고 세션 확인 후 팝업(또는 재클릭 허용)
    e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation();
    uid().then(function (u) {
      cachedUid = u;
      if (u) { try { t.click(); } catch (_) {} return; }             // 로그인 상태였다면 원래 동작 재실행
      try { showShortsLoginPopup(t.classList.contains("gv-btn") ? "진영 선택은 로그인 후 가능해요" : "로그인 후 이용할 수 있어요"); } catch (_) {}
    });
  }, true);   // ⚠️ capture:true — 버블 차단(stopPropagation)에도 영향받지 않는다
})();

/* 🔐 릴스 위 로그인 팝업 — 자동 리다이렉트 대신 즉각 보이는 안내(사장님 확정).
   [로그인하기] = 릴스 닫고(영상 레이어 제거) 로그인으로 3중 이동. */
function showShortsLoginPopup(msg) {
  const host = document.body;   // ⚠️ 반드시 body — 오버레이 안이면 릴스 레이어에 가려질 수 있다
  if (document.getElementById("shortsLoginPop")) return;
  if (!document.getElementById("shortsLoginPopCss")) {
    const st = document.createElement("style"); st.id = "shortsLoginPopCss";
    st.textContent = [
      "#shortsLoginPop{position:fixed;inset:0;z-index:2147483000;display:flex;align-items:center;justify-content:center;background:rgba(4,6,12,.6)}",
      "#shortsLoginPop .slp-card{width:min(82vw,320px);border-radius:20px;padding:24px 20px 16px;text-align:center;color:#fff;",
        "background:linear-gradient(160deg,rgba(24,27,38,.98),rgba(14,16,22,.98));border:1px solid rgba(255,255,255,.14);box-shadow:0 24px 60px rgba(0,0,0,.6)}",
      "#shortsLoginPop .slp-ic{font-size:40px;margin-bottom:10px}",
      "#shortsLoginPop .slp-t{font-size:17px;font-weight:950;margin-bottom:6px}",
      "#shortsLoginPop .slp-s{font-size:13px;color:#a7afc0;line-height:1.5;margin-bottom:16px}",
      "#shortsLoginPop .slp-go{width:100%;padding:13px;border:0;border-radius:12px;font-size:14.5px;font-weight:950;color:#fff;cursor:pointer;",
        "background:linear-gradient(135deg,#ff4d67,#ff2d55)}",
      "#shortsLoginPop .slp-x{margin-top:10px;background:none;border:0;color:#8b93a6;font-size:12.5px;font-weight:800;cursor:pointer;padding:4px 8px}"
    ].join("");
    document.head.appendChild(st);
  }
  const pop = document.createElement("div");
  pop.id = "shortsLoginPop";
  pop.innerHTML = '<div class="slp-card"><div class="slp-ic">🔒</div><div class="slp-t">로그인이 필요해요</div>' +
    '<div class="slp-s">' + (msg || "로그인 후 이용할 수 있어요") + '</div>' +
    '<button class="slp-go" type="button">로그인하기</button>' +
    '<button class="slp-x" type="button">나중에</button></div>';
  host.appendChild(pop);
  pop.querySelector(".slp-x").onclick = () => pop.remove();
  pop.addEventListener("click", e => { if (e.target === pop) pop.remove(); });
  pop.querySelector(".slp-go").onclick = () => {
    const go = "login.html?next=" + encodeURIComponent("index.html");
    try { closeShorts(); } catch (e) {}
    try { if (window.parent && window.parent !== window) window.parent.postMessage({ galla: "shell", t: "goto", url: go }, location.origin); } catch (e) {}
    try { (window.top || window).location.href = go; } catch (e) {}
    setTimeout(function () { try { location.href = go; } catch (e) {} }, 400);
  };
}

/* 셸(네이티브) 하단 nav 숨김 — 릴스는 풀스크린인데 nav는 부모 문서라 iframe이 못 덮는다(사장님 재현) */
function shortsNavHide(on) {
  try { if (window.parent && window.parent !== window) window.parent.postMessage({ galla: "shell", t: "navhide", on: on }, location.origin); } catch (e) {}
}

function closeShorts() {
  shortsNavHide(false);
  // 이어보기(역방향): 현재 릴스 재생 위치를 인덱스 인라인 영상에 반영
  try {
    const cur = document.querySelectorAll("#shortsTrack video")[currentIndex];
    const id = shortsList[currentIndex]?.id;
    if (cur && id != null && cur.currentTime > 0.3) {
      const inline = document.getElementById("vid-" + id);
      if (inline) inline.currentTime = cur.currentTime;
    }
  } catch (_) {}
  document.body.style.overflow = "";
  document.body.classList.remove("shorts-open");
  window.__CURRENT_SHORT_ISSUE_ID__ = null;
  if (overlay) {
    track = null;
    overlay.remove();
    overlay = null;
  }
}

/* =========================
   EXPORT
========================= */
window.__OPEN_SHORTS_INTERNAL__ = __openShortsInternal;
window.__SHORTS_ENGINE_READY__ = true;
console.info("[SHORTS] engine ready");

if (window.__SHORTS_ENGINE_READY__ && window.__SHORTS_OPEN_QUEUE__.length) {
  window.__SHORTS_OPEN_QUEUE__.forEach(x =>
    window.__OPEN_SHORTS_INTERNAL__(x.list, x.startId, x.startTime, x.entry)
  );
  window.__SHORTS_OPEN_QUEUE__ = [];
}

window.__FORCE_OPEN_SHORTS__ = function () {
  const list = (window.cards || []).filter(c => c.video_url)
    .map(c => ({ id: c.id, video_url: c.video_url }));
  if (!list.length) {
    alert("[SHORTS] no video cards");
    return;
  }
  window.__OPEN_SHORTS_INTERNAL__(list, list[0].id);
};
console.info("[SHORTS] FORCE_OPEN_SHORTS attached");

/* 릴스 → 게시물 본문 이동 (제목 탭) */
document.addEventListener("click", e => {
  const go = e.target.closest(".shorts-goto");
  if (!go || !go.dataset.goto) return;
  e.preventDefault();
  e.stopPropagation();
  const cv = document.querySelectorAll("#shortsTrack video")[currentIndex];
  const t = (cv && cv.currentTime > 0.3) ? `&t=${cv.currentTime.toFixed(1)}` : "";
  const url = `issue.html?id=${go.dataset.goto}${t}`;
  // SPA(앱): 스택 push로 — 하드내비는 MPA 이탈로 스크롤 죽음
  if (document.body.dataset.page === "spa" && window.GALLA_nav) { try { closeShorts(); } catch (_) {} window.GALLA_nav(url); return; }
  location.href = url;
});

document.addEventListener("click", e => {
  const btn = e.target.closest(".shorts-action-btn");
  if (!btn) return;

  const short = btn.closest(".short");
  const issueId = Number(short?.dataset.issueId);
  if (!issueId) return;

  if (btn.classList.contains("comment")) {
    const modal = document.getElementById("shortsCommentModal");
    if (!modal) return;

    openCommentModal();
    loadShortsComments();
  }

  if (btn.classList.contains("share")) {
    shareShort(shortsList[currentIndex] || { id: issueId });
  }
});

function openCommentModal() {
  const modal = document.getElementById("shortsCommentModal");
  const sheet = modal?.querySelector(".comment-sheet");
  if (!modal || !sheet) return;
  if (window.__COMMENT_OPEN__) return;

  window.__COMMENT_OPEN__ = true;
  window.__COMMENT_STATE__ = "half";

  modal.classList.add("visible");
  document.body.classList.add("comment-open");

  const HALF_Y = Math.round(window.innerHeight * 0.45);

  sheet.style.transition = "none";
  sheet.style.transform = `translateX(-50%) translateY(${window.innerHeight}px)`;

  requestAnimationFrame(() => {
    sheet.style.transition = "transform 0.28s cubic-bezier(.4,0,.2,1)";
    sheet.style.transform = `translateX(-50%) translateY(${HALF_Y}px)`;
  });

  bindCommentDrag();
}

function closeCommentModal() {
  const modal = document.getElementById("shortsCommentModal");
  const sheet = modal?.querySelector(".comment-sheet");
  if (!modal || !sheet) return;

  sheet.style.transition = "transform 0.25s cubic-bezier(.4,0,.2,1)";
  sheet.style.transform = `translateX(-50%) translateY(${window.innerHeight}px)`;

  setTimeout(() => {
    modal.classList.remove("visible");
    document.body.classList.remove("comment-open");
    window.__COMMENT_OPEN__ = false;
    window.__COMMENT_STATE__ = "closed";

    const video = document.querySelectorAll("#shortsTrack video")[currentIndex];
    if (video) video.play().catch(() => {});
  }, 260);
}

function bindCommentDrag() {
  const modal = document.getElementById("shortsCommentModal");
  const sheet = modal?.querySelector(".comment-sheet");
  const list = sheet?.querySelector(".comment-list");
  if (!sheet || !list) return;

  let startY = 0;
  let startPos = 0;
  let currentPos = 0;
  let dragging = false;

  const FULL_Y = 0;
  const HALF_Y = Math.round(window.innerHeight * 0.45);
  const CLOSE_Y = Math.round(window.innerHeight * 0.85);

  sheet.ontouchstart = e => {
    if (isScrollableTarget(e.target) && list.scrollTop > 0) return;
    dragging = true;
    startY = e.touches[0].clientY;
    startPos = sheet.getBoundingClientRect().top;
    sheet.style.transition = "none";
  };

  sheet.ontouchmove = e => {
    if (!dragging) return;
    const dy = e.touches[0].clientY - startY;
    currentPos = Math.min(CLOSE_Y, Math.max(FULL_Y, startPos + dy));
    sheet.style.transform = `translateX(-50%) translateY(${currentPos}px)`;
  };

  sheet.ontouchend = () => {
    if (!dragging) return;
    dragging = false;
    sheet.style.transition = "transform 0.28s cubic-bezier(.4,0,.2,1)";

    if (currentPos > window.innerHeight * 0.6) {
      closeCommentModal();
      return;
    }

    if (currentPos < window.innerHeight * 0.25) {
      window.__COMMENT_STATE__ = "full";
      sheet.style.transform = `translateX(-50%) translateY(${FULL_Y}px)`;
    } else {
      window.__COMMENT_STATE__ = "half";
      sheet.style.transform = `translateX(-50%) translateY(${HALF_Y}px)`;
    }
  };

  // ===== PC MOUSE DRAG SUPPORT =====
  let mouseDragging = false;

  sheet.onmousedown = e => {
    // 댓글 리스트 스크롤 중이면 모달 드래그 막음
    if (isScrollableTarget(e.target) && list.scrollTop > 0) return;

    mouseDragging = true;
    startY = e.clientY;
    startPos = sheet.getBoundingClientRect().top;
    sheet.style.transition = "none";

    e.preventDefault();
  };

  window.onmousemove = e => {
    if (!mouseDragging) return;

    const dy = e.clientY - startY;
    currentPos = Math.min(CLOSE_Y, Math.max(FULL_Y, startPos + dy));
    sheet.style.transform = `translateX(-50%) translateY(${currentPos}px)`;
  };

  window.onmouseup = () => {
    if (!mouseDragging) return;
    mouseDragging = false;

    sheet.style.transition = "transform 0.28s cubic-bezier(.4,0,.2,1)";

    if (currentPos > window.innerHeight * 0.6) {
      closeCommentModal();
      return;
    }

    if (currentPos < window.innerHeight * 0.25) {
      window.__COMMENT_STATE__ = "full";
      sheet.style.transform = `translateX(-50%) translateY(${FULL_Y}px)`;
    } else {
      window.__COMMENT_STATE__ = "half";
      sheet.style.transform = `translateX(-50%) translateY(${HALF_Y}px)`;
    }
  };
}

document.addEventListener("click", e => {
  const modal = document.getElementById("shortsCommentModal");
  if (!modal || !modal.classList.contains("visible")) return;

  if (e.target.classList.contains("comment-dim")) {
    closeCommentModal();
  }
});

// =========================
// COMMENT STANCE TAB (STATE)
// =========================
document.addEventListener("click", e => {
  const tab = e.target.closest("#shortsCommentModal .stance-tab");
  if (!tab) return;

  e.preventDefault();
  e.stopPropagation();

  const stance = tab.dataset.stance;
  if (!stance) return;

  // 상태 저장
  window.currentCommentStance = stance;

  // UI 갱신
  document
    .querySelectorAll("#shortsCommentModal .stance-tab")
    .forEach(btn => btn.classList.remove("active"));

  tab.classList.add("active");

  // 댓글 다시 로딩
  loadShortsComments();
});


// =========================
// COMMENT LOAD (REAL DATA — issue comments 연동)
// =========================
const SC = {
  issueId: null,
  rows: [],           // 전체 댓글 rows
  profiles: {},       // user_id → {nickname, level}
  likeAgg: {},        // comment_id → {up, down}
  myLikes: new Map(), // comment_id → 1|-1
  myId: null,
  expanded: new Set() // 답글 펼침 상태
};
window.currentCommentStance = window.currentCommentStance || "pro";
window.currentCommentSort = window.currentCommentSort || "latest";

function scEsc(s) {
  return String(s ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;");
}
function scTimeAgo(iso) {
  if (!iso) return "";
  const t = new Date(iso.endsWith?.("Z") || iso.includes?.("+") ? iso : iso + "Z").getTime();
  const s = (Date.now() - t) / 1000;
  if (s < 60) return "방금 전";
  if (s < 3600) return `${Math.floor(s / 60)}분 전`;
  if (s < 86400) return `${Math.floor(s / 3600)}시간 전`;
  return `${Math.floor(s / 86400)}일 전`;
}
function scNick(r) {
  if (r.is_anonymous) return "익명";
  return SC.profiles[r.user_id]?.nickname || "익명";
}
function scLevel(r) {
  if (r.is_anonymous) return "";
  const lv = SC.profiles[r.user_id]?.level;
  return lv ? `<span class="sc-lv">Lv.${lv}</span>` : "";
}

async function loadShortsComments() {
  const supabase = window.supabaseClient;
  const list = document.getElementById("shortsCommentList");
  if (!supabase || !list) return;

  const issueId = window.__CURRENT_SHORT_ISSUE_ID__;
  if (!issueId) { list.innerHTML = ""; return; }
  SC.issueId = issueId;

  list.innerHTML = `<div class="sc-empty">불러오는 중…</div>`;

  const { data: sess } = await supabase.auth.getSession();
  SC.myId = sess?.session?.user?.id || null;

  // 이슈 전황(찬반) + 진영 이름 + 댓글
  const [{ data: issue }, { data: rows }] = await Promise.all([
    supabase.from("issues")
      .select("pro_count,con_count,faction_a,faction_b").eq("id", issueId).single(),
    supabase.from("comments")
      .select("id,user_id:author_id,content,created_at,faction,parent_id,is_anonymous")
      .eq("issue_id", issueId).neq("status", "deleted")
      .order("created_at", { ascending: false }).limit(300)
  ]);
  // 로딩 중 스크롤로 이슈가 바뀌었으면 무시
  if (SC.issueId !== window.__CURRENT_SHORT_ISSUE_ID__) return;
  SC.rows = rows || [];

  // 전황 요약 갱신
  const pro = issue?.pro_count || 0, con = issue?.con_count || 0;
  const total = pro + con;
  const proPct = total ? Math.round(pro / total * 100) : 50;
  const modal = document.getElementById("shortsCommentModal");
  const bar = modal.querySelector(".summary-bar");
  if (bar) {
    bar.querySelector(".pro").textContent = `${issue?.faction_a || "찬성이오"} ${proPct}%`;
    bar.querySelector(".con").textContent = `${issue?.faction_b || "난 반댈세"} ${100 - proPct}%`;
    bar.querySelector(".bar-pro").style.width = proPct + "%";
  }
  const participants = new Set(SC.rows.map(r => r.user_id).filter(Boolean)).size;
  const metaEl = modal.querySelector(".summary-meta");
  if (metaEl) metaEl.textContent = `(총 댓글 ${SC.rows.length} · 참여자 ${participants})`;

  // 탭 라벨도 진영 이름으로
  const tabPro = modal.querySelector('.stance-tab[data-stance="pro"]');
  const tabCon = modal.querySelector('.stance-tab[data-stance="con"]');
  if (tabPro) tabPro.textContent = issue?.faction_a || "찬성이오";
  if (tabCon) tabCon.textContent = issue?.faction_b || "난 반댈세";

  // 프로필 + 좋아요
  SC.profiles = {}; SC.likeAgg = {}; SC.myLikes = new Map();
  const userIds = [...new Set(SC.rows.map(r => r.user_id).filter(Boolean))];
  const ids = SC.rows.map(r => r.id);
  const [profRes, likeRes] = await Promise.all([
    userIds.length
      ? supabase.from("user_profiles").select("user_id,nickname,level").in("user_id", userIds)
      : Promise.resolve({ data: [] }),
    ids.length
      ? supabase.from("comment_likes").select("comment_id,user_id,value").in("comment_id", ids)
      : Promise.resolve({ data: [] })
  ]);
  (profRes.data || []).forEach(p => SC.profiles[p.user_id] = p);
  (likeRes.data || []).forEach(l => {
    const a = SC.likeAgg[l.comment_id] ||= { up: 0, down: 0 };
    if (l.value === 1) a.up++; else a.down++;
    if (SC.myId && l.user_id === SC.myId) SC.myLikes.set(l.comment_id, l.value);
  });

  renderShortsComments();
}

function renderShortsComments() {
  const list = document.getElementById("shortsCommentList");
  if (!list) return;

  const stance = window.currentCommentStance;
  const sort = window.currentCommentSort;

  const tops = SC.rows.filter(r => !r.parent_id && r.faction === stance);
  const byParent = {};
  SC.rows.forEach(r => { if (r.parent_id) (byParent[r.parent_id] ||= []).push(r); });

  const up = id => (SC.likeAgg[id]?.up || 0);
  if (sort === "popular") tops.sort((a, b) => up(b.id) - up(a.id));
  // latest는 이미 created_at desc 정렬 상태

  // 빌보드: 현재 진영 좋아요 상위 3 (1개 이상일 때만 노출)
  const billboard = document.getElementById("commentBillboard");
  const hot = [...tops].filter(c => up(c.id) > 0).sort((a, b) => up(b.id) - up(a.id)).slice(0, 3);
  if (billboard) {
    billboard.hidden = hot.length === 0;
    billboard.innerHTML = hot.map(c =>
      `<div class="billboard-item">🔥 <b>${scEsc(scNick(c))}</b> ${scEsc(c.content).slice(0, 40)} <span class="bb-like">👍${up(c.id)}</span></div>`
    ).join("");
  }

  if (!tops.length) {
    list.innerHTML = `<div class="sc-empty">아직 이 진영의 댓글이 없어요. 첫 포문을 여세요!</div>`;
    return;
  }

  const itemHtml = (c, isReply) => {
    const my = SC.myLikes.get(c.id);
    const replies = byParent[c.id] || [];
    return `
      <div class="sc-item ${isReply ? "sc-reply" : ""}" data-cid="${c.id}">
        <div class="sc-head">
          <b class="sc-nick ${c.faction === "pro" ? "pro" : "con"}">${scEsc(scNick(c))}</b>
          ${scLevel(c)}
          <span class="sc-time">${scTimeAgo(c.created_at)}</span>
        </div>
        <div class="sc-body">${scEsc(c.content)}</div>
        <div class="sc-acts">
          <button class="sc-like ${my === 1 ? "on" : ""}" data-cid="${c.id}">👍 ${up(c.id)}</button>
          ${!isReply && replies.length
            ? `<button class="sc-toggle" data-cid="${c.id}">답글 ${replies.length}개 ${SC.expanded.has(c.id) ? "접기" : "보기"}</button>`
            : ""}
        </div>
        ${!isReply && SC.expanded.has(c.id)
          ? `<div class="sc-replies">${replies.slice().reverse().map(r => itemHtml(r, true)).join("")}</div>`
          : ""}
      </div>`;
  };

  list.innerHTML = tops.map(c => itemHtml(c, false)).join("");
}

// ===== 댓글 상호작용: 정렬 / 답글 펼침 / 좋아요 =====
document.addEventListener("click", async e => {
  const modal = document.getElementById("shortsCommentModal");
  if (!modal || !modal.classList.contains("visible")) return;
  const supabase = window.supabaseClient;

  const sortBtn = e.target.closest("#shortsCommentModal .sort-btn");
  if (sortBtn) {
    window.currentCommentSort = sortBtn.dataset.sort;
    modal.querySelectorAll(".sort-btn").forEach(b => b.classList.toggle("active", b === sortBtn));
    renderShortsComments();
    return;
  }

  const tg = e.target.closest("#shortsCommentModal .sc-toggle");
  if (tg) {
    const cid = Number(tg.dataset.cid);
    if (SC.expanded.has(cid)) SC.expanded.delete(cid); else SC.expanded.add(cid);
    renderShortsComments();
    return;
  }

  const likeBtn = e.target.closest("#shortsCommentModal .sc-like");
  if (likeBtn && supabase) {
    if (!SC.myId) {
      showShortsLoginPopup("로그인 후 이용할 수 있어요");
      return;
    }
    const cid = Number(likeBtn.dataset.cid);
    const mine = SC.myLikes.get(cid);
    if (mine === 1) {
      await supabase.from("comment_likes").delete().eq("comment_id", cid).eq("user_id", SC.myId);
      SC.myLikes.delete(cid);
      if (SC.likeAgg[cid]) SC.likeAgg[cid].up = Math.max(0, SC.likeAgg[cid].up - 1);
    } else {
      const { error } = await supabase.from("comment_likes")
        .upsert({ comment_id: cid, user_id: SC.myId, value: 1 }, { onConflict: "comment_id,user_id" });
      if (!error) {
        (SC.likeAgg[cid] ||= { up: 0, down: 0 }).up++;
        SC.myLikes.set(cid, 1);
      }
    }
    renderShortsComments();
    return;
  }
});

// ===== 댓글 등록 (로그인 필수, 현재 진영 탭으로 등록) =====
document.addEventListener("click", async e => {
  if (!e.target.closest("#shortsCommentSend")) return;
  const supabase = window.supabaseClient;
  const input = document.getElementById("shortsCommentInput");
  if (!supabase || !input) return;

  const content = input.value.trim();
  if (!content) return;

  const { data: sess } = await supabase.auth.getSession();
  const uid = sess?.session?.user?.id;
  if (!uid) {
    showShortsLoginPopup("로그인 후 이용할 수 있어요");
    return;
  }

  const { error } = await supabase.from("comments").insert({
    issue_id: SC.issueId,
    user_id: uid,
    faction: window.currentCommentStance,
    content
  });
  if (error) { console.error("[SHORTS] comment insert", error); alert("댓글 등록 실패"); return; }

  input.value = "";
  loadShortsComments();
});
  // ===== Inject overlay styles for shorts actions (once) =====
  // (액션 레일 스타일은 css/shorts.css 로 이관 — 중복 주입 제거)